package com.flyairnorth.integration;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Configuration
@EnableWebMvc
@EnableAsync
@EnableRetry
@EnableTransactionManagement
@EnableJpaRepositories(basePackages="com.flyairnorth.integration.repository", repositoryImplementationPostfix="Impl")
@PropertySources({ @PropertySource(value = { "classpath:internal.properties" }),
		@PropertySource(ignoreResourceNotFound = true, value = { "file:${application.properties}" }) })
public class ApplicationConfiguration {
	
}
