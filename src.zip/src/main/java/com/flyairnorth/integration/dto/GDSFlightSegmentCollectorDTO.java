package com.flyairnorth.integration.dto;

import java.util.List;

import com.flyairnorth.integration.entity.GDSFlightSegments;

public class GDSFlightSegmentCollectorDTO {
	
	private List<GDSFlightSegmentDTO> gdsFlightSegmentDTO;
	private List<GDSFlightSegments> gdsFlightSegments;
	
	public List<GDSFlightSegmentDTO> getGdsFlightSegmentDTO() {
		return gdsFlightSegmentDTO;
	}
	public void setGdsFlightSegmentDTO(List<GDSFlightSegmentDTO> gdsFlightSegmentDTO) {
		this.gdsFlightSegmentDTO = gdsFlightSegmentDTO;
	}
	public List<GDSFlightSegments> getGdsFlightSegments() {
		return gdsFlightSegments;
	}
	public void setGdsFlightSegments(List<GDSFlightSegments> gdsFlightSegments) {
		this.gdsFlightSegments = gdsFlightSegments;
	}
	

}
