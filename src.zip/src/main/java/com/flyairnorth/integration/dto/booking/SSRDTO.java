package com.flyairnorth.integration.dto.booking;

public class SSRDTO {
	
	private String ssrCode;
	public String getSsrCode() {
		return ssrCode;
	}
	public void setSsrCode(String ssrCode) {
		this.ssrCode = ssrCode;
	}
	public String getTravelerRefNumberRPHList() {
		return travelerRefNumberRPHList;
	}
	public void setTravelerRefNumberRPHList(String travelerRefNumberRPHList) {
		this.travelerRefNumberRPHList = travelerRefNumberRPHList;
	}
	public String getFlightRefNumberRPHList() {
		return flightRefNumberRPHList;
	}
	public void setFlightRefNumberRPHList(String flightRefNumberRPHList) {
		this.flightRefNumberRPHList = flightRefNumberRPHList;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getFromCode() {
		return fromCode;
	}
	public void setFromCode(String fromCode) {
		this.fromCode = fromCode;
	}
	public String getToCode() {
		return toCode;
	}
	public void setToCode(String toCode) {
		this.toCode = toCode;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	private String travelerRefNumberRPHList;
	private String flightRefNumberRPHList;
	private String status;
	private String fromCode;
	private String toCode;
	private String firstName;
	private String lastName;
	

}
