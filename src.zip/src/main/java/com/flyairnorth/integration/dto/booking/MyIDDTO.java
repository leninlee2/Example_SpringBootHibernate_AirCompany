package com.flyairnorth.integration.dto.booking;

public class MyIDDTO {

	private String employeeID;
	private String employeeType;
	private boolean assignSeat;
	private String passengerAirlineCode;
	private String fareCode;
	
	public MyIDDTO() {}
	
	public MyIDDTO(String employeeID, String employeeType, boolean assignSeat, String passengerAirlineCode,
			String fareCode) {
		this.employeeID = employeeID;
		this.employeeType = employeeType;
		this.assignSeat = assignSeat;
		this.passengerAirlineCode = passengerAirlineCode;
		this.fareCode = fareCode;
	}

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

	public boolean isAssignSeat() {
		return assignSeat;
	}

	public void setAssignSeat(boolean assignSeat) {
		this.assignSeat = assignSeat;
	}

	public String getPassengerAirlineCode() {
		return passengerAirlineCode;
	}

	public void setPassengerAirlineCode(String passengerAirlineCode) {
		this.passengerAirlineCode = passengerAirlineCode;
	}

	public String getFareCode() {
		return fareCode;
	}

	public void setFareCode(String fareCode) {
		this.fareCode = fareCode;
	}
}