package com.flyairnorth.integration.dto.booking;

import java.util.ArrayList;
import java.util.List;

import com.flyairnorth.integration.enumerator.PaymentMethods;

public class PaymentDTO {

	private PaymentMethods paymentMethod;
	private String paymentTransactionTypeCode;
	private List<AmountCurrencyAndApprovalCodeDTO> amounts;
	private String iataNumber;
	//new parameter to booking number
	private String bookiata;

	public String getBookiata() {
		return bookiata;
	}

	public void setBookiata(String bookiata) {
		this.bookiata = bookiata;
	}

	public PaymentDTO() {
		this.amounts = new ArrayList<>();
	}

	public List<AmountCurrencyAndApprovalCodeDTO> getAmounts() {
		return amounts;
	}

	public void setAmounts(List<AmountCurrencyAndApprovalCodeDTO> amounts) {
		this.amounts = amounts;
	}

	public PaymentMethods getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(PaymentMethods paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getPaymentTransactionTypeCode() {
		return paymentTransactionTypeCode;
	}

	public void setPaymentTransactionTypeCode(String paymentTransactionTypeCode) {
		this.paymentTransactionTypeCode = paymentTransactionTypeCode;
	}

	public String getIataNumber() {
		return iataNumber;
	}

	public void setIataNumber(String iataNumber) {
		this.iataNumber = iataNumber;
	}
}
