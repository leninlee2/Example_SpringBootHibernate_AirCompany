package com.flyairnorth.integration.dto.booking;

import java.util.ArrayList;
import java.util.List;

public class InvalidEmailDTO {

	private String email;
	private List<String> contacts;
	private String name;
	private String inum;
	private String pnr;
	private String tnum;
	private Integer tnumcntr;
	
	public InvalidEmailDTO() {
		super();
		this.contacts = new ArrayList<>();
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<String> getContacts() {
		return contacts;
	}

	public void setContacts(List<String> contacts) {
		this.contacts = contacts;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getInum() {
		return inum;
	}

	public void setInum(String inum) {
		this.inum = inum;
	}

	public String getPnr() {
		return pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public String getTnum() {
		return tnum;
	}

	public void setTnum(String tnum) {
		this.tnum = tnum;
	}

	public Integer getTnumcntr() {
		return tnumcntr;
	}

	public void setTnumcntr(Integer tnumcntr) {
		this.tnumcntr = tnumcntr;
	}
}
