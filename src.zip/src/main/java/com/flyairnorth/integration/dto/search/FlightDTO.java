package com.flyairnorth.integration.dto.search;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class FlightDTO {
	
	private String flightNumber;
	
	private String origin;

	private String destination;
	
	private List<FareDTO> fares;
	
	private LocalDateTime departureDateTime;

	private LocalDateTime arrivalDateTime;
	
	private String status;
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public FlightDTO() {
		this.fares = new ArrayList<>();
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public List<FareDTO> getFares() {
		return fares;
	}

	public void setFares(List<FareDTO> fares) {
		this.fares = fares;
	}

	public LocalDateTime getDepartureDateTime() {
		return departureDateTime;
	}

	public void setDepartureDateTime(LocalDateTime departureDateTime) {
		this.departureDateTime = departureDateTime;
	}

	public LocalDateTime getArrivalDateTime() {
		return arrivalDateTime;
	}

	public void setArrivalDateTime(LocalDateTime arrivalDateTime) {
		this.arrivalDateTime = arrivalDateTime;
	}
}
