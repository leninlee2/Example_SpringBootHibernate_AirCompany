package com.flyairnorth.integration.dto.booking;

import java.util.List;

public class AddressDTO {

	private List<String> addressLines;
	private String state;
	private String cityName;
	private String country;
	private String postalCode;

	public List<String> getAddressLines() {
		return addressLines;
	}

	public void setAddressLines(List<String> addressLines) {
		this.addressLines = addressLines;
	}

	public String getState() {
		if (this.state == null) {
			return "";
		}
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCityName() {
		if (this.cityName == null) {
			return "";
		}
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getCountry() {
		if (this.country == null) { 
			return "";
		}
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPostalCode() {
		if (this.postalCode == null) { 
			return "";
		}
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
}
