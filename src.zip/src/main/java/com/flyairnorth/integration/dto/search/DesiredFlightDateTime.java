package com.flyairnorth.integration.dto.search;

import java.time.LocalDate;
import java.time.LocalTime;

public class DesiredFlightDateTime {

	private LocalDate departureDate;

	private LocalTime initialWindowTime;

	private LocalTime finalWindowTime;

	public DesiredFlightDateTime(LocalDate departureDate, LocalTime initialWindowTime, LocalTime finalWindowTime) {
		this.departureDate = departureDate;
		this.initialWindowTime = initialWindowTime;
		this.finalWindowTime = finalWindowTime;
	}

	public LocalDate getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(LocalDate departureDate) {
		this.departureDate = departureDate;
	}

	public LocalTime getInitialWindowTime() {
		return initialWindowTime;
	}

	public void setInitialWindowTime(LocalTime initialWindowTime) {
		this.initialWindowTime = initialWindowTime;
	}

	public LocalTime getFinalWindowTime() {
		return finalWindowTime;
	}

	public void setFinalWindowTime(LocalTime finalWindowTime) {
		this.finalWindowTime = finalWindowTime;
	}
}
