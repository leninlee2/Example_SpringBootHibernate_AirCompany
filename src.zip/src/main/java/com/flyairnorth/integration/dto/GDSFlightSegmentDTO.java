package com.flyairnorth.integration.dto;

import com.flyairnorth.integration.entity.GDSFlightSegments;

public class GDSFlightSegmentDTO {
	
	private GDSFlightSegments gdsFlightSegments;
	
	public GDSFlightSegments getGdsFlightSegments() {
		return gdsFlightSegments;
	}
	public void setGdsFlightSegments(GDSFlightSegments gdsFlightSegments) {
		this.gdsFlightSegments = gdsFlightSegments;
	}
	public String getMarketingAirline() {
		return marketingAirline;
	}
	public void setMarketingAirline(String marketingAirline) {
		this.marketingAirline = marketingAirline;
	}
	private String marketingAirline;

}
