package com.flyairnorth.integration.dto.booking;

import com.flyairnorth.integration.enumerator.VidecomContactType;

public class TelephoneDTO {

	private String phoneNumber;
	
	private VidecomContactType type;

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		if (phoneNumber != null && phoneNumber.length() > 30) {
			phoneNumber = phoneNumber.substring(0, 30);
		}
		this.phoneNumber = phoneNumber;
	}

	public VidecomContactType getType() {
		return type;
	}

	public void setType(VidecomContactType type) {
		this.type = type;
	}

	public String toString() {
		return phoneNumber; 
	}
}
