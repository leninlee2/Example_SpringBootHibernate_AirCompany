package com.flyairnorth.integration.dto.booking;

public class PointOfSaleDTO {

	private String companyName;

	private String airportOfTicketing;

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getAirportOfTicketing() {
		return airportOfTicketing;
	}

	public void setAirportOfTicketing(String airportOfTicketing) {
		this.airportOfTicketing = airportOfTicketing;
	}
}
