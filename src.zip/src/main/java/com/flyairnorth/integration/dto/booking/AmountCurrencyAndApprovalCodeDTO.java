package com.flyairnorth.integration.dto.booking;

import java.math.BigDecimal;

public class AmountCurrencyAndApprovalCodeDTO {

	private String currency;
	private BigDecimal amount;
	private String approvalCode;

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getApprovalCode() {
		return approvalCode;
	}

	public void setApprovalCode(String approvalCode) {
		this.approvalCode = approvalCode;
	}
}