package com.flyairnorth.integration.dto;

import java.util.List;

public class ChangelogItem {

	private String date;
	private List<String> descriptions;
	private String version;

	public ChangelogItem() {}

	public ChangelogItem(String date, String version, List<String> descriptions) {
		this.date = date;
		this.version = version;
		this.descriptions = descriptions;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public List<String> getDescriptions() {
		return descriptions;
	}

	public void setDescriptions(List<String> descriptions) {
		this.descriptions = descriptions;
	}
}
