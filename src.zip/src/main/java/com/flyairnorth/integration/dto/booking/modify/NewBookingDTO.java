package com.flyairnorth.integration.dto.booking.modify;

import java.util.ArrayList;
import java.util.List;

import com.flyairnorth.integration.dto.booking.BookingDTO;
import com.flyairnorth.integration.dto.booking.BookingPassengerDTO;
import com.flyairnorth.integration.dto.booking.PaymentDTO;
import com.flyairnorth.integration.dto.booking.PointOfSaleDTO;
import com.flyairnorth.integration.dto.booking.TicketDTO;

public class NewBookingDTO {
	private List<BookingPassengerDTO> passengers;
	private List<BookingDTO> bookingList;
	private List<PaymentDTO> payments;
	private List<TicketDTO> tickets;
	private PointOfSaleDTO pointOfSale;
	
	public List<BookingPassengerDTO> getPassengers() {
		if (passengers == null) {
			this.passengers = new ArrayList<>();
		}
		return passengers;
	}

	public void setPassengers(List<BookingPassengerDTO> passengers) {
		this.passengers = passengers;
	}

	public List<BookingDTO> getBookingList() {
		return bookingList;
	}

	public void setBookingList(List<BookingDTO> bookingList) {
		this.bookingList = bookingList;
	}

	public List<PaymentDTO> getPayments() {
		return payments;
	}

	public void setPayments(List<PaymentDTO> payments) {
		this.payments = payments;
	}

	public List<TicketDTO> getTickets() {
		return tickets;
	}

	public void setTickets(List<TicketDTO> tickets) {
		this.tickets = tickets;
	}

	public PointOfSaleDTO getPointOfSale() {
		return pointOfSale;
	}

	public void setPointOfSale(PointOfSaleDTO pointOfSale) {
		this.pointOfSale = pointOfSale;
	}
}
