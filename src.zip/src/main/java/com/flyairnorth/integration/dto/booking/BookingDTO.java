package com.flyairnorth.integration.dto.booking;

import java.time.LocalDateTime;

public class BookingDTO {

	private String origin;
	private String destination;
	private String fareClass;
	private String fareCode;
	private String flightNumber;
	private LocalDateTime departureDateTime;
	private String segmentReferenceNumber;
	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getFareClass() {
		return fareClass;
	}

	public void setFareClass(String fareClass) {
		this.fareClass = fareClass;
	}

	public String getFareCode() {
		return fareCode;
	}

	public void setFareCode(String fareCode) {
		this.fareCode = fareCode;
	}

	public LocalDateTime getDepartureDateTime() {
		return departureDateTime;
	}

	public void setDepartureDateTime(LocalDateTime departureDateTime) {
		this.departureDateTime = departureDateTime;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getSegmentReferenceNumber() {
		return segmentReferenceNumber;
	}

	public void setSegmentReferenceNumber(String segmentReferenceNumber) {
		this.segmentReferenceNumber = segmentReferenceNumber;
	}
}
