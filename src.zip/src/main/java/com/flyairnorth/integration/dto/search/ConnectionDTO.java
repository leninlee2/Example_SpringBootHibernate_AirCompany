package com.flyairnorth.integration.dto.search;

import java.util.List;

public class ConnectionDTO {

	private FlightDTO firstLeg;
	private FlightDTO secondLeg;
	private List<FareDTO> fares;

	public ConnectionDTO() {
		super();
	}

	public ConnectionDTO(FlightDTO firstFlightDTO, FlightDTO secondFlightDTO, List<FareDTO> fares) {
		this.firstLeg = firstFlightDTO;
		this.secondLeg = secondFlightDTO;
		this.fares = fares;
	}

	public FlightDTO getFirstLeg() {
		return firstLeg;
	}

	public void setFirstLeg(FlightDTO firstLeg) {
		this.firstLeg = firstLeg;
	}

	public FlightDTO getSecondLeg() {
		return secondLeg;
	}

	public void setSecondLeg(FlightDTO secondLeg) {
		this.secondLeg = secondLeg;
	}

	public List<FareDTO> getFares() {
		return fares;
	}

	public void setFares(List<FareDTO> fares) {
		this.fares = fares;
	}
}
