package com.flyairnorth.integration.dto.booking;

public class CancelDTO {
	private String inum;
	private String tnum;
	private Integer tnumcntr;
	private String rloc;

	public String getInum() {
		return inum;
	}

	public void setInum(String inum) {
		this.inum = inum;
	}

	public String getTnum() {
		return tnum;
	}

	public void setTnum(String tnum) {
		this.tnum = tnum;
	}

	public Integer getTnumcntr() {
		return tnumcntr;
	}

	public void setTnumcntr(Integer tnumcntr) {
		this.tnumcntr = tnumcntr;
	}

	public String getRloc() {
		return rloc;
	}

	public void setRloc(String rloc) {
		this.rloc = rloc;
	}
}
