package com.flyairnorth.integration.dto.booking.modify;

public class OldBookingDTO {

	private String inum;
	private String tnum;
	private String tnumcntr;
	private String rloc;

	public String getInum() {
		return inum;
	}

	public void setInum(String inum) {
		this.inum = inum;
	}

	public String getTnum() {
		return tnum;
	}

	public void setTnum(String tnum) {
		this.tnum = tnum;
	}

	public String getTnumcntr() {
		return tnumcntr;
	}

	public void setTnumcntr(String tnumcntr) {
		this.tnumcntr = tnumcntr;
	}

	public String getRloc() {
		return rloc;
	}

	public void setRloc(String rloc) {
		this.rloc = rloc;
	}
}
