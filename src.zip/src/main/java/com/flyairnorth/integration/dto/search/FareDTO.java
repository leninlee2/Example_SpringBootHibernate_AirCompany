package com.flyairnorth.integration.dto.search;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import com.flyairnorth.integration.enumerator.PaxType;

public class FareDTO {

	private List<ChargeDTO> charges;

	private BigDecimal fareValue;

	private String currencyIsocode;

	private String origin;

	private String destination;

	private String fareClass;

	private String code;

	private String myIDBookingStatus;

	private PassengerDTO passengerDTO;

	private PaxType paxType;

	public FareDTO() {
		this.charges = new ArrayList<>();
	}

	public List<ChargeDTO> getCharges() {
		return charges;
	}

	public void setCharges(List<ChargeDTO> charges) {
		this.charges = charges;
	}

	public BigDecimal getFareValue() {
		return fareValue;
	}

	public void setFareValue(BigDecimal fareValue) {
		this.fareValue = fareValue;
	}

	public String getCurrencyIsocode() {
		return currencyIsocode;
	}

	public void setCurrencyIsocode(String currencyIsocode) {
		this.currencyIsocode = currencyIsocode;
	}

	public BigDecimal getFareAndChargesSum() {
		BigDecimal chargesSum = BigDecimal.valueOf(this.charges.stream().mapToDouble(ChargeDTO::getAmount).sum())
				.setScale(2, RoundingMode.HALF_UP);
		return this.getFareValue().add(chargesSum);
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public PassengerDTO getPassengerDTO() {
		return passengerDTO;
	}

	public void setPassengerDTO(PassengerDTO passengerDTO) {
		this.passengerDTO = passengerDTO;
	}

	public String getFareClass() {
		return fareClass;
	}

	public void setFareClass(String fareClass) {
		this.fareClass = fareClass;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMyIDBookingStatus() {
		return myIDBookingStatus;
	}

	public void setMyIDBookingStatus(String myIDBookingStatus) {
		this.myIDBookingStatus = myIDBookingStatus;
	}

	public String getCurrencyName() {
		return "CAD".equals(this.currencyIsocode) ? "Canadian Dollars" : "Unknown";
	}

	public void setPaxType(PaxType paxType) {
		this.paxType = paxType;
	}

	public PaxType getPaxType() {
		return paxType;
	}
}
