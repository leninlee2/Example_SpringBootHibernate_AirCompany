package com.flyairnorth.integration.dto.search;

public class ChargeDTO {

	private Double amount;
	
	private String currencyIsocode;

	private String description;

	private String code;

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getCurrencyIsocode() {
		return currencyIsocode;
	}

	public void setCurrencyIsocode(String currencyIsocode) {
		this.currencyIsocode = currencyIsocode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
}
