package com.flyairnorth.integration.dto.booking;

import java.util.ArrayList;
import java.util.List;

import com.flyairnorth.integration.enumerator.AgeQualifyingCode;
import com.flyairnorth.integration.enumerator.GenderOptions;

public class BookingPassengerDTO {

	private int quantity;
	private AgeQualifyingCode type;
	private String firstName;
	private String middleName;
	private String lastName;
	private List<String> emails;
	private List<AddressDTO> addresses;
	private List<TelephoneDTO> telephones;
	private GenderOptions gender;
	private MyIDDTO myID;
	private String travelerRefNumber;

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public AgeQualifyingCode getType() {
		return type;
	}

	public void setType(AgeQualifyingCode type) {
		this.type = type;
	}

	public List<String> getEmails() {
		if (this.emails == null) {
			emails = new ArrayList<>();
		}
		return emails;
	}

	public void setEmails(List<String> emails) {
		this.emails = emails;
	}

	public List<AddressDTO> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<AddressDTO> addresses) {
		this.addresses = addresses;
	}

	public List<TelephoneDTO> getTelephones() {
		if (this.telephones == null) {
			this.telephones = new ArrayList<>();
		}
		return telephones;
	}

	public void setTelephones(List<TelephoneDTO> telephones) {
		this.telephones = telephones;
	}

	public String getFirstName() {
		if (this.firstName == null)
			return "";
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		if (this.middleName == null)
			return "";
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		if (this.lastName == null)
			return "";
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public GenderOptions getGender() {
		return gender;
	}

	public void setGender(GenderOptions gender) {
		this.gender = gender;
	}

	public void setMyID(MyIDDTO myID) {
		this.myID = myID;
	}

	public MyIDDTO getMyID() {
		return myID;
	}

	public String getTravelerRefNumber() {
		return travelerRefNumber;
	}

	public void setTravelerRefNumber(String travelerRefNumber) {
		this.travelerRefNumber = travelerRefNumber;
	}
}
