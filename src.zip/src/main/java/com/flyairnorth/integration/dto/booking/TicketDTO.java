package com.flyairnorth.integration.dto.booking;

public class TicketDTO {

	private String ticketNumber;
	private String passengerReference;
	private String segmentReference;

	public String getTicketNumber() {
		return ticketNumber;
	}

	public void setTicketNumber(String ticketNumber) {
		this.ticketNumber = ticketNumber;
	}

	public String getPassengerReference() {
		return passengerReference;
	}

	public void setPassengerReference(String passengerReference) {
		this.passengerReference = passengerReference;
	}

	public String getSegmentReference() {
		return segmentReference;
	}

	public void setSegmentReference(String segmentReference) {
		this.segmentReference = segmentReference;
	}
}
