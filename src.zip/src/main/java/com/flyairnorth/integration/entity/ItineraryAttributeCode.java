package com.flyairnorth.integration.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "itineraryattributecode")
public class ItineraryAttributeCode {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "itineraryattributeclass_id")
	private ItineraryAttributeClass itineraryAttributeClass;

	@Column(name = "attributename", length = 100)
	private String attributeName;

	@Column(name = "attributedescription", length = 1000)
	private String attributeDescription;

	@Column(name = "attributename_short", length = 100)
	private String attributeNameShort;

	@Column(name = "attributeunit", length = 45)
	private String attributeUnit;

	@Column(name = "attributecode", length = 45)
	private String attributeCode;

	@Column(name = "createuserid", length = 45)
	private String createUserId;

	@Column(name = "createdatetime")
	private LocalDateTime createDateTime;

	@Column(name = "updateuserid", length = 45)
	private String updateUserId;

	@Column(name = "updatedatetime")
	private LocalDateTime updateDateTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ItineraryAttributeClass getItineraryAttributeClass() {
		return itineraryAttributeClass;
	}

	public void setItineraryAttributeClass(ItineraryAttributeClass itineraryAttributeClass) {
		this.itineraryAttributeClass = itineraryAttributeClass;
	}

	public String getAttributeName() {
		return attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	public String getAttributeDescription() {
		return attributeDescription;
	}

	public void setAttributeDescription(String attributeDescription) {
		this.attributeDescription = attributeDescription;
	}

	public String getAttributeNameShort() {
		return attributeNameShort;
	}

	public void setAttributeNameShort(String attributeNameShort) {
		this.attributeNameShort = attributeNameShort;
	}

	public String getAttributeUnit() {
		return attributeUnit;
	}

	public void setAttributeUnit(String attributeUnit) {
		this.attributeUnit = attributeUnit;
	}

	public String getAttributeCode() {
		return attributeCode;
	}

	public void setAttributeCode(String attributeCode) {
		this.attributeCode = attributeCode;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public LocalDateTime getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(LocalDateTime createDateTime) {
		this.createDateTime = createDateTime;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public LocalDateTime getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(LocalDateTime updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
}
