package com.flyairnorth.integration.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "itinerary_number")
public class ItineraryNumber {

	@Id
	@Column(name = "find", length = 1)
	private String find;

	@Column(name = "inum", length = 8)
	private String inum;

	public String getFind() {
		return find;
	}

	public void setFind(String find) {
		this.find = find;
	}

	public String getInum() {
		return inum;
	}

	public void setInum(String inum) {
		this.inum = inum;
	}
}
