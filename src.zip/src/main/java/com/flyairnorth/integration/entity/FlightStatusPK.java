package com.flyairnorth.integration.entity;

import java.io.Serializable;
import java.util.Date;

public class FlightStatusPK implements Serializable {
	
	private static final long serialVersionUID = -3594065679035032829L;

	protected String flight;
	
	protected Date fdate;
	
	public FlightStatusPK() {}

	public FlightStatusPK(String flight, Date fdate) {
		super();
		this.flight = flight;
		this.fdate = fdate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fdate == null) ? 0 : fdate.hashCode());
		result = prime * result + ((flight == null) ? 0 : flight.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FlightStatusPK other = (FlightStatusPK) obj;
		if (fdate == null) {
			if (other.fdate != null)
				return false;
		} else if (!fdate.equals(other.fdate))
			return false;
		if (flight == null) {
			if (other.flight != null)
				return false;
		} else if (!flight.equals(other.flight))
			return false;
		return true;
	}
}
