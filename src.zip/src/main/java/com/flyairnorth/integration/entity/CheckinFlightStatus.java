package com.flyairnorth.integration.entity;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import com.flyairnorth.integration.enumerator.CheckinStatus;
import com.flyairnorth.integration.enumerator.YesNo;

@Entity
@Table(name="checkin_flight_status")
public class CheckinFlightStatus {
	
	@Id
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "datetime")
	private Date datetime; 
	
	@Column(name = "username", length=17, nullable=false)
	private String username;
	
	@Column(name = "fdate")
	private LocalDate fdate;
	
	@Column(name = "flight", length=10)
	private String flight;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private CheckinStatus status;

	@Column(name = "comment", length = 255)
	private String comment;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "isOnline")
	private YesNo isOnline;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getDatetime() {
		return datetime;
	}

	public void setDatetime(Date datetime) {
		this.datetime = datetime;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public LocalDate getFdate() {
		return fdate;
	}

	public void setFdate(LocalDate fdate) {
		this.fdate = fdate;
	}

	public String getFlight() {
		return flight;
	}

	public void setFlight(String flight) {
		this.flight = flight;
	}

	public CheckinStatus getStatus() {
		return status;
	}

	public void setStatus(CheckinStatus status) {
		this.status = status;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public YesNo getIsOnline() {
		return isOnline;
	}

	public void setIsOnline(YesNo isOnline) {
		this.isOnline = isOnline;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CheckinFlightStatus other = (CheckinFlightStatus) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
