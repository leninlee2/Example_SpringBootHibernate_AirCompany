package com.flyairnorth.integration.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ticket_number")
public class TicketNumber {
	
	@Id
	@Column(name = "find", length = 1)
	private String find;

	@Column(name = "transnum", length = 8)
	private String transactionNumber;

	public String getFind() {
		return find;
	}

	public void setFind(String find) {
		this.find = find;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}
}
