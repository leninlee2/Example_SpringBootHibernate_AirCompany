package com.flyairnorth.integration.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.flyairnorth.integration.enumerator.YesNo;

@Entity
@IdClass(EmployeeTravelPK.class)
@Table(name = "employee_travel")
public class EmployeeTravel {

	@Column(name = "emp_no", length = 10)
	private String empNo;

	@Id
	@Column(name = "emp_first", length = 45)
	private String empFirst;

	@Id
	@Column(name = "emp_middle", length = 45)
	private String empMiddle;

	@Id
	@Column(name = "emp_last", length = 45)
	private String empLast;

	@Column(name = "emp_doj")
	private LocalDate empDoj;

	@Column(name = "street", length = 50)
	private String street;

	@Column(name = "city", length = 45)
	private String city;

	@Column(name = "province", length = 5)
	private String province;

	@Column(name = "country", length = 3)
	private String country;

	@Column(name = "postal", length = 10)
	private String postal;

	@Column(name = "homephone", length = 45)
	private String homephone;

	@Column(name = "workphone", length = 45)
	private String workphone;

	@Column(name = "awayphone", length = 45)
	private String awayphone;

	@Column(name = "active", length = 1)
	@Enumerated(EnumType.STRING)
	private YesNo active;

	@Column(name = "status", length = 10)
	private String status;

	@Column(name = "comment", length = 250)
	private String comment;

	@Column(name = "buddy_passes")
	private Integer buddyPasses;

	@Column(name = "passenger_id", length = 45)
	private String passengerId;

	@Column(name = "email", length = 65)
	private String email;

	@Column(name = "company", length = 45)
	private String company;

	@Column(name = "department", length = 50)
	private String department;
	
	@Column(name = "priority", length = 10)
	private String priority;

	public String getEmpNo() {
		return empNo;
	}

	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}

	public String getEmpFirst() {
		return empFirst;
	}

	public void setEmpFirst(String empFirst) {
		this.empFirst = empFirst;
	}

	public String getEmpMiddle() {
		return empMiddle;
	}

	public void setEmpMiddle(String empMiddle) {
		this.empMiddle = empMiddle;
	}

	public String getEmpLast() {
		return empLast;
	}

	public void setEmpLast(String empLast) {
		this.empLast = empLast;
	}

	public LocalDate getEmpDoj() {
		return empDoj;
	}

	public void setEmpDoj(LocalDate empDoj) {
		this.empDoj = empDoj;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPostal() {
		return postal;
	}

	public void setPostal(String postal) {
		this.postal = postal;
	}

	public String getHomephone() {
		return homephone;
	}

	public void setHomephone(String homephone) {
		this.homephone = homephone;
	}

	public String getWorkphone() {
		return workphone;
	}

	public void setWorkphone(String workphone) {
		this.workphone = workphone;
	}

	public String getAwayphone() {
		return awayphone;
	}

	public void setAwayphone(String awayphone) {
		this.awayphone = awayphone;
	}

	public YesNo getActive() {
		return active;
	}

	public void setActive(YesNo active) {
		this.active = active;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Integer getBuddyPasses() {
		return buddyPasses;
	}

	public void setBuddyPasses(Integer buddyPasses) {
		this.buddyPasses = buddyPasses;
	}

	public String getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(String passengerId) {
		this.passengerId = passengerId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}
}
