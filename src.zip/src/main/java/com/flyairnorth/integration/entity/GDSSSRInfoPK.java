package com.flyairnorth.integration.entity;

import java.io.Serializable;

public class GDSSSRInfoPK  implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected int id;
	
	public GDSSSRInfoPK() {
		
	}
	
	public GDSSSRInfoPK(int id) {
		super();
		this.id = id;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + 1;
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		
		return true;
	}

}
