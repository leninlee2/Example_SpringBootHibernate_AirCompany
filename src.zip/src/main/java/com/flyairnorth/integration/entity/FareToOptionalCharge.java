package com.flyairnorth.integration.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@Table(name = "fare_to_optional_charge")
@IdClass(FareToOptionalChargePK.class)
public class FareToOptionalCharge {
	
	@Id
	@Column(name = "fare_id")
	private Integer fareId;
	
	@Id
	@Column(name = "optional_charge_id")
	private Integer optionalChargeId;

	public Integer getFareId() {
		return fareId;
	}

	public void setFareId(Integer fareId) {
		this.fareId = fareId;
	}

	public Integer getOptionalChargeId() {
		return optionalChargeId;
	}

	public void setOptionalChargeId(Integer optionalChargeId) {
		this.optionalChargeId = optionalChargeId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fareId == null) ? 0 : fareId.hashCode());
		result = prime * result + ((optionalChargeId == null) ? 0 : optionalChargeId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FareToOptionalCharge other = (FareToOptionalCharge) obj;
		if (fareId == null) {
			if (other.fareId != null)
				return false;
		} else if (!fareId.equals(other.fareId))
			return false;
		if (optionalChargeId == null) {
			if (other.optionalChargeId != null)
				return false;
		} else if (!optionalChargeId.equals(other.optionalChargeId))
			return false;
		return true;
	}
}
