package com.flyairnorth.integration.entity;

import java.io.Serializable;

public class FaresRulesPK implements Serializable{

	private static final long serialVersionUID = 1879827555415530265L;

	protected String fareClass;

	protected String fareCode;
	
	public FaresRulesPK() {}
	
	public FaresRulesPK(String fareClass, String fareCode) {
		this.fareClass = fareClass;
		this.fareCode = fareCode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fareClass == null) ? 0 : fareClass.hashCode());
		result = prime * result + ((fareCode == null) ? 0 : fareCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FaresRulesPK other = (FaresRulesPK) obj;
		if (fareClass == null) {
			if (other.fareClass != null)
				return false;
		} else if (!fareClass.equals(other.fareClass))
			return false;
		if (fareCode == null) {
			if (other.fareCode != null)
				return false;
		} else if (!fareCode.equals(other.fareCode))
			return false;
		return true;
	}
}
