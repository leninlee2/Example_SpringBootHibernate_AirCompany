package com.flyairnorth.integration.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "bookingtype")
public class BookingType {

	@Id
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "bookingsourceid")
	private BookingSource bookingSoure;

	@Column(name = "bookingtype", length = 100)
	private String bookingType;

	@Column(name = "bookingtype_short", length = 45)
	private String bookingTypeShort;

	@Column(name = "shortcode", length = 10)
	private String shortCode;

	@Column(name = "description", length = 2000)
	private String description;

	@Column(name = "createuserid", length = 45)
	private String createUserId;

	@Column(name = "createdatetime")
	private LocalDateTime createDateTime;

	@Column(name = "updateuserid", length = 45)
	private String updateUserId;

	@Column(name = "updatedatetime")
	private LocalDateTime updateDateTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public BookingSource getBookingSoure() {
		return bookingSoure;
	}

	public void setBookingSoure(BookingSource bookingSoure) {
		this.bookingSoure = bookingSoure;
	}

	public String getBookingType() {
		return bookingType;
	}

	public void setBookingType(String bookingType) {
		this.bookingType = bookingType;
	}

	public String getBookingTypeShort() {
		return bookingTypeShort;
	}

	public void setBookingTypeShort(String bookingTypeShort) {
		this.bookingTypeShort = bookingTypeShort;
	}

	public String getShortCode() {
		return shortCode;
	}

	public void setShortCode(String shortCode) {
		this.shortCode = shortCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public LocalDateTime getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(LocalDateTime createDateTime) {
		this.createDateTime = createDateTime;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public LocalDateTime getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(LocalDateTime updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
}
