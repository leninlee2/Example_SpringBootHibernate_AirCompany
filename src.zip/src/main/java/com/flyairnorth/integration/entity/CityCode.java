package com.flyairnorth.integration.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import com.flyairnorth.integration.enumerator.YesNo;

@Entity
@Table(name = "citycode")
public class CityCode {

	@Id
	@Column(name = "citycode", length = 3, nullable = false)
	private String cityCode;

	@Column(name = "citydesc", length = 31)
	private String cityDesc;

	@Column(name = "address", length = 255)
	private String address;

	@Enumerated(EnumType.STRING)
	@Column(name = "active")
	private YesNo active;

	@Enumerated(EnumType.STRING)
	@Column(name = "active_cargo")
	private YesNo activeCargo;

	@Column(name = "state", length = 3)
	private String state;

	@Column(name = "suffixcode", length = 3)
	private String suffixCode;

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getCityDesc() {
		return cityDesc;
	}

	public void setCityDesc(String cityDesc) {
		this.cityDesc = cityDesc;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public YesNo getActive() {
		return active;
	}

	public void setActive(YesNo active) {
		this.active = active;
	}

	public YesNo getActiveCargo() {
		return activeCargo;
	}

	public void setActiveCargo(YesNo activeCargo) {
		this.activeCargo = activeCargo;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getSuffixCode() {
		return suffixCode;
	}

	public void setSuffixCode(String suffixCode) {
		this.suffixCode = suffixCode;
	}
}
