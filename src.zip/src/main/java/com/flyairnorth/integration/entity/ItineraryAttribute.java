package com.flyairnorth.integration.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "itineraryattribute")
public class ItineraryAttribute {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "inum", length = 8)
	private String inum;

	@Column(name = "pnr", length = 45)
	private String pnr;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "itineraryattributeclass_id")
	private ItineraryAttributeClass itineraryAttributeClass;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "itineraryattributecode_id")
	private ItineraryAttributeCode itineraryAttributeCode;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "itineraryattributevalue_id")
	private ItineraryAttributeValue itineraryAttributeValue;

	@Column(name = "attributevalue_str", length = 1000)
	private String attributeValueStr;

	@Column(name = "attributedescription", length = 2000)
	private String attributeDescription;

	@Column(name = "createuserid", length = 45)
	private String createUserId;

	@Column(name = "createdatetime")
	private LocalDateTime createDateTime;

	@Column(name = "updateuserid", length = 45)
	private String updateUserId;

	@Column(name = "updatedatetime")
	private LocalDateTime updateDateTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getInum() {
		return inum;
	}

	public void setInum(String inum) {
		this.inum = inum;
	}

	public String getPnr() {
		return pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public ItineraryAttributeClass getItineraryAttributeClass() {
		return itineraryAttributeClass;
	}

	public void setItineraryAttributeClass(ItineraryAttributeClass itineraryAttributeClass) {
		this.itineraryAttributeClass = itineraryAttributeClass;
	}

	public ItineraryAttributeCode getItineraryAttributeCode() {
		return itineraryAttributeCode;
	}

	public void setItineraryAttributeCode(ItineraryAttributeCode itineraryAttributeCode) {
		this.itineraryAttributeCode = itineraryAttributeCode;
	}

	public ItineraryAttributeValue getItineraryAttributeValue() {
		return itineraryAttributeValue;
	}

	public void setItineraryAttributeValue(ItineraryAttributeValue itineraryAttributeValue) {
		this.itineraryAttributeValue = itineraryAttributeValue;
	}

	public String getAttributeValueStr() {
		return attributeValueStr;
	}

	public void setAttributeValueStr(String attributeValueStr) {
		this.attributeValueStr = attributeValueStr;
	}

	public String getAttributeDescription() {
		return attributeDescription;
	}

	public void setAttributeDescription(String attributeDescription) {
		this.attributeDescription = attributeDescription;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public LocalDateTime getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(LocalDateTime createDateTime) {
		this.createDateTime = createDateTime;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public LocalDateTime getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(LocalDateTime updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
}
