package com.flyairnorth.integration.entity;

import java.io.Serializable;

public class TLogPK  implements Serializable{
	
	private static final long serialVersionUID = 5598256901863234216L;
	protected String tNum;
	protected Integer tnumCntr;
	
	public TLogPK() {
	}

	public TLogPK(String tNum, Integer tNumCntr) {
		super();
		this.tNum = tNum;
		this.tnumCntr = tNumCntr;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((tNum == null) ? 0 : tNum.hashCode());
		result = prime * result + ((tnumCntr == null) ? 0 : tnumCntr.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TLogPK other = (TLogPK) obj;
		if (tNum == null) {
			if (other.tNum != null)
				return false;
		} else if (!tNum.equals(other.tNum))
			return false;
		if (tnumCntr == null) {
			if (other.tnumCntr != null)
				return false;
		} else if (!tnumCntr.equals(other.tnumCntr))
			return false;
		return true;
	}
}
