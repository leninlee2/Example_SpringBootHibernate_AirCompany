package com.flyairnorth.integration.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

public class FlightsPK implements Serializable{

	private static final long serialVersionUID = 8160032954493139374L;

	protected String flight;
	protected LocalDateTime tstart;
	protected LocalDateTime tend;
	protected Integer leg1;
	
	public FlightsPK() {}

	public FlightsPK(String flight, LocalDateTime tstart, LocalDateTime tend, Integer leg1) {
		super();
		this.flight = flight;
		this.tstart = tstart;
		this.tend = tend;
		this.leg1 = leg1;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((flight == null) ? 0 : flight.hashCode());
		result = prime * result + ((leg1 == null) ? 0 : leg1.hashCode());
		result = prime * result + ((tend == null) ? 0 : tend.hashCode());
		result = prime * result + ((tstart == null) ? 0 : tstart.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FlightsPK other = (FlightsPK) obj;
		if (flight == null) {
			if (other.flight != null)
				return false;
		} else if (!flight.equals(other.flight))
			return false;
		if (leg1 == null) {
			if (other.leg1 != null)
				return false;
		} else if (!leg1.equals(other.leg1))
			return false;
		if (tend == null) {
			if (other.tend != null)
				return false;
		} else if (!tend.equals(other.tend))
			return false;
		if (tstart == null) {
			if (other.tstart != null)
				return false;
		} else if (!tstart.equals(other.tstart))
			return false;
		return true;
	}
}
