package com.flyairnorth.integration.entity;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.flyairnorth.integration.enumerator.YesNo;

@Entity
@IdClass(BookedFlightsPK.class)
@Table(name = "booked_flights")
public class BookedFlights {
	
//	@Id
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
//	private Long id;

	@Temporal(TemporalType.TIMESTAMP)
//	@Column(name = "createdatetime")
	@Column(name = "datetime")
	private Date createDatetime;

	@Column(name = "agent", length = 17)
	private String agent;

	@Id
	@Column(name = "flight", length = 10)
	private String flight;

	@Id
	@Column(name = "fdate")
	private LocalDate fDate;

	@Column(name = "fdate1")
	private LocalDate fDate1;

	@Column(name = "fdate2")
	private LocalDate fDate2;

	@Column(name = "fdate3")
	private LocalDate fDate3;

	@Column(name = "fdate4")
	private LocalDate fDate4;

	@Column(name = "fdate5")
	private LocalDate fDate5;

	@Column(name = "leg1", nullable = true)
	private Integer leg1;

	@Column(name = "leg2", nullable = true)
	private Integer leg2;

	@Column(name = "leg3", nullable = true)
	private Integer leg3;

	@Column(name = "leg4", nullable = true)
	private Integer leg4;

	@Column(name = "leg5", nullable = true)
	private Integer leg5;

	@Column(name = "avgbagnum", nullable = true)
	private Double avgBagNum;

	@Column(name = "avgbagweight")
	private Double avgBagWeight;

	@Column(name = "stops", length = 3)
	private String stops;

	@Column(name = "equip", length = 3)
	private String equip;

	@Enumerated(EnumType.STRING)
	@Column(name = "international")
	private YesNo international;

	@Enumerated(EnumType.STRING)
	@Column(name = "seatpack")
	private YesNo seatPack;

//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "flight_id")
//	private Flights flights;

//	@Enumerated(EnumType.STRING)
//	@Column(name = "schedule")
//	private YesNo schedule;

	public String getAgent() {
		return agent;
	}

	public void setAgent(String agent) {
		this.agent = agent;
	}

	public String getFlight() {
		return flight;
	}

	public void setFlight(String flight) {
		this.flight = flight;
	}

	public LocalDate getfDate() {
		return fDate;
	}

	public void setfDate(LocalDate fDate) {
		this.fDate = fDate;
	}

	public LocalDate getfDate1() {
		return fDate1;
	}

	public void setfDate1(LocalDate fDate1) {
		this.fDate1 = fDate1;
	}

	public LocalDate getfDate2() {
		return fDate2;
	}

	public void setfDate2(LocalDate fDate2) {
		this.fDate2 = fDate2;
	}

	public LocalDate getfDate3() {
		return fDate3;
	}

	public void setfDate3(LocalDate fDate3) {
		this.fDate3 = fDate3;
	}

	public LocalDate getfDate4() {
		return fDate4;
	}

	public void setfDate4(LocalDate fDate4) {
		this.fDate4 = fDate4;
	}

	public LocalDate getfDate5() {
		return fDate5;
	}

	public void setfDate5(LocalDate fDate5) {
		this.fDate5 = fDate5;
	}

	public Integer getLeg1() {
		return leg1;
	}

	public void setLeg1(Integer leg1) {
		this.leg1 = leg1;
	}

	public Integer getLeg2() {
		return leg2;
	}

	public void setLeg2(Integer leg2) {
		this.leg2 = leg2;
	}

	public Integer getLeg3() {
		return leg3;
	}

	public void setLeg3(Integer leg3) {
		this.leg3 = leg3;
	}

	public Integer getLeg4() {
		return leg4;
	}

	public void setLeg4(Integer leg4) {
		this.leg4 = leg4;
	}

	public Integer getLeg5() {
		return leg5;
	}

	public void setLeg5(Integer leg5) {
		this.leg5 = leg5;
	}

	public Double getAvgBagNum() {
		return avgBagNum;
	}

	public void setAvgBagNum(Double avgBagNum) {
		this.avgBagNum = avgBagNum;
	}

	public Double getAvgBagWeight() {
		return avgBagWeight;
	}

	public void setAvgBagWeight(Double avgBagWeight) {
		this.avgBagWeight = avgBagWeight;
	}

	public String getStops() {
		return stops;
	}

	public void setStops(String stops) {
		this.stops = stops;
	}

	public String getEquip() {
		return equip;
	}

	public void setEquip(String equip) {
		this.equip = equip;
	}

	public YesNo getInternational() {
		return international;
	}

	public void setInternational(YesNo international) {
		this.international = international;
	}

	public YesNo getSeatPack() {
		return seatPack;
	}

	public void setSeatPack(YesNo seatPack) {
		this.seatPack = seatPack;
	}

//	public Long getId() {
//		return id;
//	}
//
//	public void setId(Long id) {
//		this.id = id;
//	}

//	public Flights getFlights() {
//		return flights;
//	}
//
//	public void setFlights(Flights flights) {
//		this.flights = flights;
//	}

//	public YesNo getSchedule() {
//		return schedule;
//	}
//
//	public void setSchedule(YesNo schedule) {
//		this.schedule = schedule;
//	}

	public Date getCreateDatetime() {
		return createDatetime;
	}

	public void setCreateDatetime(Date createDatetime) {
		this.createDatetime = createDatetime;
	}

	@Override
	public BookedFlights clone() {
		BookedFlights dolly = new BookedFlights();

		dolly.flight = flight;
		dolly.fDate = this.fDate;
		dolly.fDate1 = this.fDate1;
		dolly.fDate2 = this.fDate2;
		dolly.fDate3 = this.fDate3;
		dolly.fDate4 = this.fDate4;
		dolly.fDate5 = this.fDate5;
		dolly.leg1 = this.leg1;
		dolly.leg2 = this.leg2;
		dolly.leg3 = this.leg3;
		dolly.leg4 = this.leg4;
		dolly.leg5 = this.leg5;
		dolly.avgBagNum = this.avgBagNum;
		dolly.avgBagWeight = this.avgBagWeight;
		dolly.stops = this.stops;
		dolly.equip = this.equip;
		dolly.international = this.international;
		dolly.seatPack = this.seatPack;
//		dolly.flights = this.flights;
//		dolly.schedule = this.schedule;

		return dolly;
	}
}