package com.flyairnorth.integration.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@IdClass(EmployeeTravelPersonPK.class)
@Table(name = "employee_travel_person")
public class EmployeeTravelPerson {
	
	@Id
	@Column(name = "passenger_id", length = 10)
	private String passengerId;

	@Id
	@Column(name = "type", length = 10)
	private String type;

	@Id
	@Column(name = "first", length = 45)
	private String first;

	@Column(name = "middle", length = 45)
	private String middle;

	@Id
	@Column(name = "last", length = 45)
	private String last;

	@Column(name = "dob")
	private LocalDate dob;

	public String getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(String passengerId) {
		this.passengerId = passengerId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getFirst() {
		return first;
	}

	public void setFirst(String first) {
		this.first = first;
	}

	public String getMiddle() {
		return middle;
	}

	public void setMiddle(String middle) {
		this.middle = middle;
	}

	public String getLast() {
		return last;
	}

	public void setLast(String last) {
		this.last = last;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
}
