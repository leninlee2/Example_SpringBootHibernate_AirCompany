package com.flyairnorth.integration.entity;

import java.io.Serializable;

public class FareToOptionalChargePK implements Serializable{

	private static final long serialVersionUID = 3233882575594569694L;

	protected Integer fareId;

	protected Integer optionalChargeId;

	public FareToOptionalChargePK() {}

	public FareToOptionalChargePK(Integer fareId, Integer optionalChargeId) {
		super();
		this.fareId = fareId;
		this.optionalChargeId = optionalChargeId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fareId == null) ? 0 : fareId.hashCode());
		result = prime * result + ((optionalChargeId == null) ? 0 : optionalChargeId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FareToOptionalChargePK other = (FareToOptionalChargePK) obj;
		if (fareId == null) {
			if (other.fareId != null)
				return false;
		} else if (!fareId.equals(other.fareId))
			return false;
		if (optionalChargeId == null) {
			if (other.optionalChargeId != null)
				return false;
		} else if (!optionalChargeId.equals(other.optionalChargeId))
			return false;
		return true;
	}
}