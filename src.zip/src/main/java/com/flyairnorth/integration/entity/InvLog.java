package com.flyairnorth.integration.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "invlog")
public class InvLog {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "flightnum", length = 10)
	private String flightNum;

	@Column(name = "fdate")
	private LocalDateTime fDate;

	@Column(name = "fromCode", length = 3, nullable = true)
	private String fromCode;

	@Column(name = "tocode", length = 3, nullable = true)
	private String toCode;

	@Column(name = "createUserid", length = 30, nullable = true)
	private String createUserId;

	@Column(name = "createDateTime", nullable = true)
	private LocalDateTime createDateTime;

	@Column(name = "comment", length = 500, nullable = true)
	private String comment;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFlightNum() {
		return flightNum;
	}

	public void setFlightNum(String flightNum) {
		this.flightNum = flightNum;
	}

	public LocalDateTime getfDate() {
		return fDate;
	}

	public void setfDate(LocalDateTime fDate) {
		this.fDate = fDate;
	}

	public String getFromCode() {
		return fromCode;
	}

	public void setFromCode(String fromCode) {
		this.fromCode = fromCode;
	}

	public String getToCode() {
		return toCode;
	}

	public void setToCode(String toCode) {
		this.toCode = toCode;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public LocalDateTime getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(LocalDateTime createDateTime) {
		this.createDateTime = createDateTime;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
}
