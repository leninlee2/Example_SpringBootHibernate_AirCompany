package com.flyairnorth.integration.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.flyairnorth.integration.enumerator.YesNo;

@Entity
@Table(name = "fare_seats_inventory")
@IdClass(FareSeatsInventoryPK.class)
public class FareSeatsInventory {

	@Id
	@Column(name = "flight", length = 10)
	private String flight;

	@Id
	@Column(name = "fdate")
	private LocalDate fDate;

	@Id
	@Column(name = "farecode", length = 20)
	private String fareCode;

	@Column(name = "seats")
	private Integer seats;

	@Enumerated(EnumType.STRING)
	@Column(name = "avs_update")
	private YesNo avsUpdate;

	public String getFlight() {
		return flight;
	}

	public void setFlight(String flight) {
		this.flight = flight;
	}

	public LocalDate getfDate() {
		return fDate;
	}

	public void setfDate(LocalDate fDate) {
		this.fDate = fDate;
	}

	public String getFareCode() {
		return fareCode;
	}

	public void setFareCode(String fareCode) {
		this.fareCode = fareCode;
	}

	public Integer getSeats() {
		return seats;
	}

	public void setSeats(Integer seats) {
		this.seats = seats;
	}

	public YesNo getAvsUpdate() {
		return avsUpdate;
	}

	public void setAvsUpdate(YesNo avsUpdate) {
		this.avsUpdate = avsUpdate;
	}
}
