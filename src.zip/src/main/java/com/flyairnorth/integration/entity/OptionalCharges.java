package com.flyairnorth.integration.entity;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.flyairnorth.integration.enumerator.YesNo;

@Entity
@Table(name = "optional_charges")
public class OptionalCharges {

	@Id
	@Column(name = "id")
	private Integer id;

	@Column(name = "ordering")
	private Integer ordering;

	@Column(name = "description", length = 60)
	private String description;

	@Column(name = "code", length = 10)
	private String code;

	@Column(name = "amount", precision = 7, scale = 2)
	private Double amount;

	@Column(name = "start")
	@Temporal(TemporalType.DATE)
	private Date start;

	@Column(name = "end")
	@Temporal(TemporalType.DATE)
	private Date end;

	@Column(name = "fdate_start")
	private LocalDate fDateStart;

	@Column(name = "fdate_end")
	private LocalDate fDateEnd;

	@Column(name = "start2")
	private LocalDate start2;

	@Column(name = "end2")
	private LocalDate end2;

	@Column(name = "fdate_start2")
	private LocalDate fDateStart2;

	@Column(name = "fdate_end2")
	private LocalDate fDateEnd2;

	@Column(name = "amount2", precision = 7, scale = 2)
	private Double amount2;

	@Column(name = "isocode", length = 3)
	private String isoCode;

	@Enumerated(EnumType.STRING)
	@Column(name = "showaftergst")
	private YesNo showAfterGST;

	@Column(name = "gstexmpt", precision = 7, scale = 2)
	private Double gstExmpt;

	@Enumerated(EnumType.STRING)
	@Column(name = "active")
	private YesNo active;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_update")
	private Date lastUpdate;

	@Column(name = "update_agent", length = 25)
	private String updateAgent;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getOrdering() {
		return ordering;
	}

	public void setOrdering(Integer ordering) {
		this.ordering = ordering;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Date getStart() {
		return start;
	}

	public void setStart(Date start) {
		this.start = start;
	}

	public Date getEnd() {
		return end;
	}

	public void setEnd(Date end) {
		this.end = end;
	}

	public LocalDate getfDateStart() {
		return fDateStart;
	}

	public void setfDateStart(LocalDate fDateStart) {
		this.fDateStart = fDateStart;
	}

	public LocalDate getfDateEnd() {
		return fDateEnd;
	}

	public void setfDateEnd(LocalDate fDateEnd) {
		this.fDateEnd = fDateEnd;
	}

	public LocalDate getStart2() {
		return start2;
	}

	public void setStart2(LocalDate start2) {
		this.start2 = start2;
	}

	public LocalDate getEnd2() {
		return end2;
	}

	public void setEnd2(LocalDate end2) {
		this.end2 = end2;
	}

	public LocalDate getfDateStart2() {
		return fDateStart2;
	}

	public void setfDateStart2(LocalDate fDateStart2) {
		this.fDateStart2 = fDateStart2;
	}

	public LocalDate getfDateEnd2() {
		return fDateEnd2;
	}

	public void setfDateEnd2(LocalDate fDateEnd2) {
		this.fDateEnd2 = fDateEnd2;
	}

	public Double getAmount2() {
		return amount2;
	}

	public void setAmount2(Double amount2) {
		this.amount2 = amount2;
	}

	public String getIsoCode() {
		return isoCode;
	}

	public void setIsoCode(String isoCode) {
		this.isoCode = isoCode;
	}

	public YesNo getShowAfterGST() {
		return showAfterGST;
	}

	public void setShowAfterGST(YesNo showAfterGST) {
		this.showAfterGST = showAfterGST;
	}

	public Double getGstExmpt() {
		return gstExmpt;
	}

	public void setGstExmpt(Double gstExmpt) {
		this.gstExmpt = gstExmpt;
	}

	public YesNo getActive() {
		return active;
	}

	public void setActive(YesNo active) {
		this.active = active;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public String getUpdateAgent() {
		return updateAgent;
	}

	public void setUpdateAgent(String updateAgent) {
		this.updateAgent = updateAgent;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OptionalCharges other = (OptionalCharges) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
