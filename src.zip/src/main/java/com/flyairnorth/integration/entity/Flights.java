package com.flyairnorth.integration.entity;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.flyairnorth.integration.enumerator.YesNo;

@Entity
@IdClass(FlightsPK.class)
@Table(name = "flights")
public class Flights  {

//	@Id
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
//	private Long id;

//	@Column(name = "createdatetime")
	@Column(name = "datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createDatetime;

	@Column(name = "dagent")
	private String dagent;

	@Column(name = "flight")
	private String flight;

	@Enumerated(EnumType.STRING)
	@Column(name = "monday", length = 1)
	private YesNo monday;

	@Enumerated(EnumType.STRING)
	@Column(name = "tuesday", length = 1)
	private YesNo tuesday;

	@Enumerated(EnumType.STRING)
	@Column(name = "wednesday", length = 1)
	private YesNo wednesday;

	@Enumerated(EnumType.STRING)
	@Column(name = "thursday", length = 1)
	private YesNo thursday;

	@Enumerated(EnumType.STRING)
	@Column(name = "friday", length = 1)
	private YesNo friday;

	@Enumerated(EnumType.STRING)
	@Column(name = "saturday", length = 1)
	private YesNo saturday;

	@Enumerated(EnumType.STRING)
	@Column(name = "sunday", length = 1)
	private YesNo sunday;

	@Id
	@Column(name = "tstart")
	private LocalDateTime tstart;

	@Id
	@Column(name = "tend")
	private LocalDateTime tend;

	@Id
	@Column(name = "leg1", nullable=false)
	private Integer leg1;

	@Column(name = "leg2")
	private Integer leg2;

	@Column(name = "leg3")
	private Integer leg3;

	@Column(name = "leg4")
	private Integer leg4;

	@Column(name = "leg5")
	private Integer leg5;

	@Column(name = "meals", length = 3)
	private String meals;

	@Column(name = "stops", length = 3)
	private String stops;

	@Column(name = "equip", length = 3)
	private String equip;

	@Column(name = "avgbagnum")
	private Double avgbagnum;

	@Column(name = "avgbagweight")
	private Double avgbagweight;

	@Column(name = "days1")
	private Integer days1;

	@Column(name = "days2")
	private Integer days2;

	@Column(name = "days3")
	private Integer days3;

	@Column(name = "days4")
	private Integer days4;

	@Column(name = "days5")
	private Integer days5;

	@Enumerated(EnumType.STRING)
	@Column(name = "international")
	private YesNo international;

	@Enumerated(EnumType.STRING)
	@Column(name = "apisinput")
	private YesNo apisinput;

	@Enumerated(EnumType.STRING)
	@Column(name = "schedule")
	private YesNo schedule;

	@Enumerated(EnumType.STRING)
	@Column(name = "cancel")
	private YesNo cancel;

//	@Temporal(TemporalType.TIMESTAMP)
//	@Column(name = "updatedatetime")
//	private Date updateDatetime;
//
//	@Column(name = "updateuserid", length = 45)
//	private String updateUserId;
//
//	@Column(name = "break_schedule_ref")
//	private Integer breakScheduleRef;
//
//	@ManyToOne(fetch=FetchType.LAZY)
//	@JoinColumn(name = "seat_rule_id")
//	private SeatRule seatRule;

//	public Long getId() {
//		return id;
//	}
//
//	public void setId(Long id) {
//		this.id = id;
//	}

	public Date getCreateDatetime() {
		return createDatetime;
	}

	public void setCreateDatetime(Date createDatetime) {
		this.createDatetime = createDatetime;
	}

	public String getDagent() {
		return dagent;
	}

	public void setDagent(String dagent) {
		this.dagent = dagent;
	}

	public String getFlight() {
		return flight;
	}

	public void setFlight(String flight) {
		this.flight = flight;
	}

	public YesNo getMonday() {
		return monday;
	}

	public void setMonday(YesNo monday) {
		this.monday = monday;
	}

	public YesNo getTuesday() {
		return tuesday;
	}

	public void setTuesday(YesNo tuesday) {
		this.tuesday = tuesday;
	}

	public YesNo getWednesday() {
		return wednesday;
	}

	public void setWednesday(YesNo wednesday) {
		this.wednesday = wednesday;
	}

	public YesNo getThursday() {
		return thursday;
	}

	public void setThursday(YesNo thursday) {
		this.thursday = thursday;
	}

	public YesNo getFriday() {
		return friday;
	}

	public void setFriday(YesNo friday) {
		this.friday = friday;
	}

	public YesNo getSaturday() {
		return saturday;
	}

	public void setSaturday(YesNo saturday) {
		this.saturday = saturday;
	}

	public YesNo getSunday() {
		return sunday;
	}

	public void setSunday(YesNo sunday) {
		this.sunday = sunday;
	}

	public LocalDateTime getTstart() {
		return tstart;
	}

	public void setTstart(LocalDateTime tstart) {
		this.tstart = tstart;
	}

	public LocalDateTime getTend() {
		return tend;
	}

	public void setTend(LocalDateTime tend) {
		this.tend = tend;
	}

	public Integer getLeg1() {
		return leg1;
	}

	public void setLeg1(Integer leg1) {
		this.leg1 = leg1;
	}

	public Integer getLeg2() {
		return leg2;
	}

	public void setLeg2(Integer leg2) {
		this.leg2 = leg2;
	}

	public Integer getLeg3() {
		return leg3;
	}

	public void setLeg3(Integer leg3) {
		this.leg3 = leg3;
	}

	public Integer getLeg4() {
		return leg4;
	}

	public void setLeg4(Integer leg4) {
		this.leg4 = leg4;
	}

	public Integer getLeg5() {
		return leg5;
	}

	public void setLeg5(Integer leg5) {
		this.leg5 = leg5;
	}

	public String getMeals() {
		return meals;
	}

	public void setMeals(String meals) {
		this.meals = meals;
	}

	public String getStops() {
		return stops;
	}

	public void setStops(String stops) {
		this.stops = stops;
	}

	public String getEquip() {
		return equip;
	}

	public void setEquip(String equip) {
		this.equip = equip;
	}

	public Double getAvgbagnum() {
		return avgbagnum;
	}

	public void setAvgbagnum(Double avgbagnum) {
		this.avgbagnum = avgbagnum;
	}

	public Double getAvgbagweight() {
		return avgbagweight;
	}

	public void setAvgbagweight(Double avgbagweight) {
		this.avgbagweight = avgbagweight;
	}

	public Integer getDays1() {
		return days1;
	}

	public void setDays1(Integer days1) {
		this.days1 = days1;
	}

	public Integer getDays2() {
		return days2;
	}

	public void setDays2(Integer days2) {
		this.days2 = days2;
	}

	public Integer getDays3() {
		return days3;
	}

	public void setDays3(Integer days3) {
		this.days3 = days3;
	}

	public Integer getDays4() {
		return days4;
	}

	public void setDays4(Integer days4) {
		this.days4 = days4;
	}

	public Integer getDays5() {
		return days5;
	}

	public void setDays5(Integer days5) {
		this.days5 = days5;
	}

	public YesNo getInternational() {
		return international;
	}

	public void setInternational(YesNo international) {
		this.international = international;
	}

	public YesNo getApisinput() {
		return apisinput;
	}

	public void setApisinput(YesNo apisinput) {
		this.apisinput = apisinput;
	}

	public YesNo getSchedule() {
		return schedule;
	}

	public void setSchedule(YesNo schedule) {
		this.schedule = schedule;
	}

	public YesNo getCancel() {
		return cancel;
	}

	public void setCancel(YesNo cancel) {
		this.cancel = cancel;
	}

//	public Date getUpdateDatetime() {
//		return updateDatetime;
//	}
//
//	public void setUpdateDatetime(Date updateDatetime) {
//		this.updateDatetime = updateDatetime;
//	}
//
//	public String getUpdateUserId() {
//		return updateUserId;
//	}
//
//	public void setUpdateUserId(String updateUserId) {
//		this.updateUserId = updateUserId;
//	}
//
//	public Integer getBreakScheduleRef() {
//		return breakScheduleRef;
//	}
//
//	public void setBreakScheduleRef(Integer breakScheduleRef) {
//		this.breakScheduleRef = breakScheduleRef;
//	}
//
//	public SeatRule getSeatRule() {
//		return seatRule;
//	}
//
//	public void setSeatRule(SeatRule seatRule) {
//		this.seatRule = seatRule;
//	}

	@Override
	public Flights clone() {
		Flights dolly = new Flights();

		dolly.flight = this.flight;
		dolly.monday = this.monday;
		dolly.tuesday = this.tuesday;
		dolly.wednesday = this.wednesday;
		dolly.thursday = this.thursday;
		dolly.friday = this.friday;
		dolly.saturday = this.saturday;
		dolly.sunday = this.sunday;
		dolly.tstart = this.tstart;
		dolly.tend = this.tend;
		dolly.leg1 = this.leg1;
		dolly.leg2 = this.leg2;
		dolly.leg3 = this.leg3;
		dolly.leg4 = this.leg4;
		dolly.leg5 = this.leg5;
		dolly.meals = this.meals;
		dolly.stops = this.stops;
		dolly.equip = this.equip;
		dolly.avgbagnum = this.avgbagnum;
		dolly.avgbagweight = this.avgbagweight;
		dolly.days1 = this.days1;
		dolly.days2 = this.days2;
		dolly.days3 = this.days3;
		dolly.days4 = this.days4;
		dolly.days5 = this.days5;
		dolly.international = this.international;
		dolly.apisinput = this.apisinput;
		dolly.schedule = this.schedule;
		dolly.cancel = this.cancel;
//		dolly.breakScheduleRef = this.breakScheduleRef;
//		dolly.seatRule = this.seatRule;

		return dolly;
	}
}
