package com.flyairnorth.integration.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "fares_rules")
@IdClass(FaresRulesPK.class)
public class FaresRules {

	@Column(name="timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date timestamp; 

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public Integer getRuleCode() {
		return ruleCode;
	}

	public void setRuleCode(Integer ruleCode) {
		this.ruleCode = ruleCode;
	}

	public String getFareClass() {
		return fareClass;
	}

	public void setFareClass(String fareClass) {
		this.fareClass = fareClass;
	}

	public String getFareCode() {
		return fareCode;
	}

	public void setFareCode(String fareCode) {
		this.fareCode = fareCode;
	}

	public String getCreateAgent() {
		return createAgent;
	}

	public void setCreateAgent(String createAgent) {
		this.createAgent = createAgent;
	}

	public String getUpdateAgent() {
		return updateAgent;
	}

	public void setUpdateAgent(String updateAgent) {
		this.updateAgent = updateAgent;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "rule_code")
	private Integer ruleCode;

	@Id
	@Column(name = "fare_class", length=45)
	private String fareClass;

	@Id
	@Column(name = "fare_code" , length= 10)
	private String fareCode;

	@Column(name = "create_agent", length=25)
	private String createAgent;

	@Column(name = "update_agent")
	private String updateAgent;

	@Column(name = "update_time")
	@Temporal (TemporalType.TIMESTAMP)
	private Date updateTime;
}
