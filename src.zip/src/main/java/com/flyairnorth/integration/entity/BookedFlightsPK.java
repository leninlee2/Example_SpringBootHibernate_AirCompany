package com.flyairnorth.integration.entity;

import java.io.Serializable;
import java.time.LocalDate;

public class BookedFlightsPK implements Serializable{
	
	private static final long serialVersionUID = 3408783413554281779L;

	protected String flight;

	protected LocalDate fDate;
	
	public BookedFlightsPK() {
	}

	public BookedFlightsPK(String flight, LocalDate fDate) {
		super();
		this.flight = flight;
		this.fDate = fDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fDate == null) ? 0 : fDate.hashCode());
		result = prime * result + ((flight == null) ? 0 : flight.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookedFlightsPK other = (BookedFlightsPK) obj;
		if (fDate == null) {
			if (other.fDate != null)
				return false;
		} else if (!fDate.equals(other.fDate))
			return false;
		if (flight == null) {
			if (other.flight != null)
				return false;
		} else if (!flight.equals(other.flight))
			return false;
		return true;
	}
}