package com.flyairnorth.integration.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@Table(name = "gdsssrinfo")
//@IdClass(GDSSSRInfoPK.class)
public class GDSSSRInfo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Column(name = "pnr", length = 6)
	private String pnr;
	
	public String getPnr() {
		return pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public String getiNum() {
		return iNum;
	}

	public void setiNum(String iNum) {
		this.iNum = iNum;
	}

	public String gettNum() {
		return tNum;
	}

	public void settNum(String tNum) {
		this.tNum = tNum;
	}

	public Integer getTnumCntr() {
		return tnumCntr;
	}

	public void setTnumCntr(Integer tnumCntr) {
		this.tnumCntr = tnumCntr;
	}

	public String getSsr() {
		return ssr;
	}

	public void setSsr(String ssr) {
		this.ssr = ssr;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public LocalDateTime getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(LocalDateTime createDateTime) {
		this.createDateTime = createDateTime;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public LocalDateTime getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(LocalDateTime updateDateTime) {
		this.updateDateTime = updateDateTime;
	}

	@Column(name = "inum", length = 8)
	private String iNum;
	
	@Column(name = "tnum", length = 8)
	private String tNum;
	
	@Column(name = "tnumcntr")
	private Integer tnumCntr;
	
	@Column(name = "ssr")
	private String ssr;
	
	@Column(name = "createuserid", length = 45)
	private String createUserId;
	
	@Column(name = "createdatetime")
	private LocalDateTime createDateTime;
	
	@Column(name = "updateuserid", length = 45)
	private String updateUserId;
	
	@Column(name = "updatedatetime")
	private LocalDateTime updateDateTime;

}
