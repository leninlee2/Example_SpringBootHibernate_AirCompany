package com.flyairnorth.integration.entity;

import java.io.Serializable;

public class EmployeeTravelPK implements Serializable {

	private static final long serialVersionUID = -6459347381693454389L;
	protected String empFirst;
	protected String empMiddle;
	protected String empLast;

	public EmployeeTravelPK() {
	}

	public EmployeeTravelPK(String empFirst, String empMiddle, String empLast) {
		super();
		this.empFirst = empFirst;
		this.empMiddle = empMiddle;
		this.empLast = empLast;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((empFirst == null) ? 0 : empFirst.hashCode());
		result = prime * result + ((empLast == null) ? 0 : empLast.hashCode());
		result = prime * result + ((empMiddle == null) ? 0 : empMiddle.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeTravelPK other = (EmployeeTravelPK) obj;
		if (empFirst == null) {
			if (other.empFirst != null)
				return false;
		} else if (!empFirst.equals(other.empFirst))
			return false;
		if (empLast == null) {
			if (other.empLast != null)
				return false;
		} else if (!empLast.equals(other.empLast))
			return false;
		if (empMiddle == null) {
			if (other.empMiddle != null)
				return false;
		} else if (!empMiddle.equals(other.empMiddle))
			return false;
		return true;
	}
}
