package com.flyairnorth.integration.entity;

import java.io.Serializable;
import java.time.LocalDate;

public class BookedLegsPK implements Serializable {

	private static final long serialVersionUID = 6424754419795374483L;

	protected LocalDate fDate;

	protected Integer leg;
	
	public BookedLegsPK() {}

	public BookedLegsPK(LocalDate fDate, Integer leg) {
		super();
		this.fDate = fDate;
		this.leg = leg;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fDate == null) ? 0 : fDate.hashCode());
		result = prime * result + ((leg == null) ? 0 : leg.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookedLegsPK other = (BookedLegsPK) obj;
		if (fDate == null) {
			if (other.fDate != null)
				return false;
		} else if (!fDate.equals(other.fDate))
			return false;
		if (leg == null) {
			if (other.leg != null)
				return false;
		} else if (!leg.equals(other.leg))
			return false;
		return true;
	}
}
