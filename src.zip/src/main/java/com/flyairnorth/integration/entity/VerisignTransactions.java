package com.flyairnorth.integration.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "verisign_transactions")
public class VerisignTransactions {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "date")
	private LocalDateTime date;

	@Column(name = "pnref", length = 20)
	private String pnref;

	@Column(name = "amount", precision = 7, scale = 2)
	private BigDecimal amount;

	@Column(name = "authcode", length = 6)
	private String authcode;

	@Column(name = "description", length = 70)
	private String description;

	@Column(name = "tran_dt")
	private LocalDate tranDt;

	@Column(name = "comment", length = 50)
	private String comment;

	@Column(name = "inum", length = 8)
	private String inum;

	@Column(name = "cctype", length = 8)
	private String ccType;

	@Column(name = "source", length = 20)
	private String source;

	@Column(name = "awb_id", length = 11)
	private String awbId;

	@Column(name = "airpassnum", length = 8)
	private String airPassNum;

	@Column(name = "passenger_passnum", length = 8)
	private String passengerPassNum;

	@Column(name = "corpnum", length = 8)
	private String corpNum;

	@Column(name = "corpprepay_passnum", length = 8)
	private String corpPrepayPassNum;

	@Column(name = "trans_id")
	private Long transId;

	@Column(name = "ipaddress", length = 15)
	private String ipaddress;

	@Column(name = "avsresponse", length = 2)
	private String avsResponse;

	@Column(name = "cvdresponse", length = 2)
	private String cvdResponse;

	@Column(name = "ref_id", length = 20)
	private String refId;

	@Column(name = "trans_type", length = 255)
	private String transType;

	@Column(name = "trans_res_code", length = 3)
	private String transResCode;

	@Column(name = "trans_iso_code", length = 2)
	private String transIsoCode;

	@Column(name = "trans_res_message", length = 100)
	private String transResMessage;

	@Column(name = "trans_ref_num", length = 18)
	private String transRefNum;

	@Column(name = "trans_card_name", length = 50)
	private String transCardName;

	@Column(name = "trans_order_id", length = 50)
	private String transOrderId;

	@Column(name = "trans_txn", length = 50)
	private String transTxn;

	@Column(name = "order_id", length = 50)
	private String orderId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	public String getPnref() {
		return pnref;
	}

	public void setPnref(String pnref) {
		this.pnref = pnref;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getAuthcode() {
		return authcode;
	}

	public void setAuthcode(String authcode) {
		this.authcode = authcode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDate getTranDt() {
		return tranDt;
	}

	public void setTranDt(LocalDate tranDt) {
		this.tranDt = tranDt;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getInum() {
		return inum;
	}

	public void setInum(String inum) {
		this.inum = inum;
	}

	public String getCcType() {
		return ccType;
	}

	public void setCcType(String ccType) {
		this.ccType = ccType;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getAwbId() {
		return awbId;
	}

	public void setAwbId(String awbId) {
		this.awbId = awbId;
	}

	public String getAirPassNum() {
		return airPassNum;
	}

	public void setAirPassNum(String airPassNum) {
		this.airPassNum = airPassNum;
	}

	public String getPassengerPassNum() {
		return passengerPassNum;
	}

	public void setPassengerPassNum(String passengerPassNum) {
		this.passengerPassNum = passengerPassNum;
	}

	public String getCorpNum() {
		return corpNum;
	}

	public void setCorpNum(String corpNum) {
		this.corpNum = corpNum;
	}

	public String getCorpPrepayPassNum() {
		return corpPrepayPassNum;
	}

	public void setCorpPrepayPassNum(String corpPrepayPassNum) {
		this.corpPrepayPassNum = corpPrepayPassNum;
	}

	public Long getTransId() {
		return transId;
	}

	public void setTransId(Long transId) {
		this.transId = transId;
	}

	public String getIpaddress() {
		return ipaddress;
	}

	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

	public String getAvsResponse() {
		return avsResponse;
	}

	public void setAvsResponse(String avsResponse) {
		this.avsResponse = avsResponse;
	}

	public String getCvdResponse() {
		return cvdResponse;
	}

	public void setCvdResponse(String cvdResponse) {
		this.cvdResponse = cvdResponse;
	}

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getTransResCode() {
		return transResCode;
	}

	public void setTransResCode(String transResCode) {
		this.transResCode = transResCode;
	}

	public String getTransIsoCode() {
		return transIsoCode;
	}

	public void setTransIsoCode(String transIsoCode) {
		this.transIsoCode = transIsoCode;
	}

	public String getTransResMessage() {
		return transResMessage;
	}

	public void setTransResMessage(String transResMessage) {
		this.transResMessage = transResMessage;
	}

	public String getTransRefNum() {
		return transRefNum;
	}

	public void setTransRefNum(String transRefNum) {
		this.transRefNum = transRefNum;
	}

	public String getTransCardName() {
		return transCardName;
	}

	public void setTransCardName(String transCardName) {
		this.transCardName = transCardName;
	}

	public String getTransOrderId() {
		return transOrderId;
	}

	public void setTransOrderId(String transOrderId) {
		this.transOrderId = transOrderId;
	}

	public String getTransTxn() {
		return transTxn;
	}

	public void setTransTxn(String transTxn) {
		this.transTxn = transTxn;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
}
