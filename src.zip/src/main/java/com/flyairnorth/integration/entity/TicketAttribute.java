package com.flyairnorth.integration.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ticketattribute")
public class TicketAttribute {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "inum", length = 8, nullable = false)
	private String inum;

	@Column(name = "tnum", length = 8, nullable = false)
	private String tnum;

	@Column(name = "tnumcntr", nullable = false)
	private Integer tNumCntr;

	@ManyToOne(fetch= FetchType.LAZY)
	@JoinColumn(name = "attrributeid")
	private TicketAttributeCode ticketAttributeCode;

	@Column(name = "attributevalue", length = 45)
	private String attributeValue;

	@Column(name = "createuserid", length = 45)
	private String createUserId;

	@Column(name = "createdatetime")
	private LocalDateTime createDateTime;

	@Column(name = "updateuserid", length = 45)
	private String updateUserId;

	@Column(name = "updatedatetime")
	private LocalDateTime updateDateTime;

	public TicketAttribute() {
		super();
	}

	public TicketAttribute(String inum, String tnum, Integer tNumCntr, TicketAttributeCode ticketAttributeCode,
			String attributeValue, String createUserId, LocalDateTime createDateTime) {
		super();
		this.inum = inum;
		this.tnum = tnum;
		this.tNumCntr = tNumCntr;
		this.ticketAttributeCode = ticketAttributeCode;
		this.attributeValue = attributeValue;
		this.createUserId = createUserId;
		this.createDateTime = createDateTime;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getInum() {
		return inum;
	}

	public void setInum(String inum) {
		this.inum = inum;
	}

	public String getTnum() {
		return tnum;
	}

	public void setTnum(String tnum) {
		this.tnum = tnum;
	}

	public Integer gettNumCntr() {
		return tNumCntr;
	}

	public void settNumCntr(Integer tNumCntr) {
		this.tNumCntr = tNumCntr;
	}

	public TicketAttributeCode getTicketAttributeCode() {
		return ticketAttributeCode;
	}

	public void setTicketAttributeCode(TicketAttributeCode ticketAttributeCode) {
		this.ticketAttributeCode = ticketAttributeCode;
	}

	public String getAttributeValue() {
		return attributeValue;
	}

	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public LocalDateTime getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(LocalDateTime createDateTime) {
		this.createDateTime = createDateTime;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public LocalDateTime getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(LocalDateTime updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
}
