package com.flyairnorth.integration.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "ticket_status_code")
public class TicketStatusCode {

	@Id
	@Column(name = "status_code")
	private Long statusCode;

	@Column(name = "status_short_code", length = 45)
	private String statusShortCode;

	@Column(name = "status_value", length = 100)
	private String statusValue;

	@Column(name = "status_description", length = 500)
	private String statusDescription;

	@Column(name = "createduserid", length = 45)
	private String createdUserId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "createdatetime")
	private Date createdDatetime;

	@Column(name = "updateduserid", length = 45)
	private String updatedUserId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updateddatetime")
	private Date updatedDatetime;

	public Long getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Long statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusShortCode() {
		return statusShortCode;
	}

	public void setStatusShortCode(String statusShortCode) {
		this.statusShortCode = statusShortCode;
	}

	public String getStatusValue() {
		return statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	public String getCreatedUserId() {
		return createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public Date getCreatedDatetime() {
		return createdDatetime;
	}

	public void setCreatedDatetime(Date createdDatetime) {
		this.createdDatetime = createdDatetime;
	}

	public String getUpdatedUserId() {
		return updatedUserId;
	}

	public void setUpdatedUserId(String updatedUserId) {
		this.updatedUserId = updatedUserId;
	}

	public Date getUpdatedDatetime() {
		return updatedDatetime;
	}

	public void setUpdatedDatetime(Date updatedDatetime) {
		this.updatedDatetime = updatedDatetime;
	}
}
