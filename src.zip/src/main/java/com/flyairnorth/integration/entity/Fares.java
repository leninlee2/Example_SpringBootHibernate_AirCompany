package com.flyairnorth.integration.entity;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.flyairnorth.integration.enumerator.YesNo;

@Entity
@Table(name = "fares")
public class Fares {

	@Id
	@Column(name = "id")
	private Integer id;

	@Column(name = "fromcode", length = 3)
	private String fromCode;

	@Column(name = "tocode", length = 3)
	private String toCode;

	@Column(name = "fareclass", length = 45)
	private String fareClass;

	@Column(name = "code", length = 20)
	private String code;

	@Column(name = "cos", length = 6)
	private Integer cos;

	@Column(name = "ow_fare", precision = 7, scale = 2)
	private BigDecimal owFare;

	@Column(name = "rt_fare", precision = 7, scale = 2)
	private BigDecimal rtFare;

	@Column(name = "child_rate")
	private BigDecimal childRate;

	@Column(name = "infant_rate")
	private BigDecimal infantRate;

	@Column(name = "student_rate")
	private BigDecimal studentRate;

	@Column(name = "senior_rate")
	private BigDecimal seniorRate;

	@Column(name = "VGFN_beneficiary")
	private BigDecimal VGFN_beneficiary;

	@Column(name = "international_connector")
	private BigDecimal internationalConnector;

	@Column(name = "through_fare_trail_of_98")
	private BigDecimal throughFareTrailOf98;

	@Column(name = "rulecode", length = 20)
	private String ruleCode;

	@Column(name = "start")
	@Temporal(TemporalType.DATE)
	private Date start;

	@Column(name = "end")
	@Temporal(TemporalType.DATE)
	private Date end;

	@Column(name = "extend")
	@Temporal(TemporalType.DATE)
	private Date extend;

	@Column(name = "currency_isocode", length = 3)
	private String currencyIsocode;

	@Column(name = "minimumstay")
	private Integer minimumStay;

	@Column(name = "maximumstay")
	private Integer maximumStay;

	@Column(name = "daysofweek", length = 7)
	private String daysOfWeek;

	@Column(name = "travelcomplete")
	@Temporal(TemporalType.DATE)
	private Date travelComplete;

	@Column(name = "seats")
	private Integer seats;

	@Column(name = "inb_start")
	@Temporal(TemporalType.DATE)
	private Date inbStart;

	@Column(name = "inb_end")
	@Temporal(TemporalType.DATE)
	private Date inbEnd;

	@Column(name = "outbound_blackout_start")
	@Temporal(TemporalType.DATE)
	private Date outboundBlackoutStart;

	@Column(name = "outbound_blackout_end")
	@Temporal(TemporalType.DATE)
	private Date outboundBlackoutEnd;

	@Column(name = "inbound_blackout_start")
	@Temporal(TemporalType.DATE)
	private Date inboundBlackoutStart;

	@Column(name = "inbound_blackout_end")
	@Temporal(TemporalType.DATE)
	private Date inboundBlackoutEnd;

	@Column(name = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date timestamp;

	@Column(name = "availablefare_start")
	@Temporal(TemporalType.DATE)
	private Date availableFareStart;

	@Column(name = "availablefare_end")
	@Temporal(TemporalType.DATE)
	private Date availableFareEnd;

	@Column(name = "advance")
	private Integer advance;

	@Column(name = "view_type")
	private String viewType;

	@Column(name = "agent", length = 25)
	private String agent;

	@Column(name = "datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date datetime;

	@Column(name = "max_passpax")
	private Integer maxPassPax;

	@Column(name = "min_passpax")
	private Integer minPassPax;

	@Column(name = "group_fare")
	private Integer groupFare;

	@Enumerated(EnumType.STRING)
	@Column(name = "package")
	private YesNo _package;

	@Enumerated(EnumType.STRING)
	@Column(name = "active")
	private YesNo active;

	@Column(name = "flight", length = 255)
	private String flight;

	@Column(name = "passnum", length = 12)
	private String passNum;

	@Column(name = "corpnum", length = 12)
	private String corpNum;

	@Column(name = "outbound_blackout_start2")
	@Temporal(TemporalType.DATE)
	private Date outboundBlackoutStart2;

	@Column(name = "outbound_blackout_end2")
	@Temporal(TemporalType.DATE)
	private Date outboundBlackoutEnd2;

	@Column(name = "outbound_blackout_start3")
	@Temporal(TemporalType.DATE)
	private Date outboundBlackoutStart3;

	@Column(name = "outbound_blackout_end3 ")
	@Temporal(TemporalType.DATE)
	private Date outboundBlackoutEnd3;

	@Column(name = "outbound_blackout_start4")
	@Temporal(TemporalType.DATE)
	private Date outboundBlackoutStart4;

	@Column(name = "outbound_blackout_end4")
	@Temporal(TemporalType.DATE)
	private Date outboundBlackoutEnd4;

	@Column(name = "outbound_blackout_start5")
	@Temporal(TemporalType.DATE)
	private Date outboundBlackoutStart5;

	@Column(name = "outbound_blackout_end5")
	@Temporal(TemporalType.DATE)
	private Date outboundBlackoutEnd5;

	@Column(name = "through_fare_discount", precision = 7, scale = 2)
	private BigDecimal throughFareDiscount;

	public Set<String> getViewType() {
		if (viewType == null)
			return Collections.emptySet();
		else
			return Collections.unmodifiableSet(new HashSet<String>(Arrays.asList(viewType.split(","))));
	}

	public void setViewType(Set<String> viewTypes) {
		if (viewTypes == null) {
			viewType = null;
		}else {
			viewType = String.join(",", viewTypes);
		}
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFromCode() {
		return fromCode;
	}

	public void setFromCode(String fromCode) {
		this.fromCode = fromCode;
	}

	public String getToCode() {
		return toCode;
	}

	public void setToCode(String toCode) {
		this.toCode = toCode;
	}

	public String getFareClass() {
		return fareClass;
	}

	public void setFareClass(String fareClass) {
		this.fareClass = fareClass;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Integer getCos() {
		return cos;
	}

	public void setCos(Integer cos) {
		this.cos = cos;
	}

	public BigDecimal getOwFare() {
		return owFare;
	}

	public void setOwFare(BigDecimal owFare) {
		this.owFare = owFare;
	}

	public BigDecimal getRtFare() {
		return rtFare;
	}

	public void setRtFare(BigDecimal rtFare) {
		this.rtFare = rtFare;
	}

	public BigDecimal getChildRate() {
		return childRate;
	}

	public void setChildRate(BigDecimal childRate) {
		this.childRate = childRate;
	}

	public BigDecimal getInfantRate() {
		return infantRate;
	}

	public void setInfantRate(BigDecimal infantRate) {
		this.infantRate = infantRate;
	}

	public BigDecimal getStudentRate() {
		return studentRate;
	}

	public void setStudentRate(BigDecimal studentRate) {
		this.studentRate = studentRate;
	}

	public BigDecimal getSeniorRate() {
		return seniorRate;
	}

	public void setSeniorRate(BigDecimal seniorRate) {
		this.seniorRate = seniorRate;
	}

	public BigDecimal getVGFN_beneficiary() {
		return VGFN_beneficiary;
	}

	public void setVGFN_beneficiary(BigDecimal vGFN_beneficiary) {
		VGFN_beneficiary = vGFN_beneficiary;
	}

	public BigDecimal getInternationalConnector() {
		return internationalConnector;
	}

	public void setInternationalConnector(BigDecimal internationalConnector) {
		this.internationalConnector = internationalConnector;
	}

	public BigDecimal getThroughFareTrailOf98() {
		return throughFareTrailOf98;
	}

	public void setThroughFareTrailOf98(BigDecimal throughFareTrailOf98) {
		this.throughFareTrailOf98 = throughFareTrailOf98;
	}

	public String getRuleCode() {
		return ruleCode;
	}

	public void setRuleCode(String ruleCode) {
		this.ruleCode = ruleCode;
	}

	public Date getStart() {
		return start;
	}

	public void setStart(Date start) {
		this.start = start;
	}

	public Date getEnd() {
		return end;
	}

	public void setEnd(Date end) {
		this.end = end;
	}

	public Date getExtend() {
		return extend;
	}

	public void setExtend(Date extend) {
		this.extend = extend;
	}

	public String getCurrencyIsocode() {
		return currencyIsocode;
	}

	public void setCurrencyIsocode(String currencyIsocode) {
		this.currencyIsocode = currencyIsocode;
	}

	public Integer getMinimumStay() {
		return minimumStay;
	}

	public void setMinimumStay(Integer minimumStay) {
		this.minimumStay = minimumStay;
	}

	public Integer getMaximumStay() {
		return maximumStay;
	}

	public void setMaximumStay(Integer maximumStay) {
		this.maximumStay = maximumStay;
	}

	public String getDaysOfWeek() {
		return daysOfWeek;
	}

	public void setDaysOfWeek(String daysOfWeek) {
		this.daysOfWeek = daysOfWeek;
	}

	public Date getTravelComplete() {
		return travelComplete;
	}

	public void setTravelComplete(Date travelComplete) {
		this.travelComplete = travelComplete;
	}

	public Integer getSeats() {
		return seats;
	}

	public void setSeats(Integer seats) {
		this.seats = seats;
	}

	public Date getInbStart() {
		return inbStart;
	}

	public void setInbStart(Date inbStart) {
		this.inbStart = inbStart;
	}

	public Date getInbEnd() {
		return inbEnd;
	}

	public void setInbEnd(Date inbEnd) {
		this.inbEnd = inbEnd;
	}

	public Date getOutboundBlackoutStart() {
		return outboundBlackoutStart;
	}

	public void setOutboundBlackoutStart(Date outboundBlackoutStart) {
		this.outboundBlackoutStart = outboundBlackoutStart;
	}

	public Date getOutboundBlackoutEnd() {
		return outboundBlackoutEnd;
	}

	public void setOutboundBlackoutEnd(Date outboundBlackoutEnd) {
		this.outboundBlackoutEnd = outboundBlackoutEnd;
	}

	public Date getInboundBlackoutStart() {
		return inboundBlackoutStart;
	}

	public void setInboundBlackoutStart(Date inboundBlackoutStart) {
		this.inboundBlackoutStart = inboundBlackoutStart;
	}

	public Date getInboundBlackoutEnd() {
		return inboundBlackoutEnd;
	}

	public void setInboundBlackoutEnd(Date inboundBlackoutEnd) {
		this.inboundBlackoutEnd = inboundBlackoutEnd;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public Date getAvailableFareStart() {
		return availableFareStart;
	}

	public void setAvailableFareStart(Date availableFareStart) {
		this.availableFareStart = availableFareStart;
	}

	public Date getAvailableFareEnd() {
		return availableFareEnd;
	}

	public void setAvailableFareEnd(Date availableFareEnd) {
		this.availableFareEnd = availableFareEnd;
	}

	public Integer getAdvance() {
		return advance;
	}

	public void setAdvance(Integer advance) {
		this.advance = advance;
	}

	public String getAgent() {
		return agent;
	}

	public void setAgent(String agent) {
		this.agent = agent;
	}

	public Date getDatetime() {
		return datetime;
	}

	public void setDatetime(Date datetime) {
		this.datetime = datetime;
	}

	public Integer getMaxPassPax() {
		return maxPassPax;
	}

	public void setMaxPassPax(Integer maxPassPax) {
		this.maxPassPax = maxPassPax;
	}

	public Integer getMinPassPax() {
		return minPassPax;
	}

	public void setMinPassPax(Integer minPassPax) {
		this.minPassPax = minPassPax;
	}

	public Integer getGroupFare() {
		return groupFare;
	}

	public void setGroupFare(Integer groupFare) {
		this.groupFare = groupFare;
	}

	public YesNo get_package() {
		return _package;
	}

	public void set_package(YesNo _package) {
		this._package = _package;
	}

	public YesNo getActive() {
		return active;
	}

	public void setActive(YesNo active) {
		this.active = active;
	}

	public String getFlight() {
		return flight;
	}

	public void setFlight(String flight) {
		this.flight = flight;
	}

	public String getPassNum() {
		return passNum;
	}

	public void setPassNum(String passNum) {
		this.passNum = passNum;
	}

	public String getCorpNum() {
		return corpNum;
	}

	public void setCorpNum(String corpNum) {
		this.corpNum = corpNum;
	}

	public Date getOutboundBlackoutStart2() {
		return outboundBlackoutStart2;
	}

	public void setOutboundBlackoutStart2(Date outboundBlackoutStart2) {
		this.outboundBlackoutStart2 = outboundBlackoutStart2;
	}

	public Date getOutboundBlackoutEnd2() {
		return outboundBlackoutEnd2;
	}

	public void setOutboundBlackoutEnd2(Date outboundBlackoutEnd2) {
		this.outboundBlackoutEnd2 = outboundBlackoutEnd2;
	}

	public Date getOutboundBlackoutStart3() {
		return outboundBlackoutStart3;
	}

	public void setOutboundBlackoutStart3(Date outboundBlackoutStart3) {
		this.outboundBlackoutStart3 = outboundBlackoutStart3;
	}

	public Date getOutboundBlackoutEnd3() {
		return outboundBlackoutEnd3;
	}

	public void setOutboundBlackoutEnd3(Date outboundBlackoutEnd3) {
		this.outboundBlackoutEnd3 = outboundBlackoutEnd3;
	}

	public Date getOutboundBlackoutStart4() {
		return outboundBlackoutStart4;
	}

	public void setOutboundBlackoutStart4(Date outboundBlackoutStart4) {
		this.outboundBlackoutStart4 = outboundBlackoutStart4;
	}

	public Date getOutboundBlackoutEnd4() {
		return outboundBlackoutEnd4;
	}

	public void setOutboundBlackoutEnd4(Date outboundBlackoutEnd4) {
		this.outboundBlackoutEnd4 = outboundBlackoutEnd4;
	}

	public Date getOutboundBlackoutStart5() {
		return outboundBlackoutStart5;
	}

	public void setOutboundBlackoutStart5(Date outboundBlackoutStart5) {
		this.outboundBlackoutStart5 = outboundBlackoutStart5;
	}

	public Date getOutboundBlackoutEnd5() {
		return outboundBlackoutEnd5;
	}

	public void setOutboundBlackoutEnd5(Date outboundBlackoutEnd5) {
		this.outboundBlackoutEnd5 = outboundBlackoutEnd5;
	}

	public BigDecimal getThroughFareDiscount() {
		return throughFareDiscount;
	}

	public void setThroughFareDiscount(BigDecimal throughFareDiscount) {
		this.throughFareDiscount = throughFareDiscount;
	}
}
