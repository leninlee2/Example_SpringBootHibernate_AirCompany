package com.flyairnorth.integration.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "paymenttransactions")
public class PaymentTransaction {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "tranTypeId")
	private TransactionCode transactionCode;

	@Column(name = "acctDate")
	private LocalDate acctDate;

	@Column(name = "tranDateTime")
	private LocalDateTime tranDateTime;

	@Column(name = "inum", length = 8)
	private String inum;

	@Column(name = "awb_id", length = 11)
	private String awbId;

	@Column(name = "passnum", length = 8)
	private String passNum;

	@Column(name = "gc_transid")
	private Integer gcTransId;

	@Column(name = "corpPrePayId")
	private Integer corpPrePayId;

	@Column(name = "amount")
	private BigDecimal amount;

	@Column(name = "createUserid", length = 45)
	private String createUserId;

	@Column(name = "createDateTime")
	private LocalDateTime createDateTime;

	@Column(name = "updateUserId", length = 45)
	private String updateUserId;

	@Column(name = "updateDateTime")
	private LocalDateTime updateDateTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TransactionCode getTransactionCode() {
		return transactionCode;
	}

	public void setTransactionCode(TransactionCode transactionCode) {
		this.transactionCode = transactionCode;
	}

	public LocalDate getAcctDate() {
		return acctDate;
	}

	public void setAcctDate(LocalDate acctDate) {
		this.acctDate = acctDate;
	}

	public LocalDateTime getTranDateTime() {
		return tranDateTime;
	}

	public void setTranDateTime(LocalDateTime tranDateTime) {
		this.tranDateTime = tranDateTime;
	}

	public String getInum() {
		return inum;
	}

	public void setInum(String inum) {
		this.inum = inum;
	}

	public String getAwbId() {
		return awbId;
	}

	public void setAwbId(String awbId) {
		this.awbId = awbId;
	}

	public String getPassNum() {
		return passNum;
	}

	public void setPassNum(String passNum) {
		this.passNum = passNum;
	}

	public Integer getGcTransId() {
		return gcTransId;
	}

	public void setGcTransId(Integer gcTransId) {
		this.gcTransId = gcTransId;
	}

	public Integer getCorpPrePayId() {
		return corpPrePayId;
	}

	public void setCorpPrePayId(Integer corpPrePayId) {
		this.corpPrePayId = corpPrePayId;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public LocalDateTime getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(LocalDateTime createDateTime) {
		this.createDateTime = createDateTime;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public LocalDateTime getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(LocalDateTime updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
}
