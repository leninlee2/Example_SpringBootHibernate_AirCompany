package com.flyairnorth.integration.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.flyairnorth.integration.enumerator.FlightStatusSegment;

//TODO:entity
@Entity
@IdClass(GDSFlightSegmentsPK.class)
@Table(name = "gdsflightsegments")
public class GDSFlightSegments {
	
	@Id
	@Column(name = "id")
	private int id;
	
	

	public int getFlightseq() {
		return flightseq;
	}

	public void setFlightseq(int flightseq) {
		this.flightseq = flightseq;
	}

	public Date getFdate() {
		return fdate;
	}

	public void setFdate(Date fdate) {
		this.fdate = fdate;
	}

	public Date getDeparturetime() {
		return departuretime;
	}

	public void setDeparturetime(Date departuretime) {
		this.departuretime = departuretime;
	}

	public Date getArrivaltime() {
		return arrivaltime;
	}

	public void setArrivaltime(Date arrivaltime) {
		this.arrivaltime = arrivaltime;
	}

	@Column(name = "pnr", length = 6)
	private String pnr;
	
	@Column(name = "inum", length = 8)
	private String inum;
	
	@Column(name = "flightnum", length = 45)
	private String flightnum;
	
	public String getFlightnum() {
		return flightnum;
	}

	public void setFlightnum(String flightnum) {
		this.flightnum = flightnum;
	}

	@Column(name = "flightseq")
	private int flightseq;
	
	@Column(name = "fromcode", length = 3)
	private String fromcode;
	
	@Column(name = "tocode", length = 3)
	private String tocode;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private FlightStatusSegment status;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fdate")
	private Date fdate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "departuretime")
	private Date departuretime;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "arrivaltime")
	private Date arrivaltime;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "createdatetime")
	private Date createdatetime;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updatedatetime")
	private Date updatedatetime;
	
	@Column(name = "createuserid", length = 45)
	private String createuserid;
	
	@Column(name = "updateuserid", length = 45)
	private String updateuserid;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPnr() {
		return pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public String getInum() {
		return inum;
	}

	public void setInum(String inum) {
		this.inum = inum;
	}

	//public String getTnum() {
	//	return tnum;
	//}

	//public void setTnum(String tnum) {
	//	this.tnum = tnum;
	//}

	public String getFromcode() {
		return fromcode;
	}

	public void setFromcode(String fromcode) {
		this.fromcode = fromcode;
	}

	public String getTocode() {
		return tocode;
	}

	public void setTocode(String tocode) {
		this.tocode = tocode;
	}

	public FlightStatusSegment getStatus() {
		return status;
	}

	public void setStatus(FlightStatusSegment status) {
		this.status = status;
	}

	public String getCreateuserid() {
		return createuserid;
	}

	public void setCreateuserid(String createuserid) {
		this.createuserid = createuserid;
	}

	public Date getCreatedatetime() {
		return createdatetime;
	}

	public void setCreatedatetime(Date createdatetime) {
		this.createdatetime = createdatetime;
	}

	//@Column(name = "tnum", length = 8)
	//private String tnum;
	
	public String getUpdateuserid() {
		return updateuserid;
	}

	public void setUpdateuserid(String updateuserid) {
		this.updateuserid = updateuserid;
	}

	public Date getUpdatedatetime() {
		return updatedatetime;
	}

	public void setUpdatedatetime(Date updatedatetime) {
		this.updatedatetime = updatedatetime;
	}

	
	
	//@Column(name = "tnumcntr")
	//private int tnumcntr;

	//public int getTnumcntr() {
	//	return tnumcntr;
	//}

	//public void setTnumcntr(int tnumcntr) {
	//	this.tnumcntr = tnumcntr;
	//}

}
