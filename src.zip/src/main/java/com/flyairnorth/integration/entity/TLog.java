package com.flyairnorth.integration.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.flyairnorth.integration.enumerator.YesNo;

@Entity
@IdClass(TLogPK.class)
@Table(name = "tlog")
public class TLog {

	@Column(name = "datetime", length = 18)
	private String dateTime;

	@Column(name = "trantype")
	private Integer tranType;

	@Column(name = "inum", length = 8)
	private String iNum;

	@Id
	@Column(name = "tnum", length = 8)
	private String tNum;

	@Id
	@Column(name = "tnumcntr")
	private Integer tnumCntr;

	@Column(name = "passnum", length = 8)
	private String passNum;

	@Column(name = "resdate", length = 8)
	private String resDate;

	@Column(name = "submitdate", length = 8)
	private String submitDate;

	@Column(name = "paiddate", length = 8)
	private String paidDate;

	@Column(name = "fflight", length = 10)
	private String fFlight;

	@Column(name = "fromcode", length = 3)
	private String fromCode;

	@Column(name = "fdate", length = 8)
	private String fDate;

	@Column(name = "tocode", length = 3)
	private String toCode;

	@Column(name = "paymeth", length = 100)
	private String payMeth;

	@Column(name = "fare")
	private Double fare;

	@Column(name = "basis")
	private Integer basis;

	@Column(name = "fareclas", length = 10)
	private String fareClas;

	@Column(name = "comm")
	private Double comm;

	@Column(name = "first", length = 25)
	private String first;

	@Column(name = "middle", length = 25)
	private String middle;

	@Column(name = "last", length = 50)
	private String last;

	@Column(name = "sex", length = 6)
	private String sex;

	@Column(name = "birthdate")
	@Temporal(TemporalType.DATE)
	private Date birthDate;

	@Column(name = "yearofbirth", length = 2)
	private String yearOfBirth;

	@Column(name = "nation", length = 2)
	private String nation;

	@Column(name = "passportid", length = 7)
	private String passportId;

	@Column(name = "label", length = 4)
	private String label;

	@Column(name = "street", length = 60)
	private String street;

	@Column(name = "city", length = 21)
	private String city;

	@Column(name = "state", length = 3)
	private String state;

	@Column(name = "zip", length = 11)
	private String zip;

	@Column(name = "country", length = 3)
	private String country;

	@Column(name = "homefone", length = 30)
	private String homeFone;

	@Column(name = "workfone", length = 30)
	private String workFone;

	@Column(name = "awayfone", length = 30)
	private String awayFone;

	@Column(name = "candagen", length = 25)
	private String candagen;

	@Column(name = "cancdate", length = 8)
	private String cancdate;

	@Column(name = "cantime", length = 8)
	private String cantime;

	@Column(name = "ccnum", length = 20)
	private String ccnum;

	@Column(name = "expire", length = 9)
	private String expire;

	@Column(name = "ccauth", length = 10)
	private String ccAuth;

	@Column(name = "ccfirst", length = 13)
	private String ccFirst;

	@Column(name = "cclast", length = 25)
	private String ccLast;

	@Column(name = "iatanum", length = 8)
	private String iataNum;

	@Column(name = "agency", length = 36)
	private String agency;

	@Column(name = "refer", length = 50)
	private String refer;

	@Column(name = "resagent", length = 25)
	private String resAgent;

	@Column(name = "restime")
	private Long resTime;

	@Column(name = "voucher")
	private Double voucher;

	@Column(name = "canepoch")
	private Long canepoch;

	@Column(name = "corpnum", length = 8)
	private String corpNum;

	@Column(name = "corppercent")
	private Integer corpPercent;

	@Column(name = "currency_id")
	private Integer currencyId;

	@Column(name = "currency_name", length = 20)
	private String currencyName;

	@Column(name = "currency_prefix", length = 8)
	private String currencyPrefix;

	@Column(name = "currency_suffix", length = 8)
	private String currencySuffix;

	@Column(name = "currency_rate")
	private Double currencyRate;

	@Column(name = "currency_oneway")
	private Double currencyOneway;

	@Column(name = "pfcexcode", length = 8)
	private String pfcexCode;

	@Column(name = "pfcexlabel", length = 20)
	private String pfcexLabel;

	@Column(name = "ultimatefdate")
	private LocalDate ultimateFDate;

	@Column(name = "email", length = 65)
	private String email;

	@Column(name = "comment", length = 255)
	private String comment;

	@Column(name = "pil_comment", length = 255)
	private String pilComment;

	@Column(name = "psm_comment", length = 255)
	private String psmComment;

	@Column(name = "ptm_comment", length = 255)
	private String ptmComment;

	@Column(name = "optcharge_description1", length = 60)
	private String optchargeDescription1;

	@Column(name = "optcharge_description2", length = 60)
	private String optchargeDescription2;

	@Column(name = "optcharge_description3", length = 60)
	private String optchargeDescription3;

	@Column(name = "optcharge_description4", length = 60)
	private String optchargeDescription4;

	@Column(name = "optcharge_description5", length = 60)
	private String optchargeDescription5;

	@Column(name = "optcharge_description6", length = 60)
	private String optchargeDescription6;

	@Column(name = "optcharge_description7", length = 60)
	private String optchargeDescription7;

	@Column(name = "optcharge_description8", length = 60)
	private String optchargeDescription8;

	@Column(name = "optcharge_description9", length = 60)
	private String optchargeDescription9;

	@Column(name = "optcharge_description10", length = 60)
	private String optchargeDescription10;

	@Column(name = "optcharge_code1", length = 6)
	private String optchargeCode1;

	@Column(name = "optcharge_code2", length = 6)
	private String optchargeCode2;

	@Column(name = "optcharge_code3", length = 6)
	private String optchargeCode3;

	@Column(name = "optcharge_code4", length = 6)
	private String optchargeCode4;

	@Column(name = "optcharge_code5", length = 6)
	private String optchargeCode5;

	@Column(name = "optcharge_code6", length = 6)
	private String optchargeCode6;

	@Column(name = "optcharge_code7", length = 6)
	private String optchargeCode7;

	@Column(name = "optcharge_code8", length = 6)
	private String optchargeCode8;

	@Column(name = "optcharge_code9", length = 6)
	private String optchargeCode9;

	@Column(name = "optcharge_code10", length = 6)
	private String optchargeCode10;

	@Column(name = "optcharge_amount1")
	private Double optchargeAmount1;

	@Column(name = "optcharge_amount2")
	private Double optchargeAmount2;

	@Column(name = "optcharge_amount3")
	private Double optchargeAmount3;

	@Column(name = "optcharge_amount4")
	private Double optchargeAmount4;

	@Column(name = "optcharge_amount5")
	private Double optchargeAmount5;

	@Column(name = "optcharge_amount6")
	private Double optchargeAmount6;

	@Column(name = "optcharge_amount7")
	private Double optchargeAmount7;

	@Column(name = "optcharge_amount8")
	private Double optchargeAmount8;

	@Column(name = "optcharge_amount9")
	private Double optchargeAmount9;

	@Column(name = "optcharge_amount10")
	private Double optchargeAmount10;

	@Column(name = "seatcos")
	private Integer seatCos;

	@Column(name = "farecode", length = 20)
	private String fareCode;

	@Column(name = "fareclass", length = 45)
	private String fareClass;

	@Enumerated(EnumType.STRING)
	@Column(name = "senior")
	private YesNo senior;

	@Column(name = "discount", length = 20)
	private String discount;

	@Column(name = "assign_seat")
	@Enumerated(EnumType.STRING)
	private YesNo assignSeat;

	@Column(name = "refagent", length = 25)
	private String refAgent;

	@Column(name = "refdate", length = 8)
	private String refDate;

	@Column(name = "reftime", length = 8)
	private String refTime;

	@Column(name = "security_code", length = 12)
	private String securityCode;

	@Column(name = "update_agent", length = 25)
	private String updateAgent;

	@Column(name = "update_time", length = 18)
	private String updateTime;

	@Enumerated(EnumType.STRING)
	@Column(name = "pre_assign")
	private YesNo preAssign;

	@Enumerated(EnumType.STRING)
	@Column(name = "adjust_fare")
	private YesNo adjustFare;

	@Column(name = "seat_history", length = 60)
	private String seatHistory;

	@Column(name = "promocode", length = 10)
	private String promoCode;

	@Column(name = "lounge_type", length = 3)
	private String loungeType;

	@Enumerated(EnumType.STRING)
	@Column(name = "isonline")
	private YesNo isOnline;

	@Column(name = "pnr", length = 6)
	private String pnr;

	@Column(name = "tourid", length = 10)
	private String tourId;

	@Column(name = "secondary_email", length = 250)
	private String secondaryEmail;

	@Enumerated(EnumType.STRING)
	@Column(name = "through_fare")
	private YesNo throughFare;

	@Enumerated(EnumType.STRING)
	@Column(name = "capo")
	private YesNo capo;

	@Enumerated(EnumType.STRING)
	@Column(name = "us_custom")
	private YesNo usCustom;

	@Column(name = "TTY_inbound", length = 15)
	private String TTYInbound;

	@Column(name = "TTY_outbound", length = 15)
	private String TTYOutbound;

	@Temporal(TemporalType.DATE)
	@Column(name = "refund_date")
	private Date refundDate;

	@Transient
	private LocalDateTime departureDateTime;

	@Transient
	private LocalDateTime arrivalDateTime;
	
	@Column(name = "bookiata", length = 8)
	private String bookiata;

	public String getBookiata() {
		return bookiata;
	}

	public void setBookiata(String bookiata) {
		this.bookiata = bookiata;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public Integer getTranType() {
		return tranType;
	}

	public void setTranType(Integer tranType) {
		this.tranType = tranType;
	}

	public String getiNum() {
		return iNum;
	}

	public void setiNum(String iNum) {
		this.iNum = iNum;
	}

	public String gettNum() {
		return tNum;
	}

	public void settNum(String tNum) {
		this.tNum = tNum;
	}

	public Integer getTnumCntr() {
		return tnumCntr;
	}

	public void setTnumCntr(Integer tNumCntr) {
		this.tnumCntr = tNumCntr;
	}

	public String getPassNum() {
		return passNum;
	}

	public void setPassNum(String passNum) {
		this.passNum = passNum;
	}

	public String getResDate() {
		return resDate;
	}

	public void setResDate(String resDate) {
		this.resDate = resDate;
	}

	public String getSubmitDate() {
		return submitDate;
	}

	public void setSubmitDate(String submitDate) {
		this.submitDate = submitDate;
	}

	public String getPaidDate() {
		return paidDate;
	}

	public void setPaidDate(String paidDate) {
		this.paidDate = paidDate;
	}

	public String getfFlight() {
		return fFlight;
	}

	public void setfFlight(String fFlight) {
		this.fFlight = fFlight;
	}

	public String getFromCode() {
		return fromCode;
	}

	public void setFromCode(String fromCode) {
		this.fromCode = fromCode;
	}

	public String getfDate() {
		return fDate;
	}

	public void setfDate(String fDate) {
		this.fDate = fDate;
	}

	public String getToCode() {
		return toCode;
	}

	public void setToCode(String toCode) {
		this.toCode = toCode;
	}

	public String getPayMeth() {
		return payMeth;
	}

	public void setPayMeth(String payMeth) {
		this.payMeth = payMeth;
	}

	public Double getFare() {
		return fare;
	}

	public void setFare(Double fare) {
		this.fare = fare;
	}

	public Integer getBasis() {
		return basis;
	}

	public void setBasis(Integer basis) {
		this.basis = basis;
	}

	public String getFareClas() {
		return fareClas;
	}

	public void setFareClas(String fareClas) {
		this.fareClas = fareClas;
	}

	public Double getComm() {
		return comm;
	}

	public void setComm(Double comm) {
		this.comm = comm;
	}

	public String getFirst() {
		return first;
	}

	public void setFirst(String first) {
		this.first = first;
	}

	public String getMiddle() {
		return middle;
	}

	public void setMiddle(String middle) {
		this.middle = middle;
	}

	public String getLast() {
		return last;
	}

	public void setLast(String last) {
		this.last = last;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public String getYearOfBirth() {
		return yearOfBirth;
	}

	public void setYearOfBirth(String yearOfBirth) {
		this.yearOfBirth = yearOfBirth;
	}

	public String getNation() {
		return nation;
	}

	public void setNation(String nation) {
		this.nation = nation;
	}

	public String getPassportId() {
		return passportId;
	}

	public void setPassportId(String passportId) {
		this.passportId = passportId;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getHomeFone() {
		return homeFone;
	}

	public void setHomeFone(String homeFone) {
		this.homeFone = homeFone;
	}

	public String getWorkFone() {
		return workFone;
	}

	public void setWorkFone(String workFone) {
		this.workFone = workFone;
	}

	public String getAwayFone() {
		return awayFone;
	}

	public void setAwayFone(String awayFone) {
		this.awayFone = awayFone;
	}

	public String getCandagen() {
		return candagen;
	}

	public void setCandagen(String candagen) {
		this.candagen = candagen;
	}

	public String getCancdate() {
		return cancdate;
	}

	public void setCancdate(String cancdate) {
		this.cancdate = cancdate;
	}

	public String getCantime() {
		return cantime;
	}

	public void setCantime(String cantime) {
		this.cantime = cantime;
	}

	public String getCcnum() {
		return ccnum;
	}

	public void setCcnum(String ccnum) {
		this.ccnum = ccnum;
	}

	public String getExpire() {
		return expire;
	}

	public void setExpire(String expire) {
		this.expire = expire;
	}

	public String getCcAuth() {
		return ccAuth;
	}

	public void setCcAuth(String ccAuth) {
		this.ccAuth = ccAuth;
	}

	public String getCcFirst() {
		return ccFirst;
	}

	public void setCcFirst(String ccFirst) {
		this.ccFirst = ccFirst;
	}

	public String getCcLast() {
		return ccLast;
	}

	public void setCcLast(String ccLast) {
		this.ccLast = ccLast;
	}

	public String getIataNum() {
		return iataNum;
	}

	public void setIataNum(String iataNum) {
		this.iataNum = iataNum;
	}

	public String getAgency() {
		return agency;
	}

	public void setAgency(String agency) {
		this.agency = agency;
	}

	public String getRefer() {
		return refer;
	}

	public void setRefer(String refer) {
		this.refer = refer;
	}

	public String getResAgent() {
		return resAgent;
	}

	public void setResAgent(String resAgent) {
		this.resAgent = resAgent;
	}

	public Long getResTime() {
		return resTime;
	}

	public void setResTime(Long resTime) {
		this.resTime = resTime;
	}

	public Double getVoucher() {
		return voucher;
	}

	public void setVoucher(Double voucher) {
		this.voucher = voucher;
	}

	public Long getCanepoch() {
		return canepoch;
	}

	public void setCanepoch(Long canepoch) {
		this.canepoch = canepoch;
	}

	public String getCorpNum() {
		return corpNum;
	}

	public void setCorpNum(String corpNum) {
		this.corpNum = corpNum;
	}

	public Integer getCorpPercent() {
		return corpPercent;
	}

	public void setCorpPercent(Integer corpPercent) {
		this.corpPercent = corpPercent;
	}

	public Integer getCurrencyId() {
		return currencyId;
	}

	public void setCurrencyId(Integer currencyId) {
		this.currencyId = currencyId;
	}

	public String getCurrencyName() {
		return currencyName;
	}

	public void setCurrencyName(String currencyName) {
		this.currencyName = currencyName;
	}

	public String getCurrencyPrefix() {
		return currencyPrefix;
	}

	public void setCurrencyPrefix(String currencyPrefix) {
		this.currencyPrefix = currencyPrefix;
	}

	public String getCurrencySuffix() {
		return currencySuffix;
	}

	public void setCurrencySuffix(String currencySuffix) {
		this.currencySuffix = currencySuffix;
	}

	public Double getCurrencyRate() {
		return currencyRate;
	}

	public void setCurrencyRate(Double currencyRate) {
		this.currencyRate = currencyRate;
	}

	public Double getCurrencyOneway() {
		return currencyOneway;
	}

	public void setCurrencyOneway(Double currencyOneway) {
		this.currencyOneway = currencyOneway;
	}

	public String getPfcexCode() {
		return pfcexCode;
	}

	public void setPfcexCode(String pfcexCode) {
		this.pfcexCode = pfcexCode;
	}

	public String getPfcexLabel() {
		return pfcexLabel;
	}

	public void setPfcexLabel(String pfcexLabel) {
		this.pfcexLabel = pfcexLabel;
	}

	public LocalDate getUltimateFDate() {
		return ultimateFDate;
	}

	public void setUltimateFDate(LocalDate ultimateFDate) {
		this.ultimateFDate = ultimateFDate;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getPilComment() {
		return pilComment;
	}

	public void setPilComment(String pilComment) {
		this.pilComment = pilComment;
	}

	public String getPsmComment() {
		return psmComment;
	}

	public void setPsmComment(String psmComment) {
		this.psmComment = psmComment;
	}

	public String getPtmComment() {
		return ptmComment;
	}

	public void setPtmComment(String ptmComment) {
		this.ptmComment = ptmComment;
	}

	public String getOptchargeDescription1() {
		return optchargeDescription1;
	}

	public void setOptchargeDescription1(String optchargeDescription1) {
		this.optchargeDescription1 = optchargeDescription1;
	}

	public String getOptchargeDescription2() {
		return optchargeDescription2;
	}

	public void setOptchargeDescription2(String optchargeDescription2) {
		this.optchargeDescription2 = optchargeDescription2;
	}

	public String getOptchargeDescription3() {
		return optchargeDescription3;
	}

	public void setOptchargeDescription3(String optchargeDescription3) {
		this.optchargeDescription3 = optchargeDescription3;
	}

	public String getOptchargeDescription4() {
		return optchargeDescription4;
	}

	public void setOptchargeDescription4(String optchargeDescription4) {
		this.optchargeDescription4 = optchargeDescription4;
	}

	public String getOptchargeDescription5() {
		return optchargeDescription5;
	}

	public void setOptchargeDescription5(String optchargeDescription5) {
		this.optchargeDescription5 = optchargeDescription5;
	}

	public String getOptchargeDescription6() {
		return optchargeDescription6;
	}

	public void setOptchargeDescription6(String optchargeDescription6) {
		this.optchargeDescription6 = optchargeDescription6;
	}

	public String getOptchargeDescription7() {
		return optchargeDescription7;
	}

	public void setOptchargeDescription7(String optchargeDescription7) {
		this.optchargeDescription7 = optchargeDescription7;
	}

	public String getOptchargeDescription8() {
		return optchargeDescription8;
	}

	public void setOptchargeDescription8(String optchargeDescription8) {
		this.optchargeDescription8 = optchargeDescription8;
	}

	public String getOptchargeDescription9() {
		return optchargeDescription9;
	}

	public void setOptchargeDescription9(String optchargeDescription9) {
		this.optchargeDescription9 = optchargeDescription9;
	}

	public String getOptchargeDescription10() {
		return optchargeDescription10;
	}

	public void setOptchargeDescription10(String optchargeDescription10) {
		this.optchargeDescription10 = optchargeDescription10;
	}

	public String getOptchargeCode1() {
		return optchargeCode1;
	}

	public void setOptchargeCode1(String optchargeCode1) {
		this.optchargeCode1 = optchargeCode1;
	}

	public String getOptchargeCode2() {
		return optchargeCode2;
	}

	public void setOptchargeCode2(String optchargeCode2) {
		this.optchargeCode2 = optchargeCode2;
	}

	public String getOptchargeCode3() {
		return optchargeCode3;
	}

	public void setOptchargeCode3(String optchargeCode3) {
		this.optchargeCode3 = optchargeCode3;
	}

	public String getOptchargeCode4() {
		return optchargeCode4;
	}

	public void setOptchargeCode4(String optchargeCode4) {
		this.optchargeCode4 = optchargeCode4;
	}

	public String getOptchargeCode5() {
		return optchargeCode5;
	}

	public void setOptchargeCode5(String optchargeCode5) {
		this.optchargeCode5 = optchargeCode5;
	}

	public String getOptchargeCode6() {
		return optchargeCode6;
	}

	public void setOptchargeCode6(String optchargeCode6) {
		this.optchargeCode6 = optchargeCode6;
	}

	public String getOptchargeCode7() {
		return optchargeCode7;
	}

	public void setOptchargeCode7(String optchargeCode7) {
		this.optchargeCode7 = optchargeCode7;
	}

	public String getOptchargeCode8() {
		return optchargeCode8;
	}

	public void setOptchargeCode8(String optchargeCode8) {
		this.optchargeCode8 = optchargeCode8;
	}

	public String getOptchargeCode9() {
		return optchargeCode9;
	}

	public void setOptchargeCode9(String optchargeCode9) {
		this.optchargeCode9 = optchargeCode9;
	}

	public String getOptchargeCode10() {
		return optchargeCode10;
	}

	public void setOptchargeCode10(String optchargeCode10) {
		this.optchargeCode10 = optchargeCode10;
	}

	public Double getOptchargeAmount1() {
		return optchargeAmount1;
	}

	public void setOptchargeAmount1(Double optchargeAmount1) {
		this.optchargeAmount1 = optchargeAmount1;
	}

	public Double getOptchargeAmount2() {
		return optchargeAmount2;
	}

	public void setOptchargeAmount2(Double optchargeAmount2) {
		this.optchargeAmount2 = optchargeAmount2;
	}

	public Double getOptchargeAmount3() {
		return optchargeAmount3;
	}

	public void setOptchargeAmount3(Double optchargeAmount3) {
		this.optchargeAmount3 = optchargeAmount3;
	}

	public Double getOptchargeAmount4() {
		return optchargeAmount4;
	}

	public void setOptchargeAmount4(Double optchargeAmount4) {
		this.optchargeAmount4 = optchargeAmount4;
	}

	public Double getOptchargeAmount5() {
		return optchargeAmount5;
	}

	public void setOptchargeAmount5(Double optchargeAmount5) {
		this.optchargeAmount5 = optchargeAmount5;
	}

	public Double getOptchargeAmount6() {
		return optchargeAmount6;
	}

	public void setOptchargeAmount6(Double optchargeAmount6) {
		this.optchargeAmount6 = optchargeAmount6;
	}

	public Double getOptchargeAmount7() {
		return optchargeAmount7;
	}

	public void setOptchargeAmount7(Double optchargeAmount7) {
		this.optchargeAmount7 = optchargeAmount7;
	}

	public Double getOptchargeAmount8() {
		return optchargeAmount8;
	}

	public void setOptchargeAmount8(Double optchargeAmount8) {
		this.optchargeAmount8 = optchargeAmount8;
	}

	public Double getOptchargeAmount9() {
		return optchargeAmount9;
	}

	public void setOptchargeAmount9(Double optchargeAmount9) {
		this.optchargeAmount9 = optchargeAmount9;
	}

	public Double getOptchargeAmount10() {
		return optchargeAmount10;
	}

	public void setOptchargeAmount10(Double optchargeAmount10) {
		this.optchargeAmount10 = optchargeAmount10;
	}

	public Integer getSeatCos() {
		return seatCos;
	}

	public void setSeatCos(Integer seatCos) {
		this.seatCos = seatCos;
	}

	public String getFareCode() {
		return fareCode;
	}

	public void setFareCode(String fareCode) {
		this.fareCode = fareCode;
	}

	public String getFareClass() {
		return fareClass;
	}

	public void setFareClass(String fareClass) {
		this.fareClass = fareClass;
	}

	public YesNo getSenior() {
		return senior;
	}

	public void setSenior(YesNo senior) {
		this.senior = senior;
	}

	public String getDiscount() {
		return discount;
	}

	public void setDiscount(String discount) {
		this.discount = discount;
	}

	public YesNo getAssignSeat() {
		return assignSeat;
	}

	public void setAssignSeat(YesNo assignSeat) {
		this.assignSeat = assignSeat;
	}

	public String getRefAgent() {
		return refAgent;
	}

	public void setRefAgent(String refAgent) {
		this.refAgent = refAgent;
	}

	public String getRefDate() {
		return refDate;
	}

	public void setRefDate(String refDate) {
		this.refDate = refDate;
	}

	public String getRefTime() {
		return refTime;
	}

	public void setRefTime(String refTime) {
		this.refTime = refTime;
	}

	public String getSecurityCode() {
		return securityCode;
	}

	public void setSecurityCode(String securityCode) {
		this.securityCode = securityCode;
	}

	public String getUpdateAgent() {
		return updateAgent;
	}

	public void setUpdateAgent(String updateAgent) {
		this.updateAgent = updateAgent;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public YesNo getPreAssign() {
		return preAssign;
	}

	public void setPreAssign(YesNo preAssign) {
		this.preAssign = preAssign;
	}

	public YesNo getAdjustFare() {
		return adjustFare;
	}

	public void setAdjustFare(YesNo adjustFare) {
		this.adjustFare = adjustFare;
	}

	public String getSeatHistory() {
		return seatHistory;
	}

	public void setSeatHistory(String seatHistory) {
		this.seatHistory = seatHistory;
	}

	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	public String getLoungeType() {
		return loungeType;
	}

	public void setLoungeType(String loungeType) {
		this.loungeType = loungeType;
	}

	public YesNo getIsOnline() {
		return isOnline;
	}

	public void setIsOnline(YesNo isOnline) {
		this.isOnline = isOnline;
	}

	public String getPnr() {
		return pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public String getTourId() {
		return tourId;
	}

	public void setTourId(String tourId) {
		this.tourId = tourId;
	}

	public String getSecondaryEmail() {
		return secondaryEmail;
	}

	public void setSecondaryEmail(String secondaryEmail) {
		this.secondaryEmail = secondaryEmail;
	}

	public YesNo getThroughFare() {
		return throughFare;
	}

	public void setThroughFare(YesNo throughFare) {
		this.throughFare = throughFare;
	}

	public YesNo getCapo() {
		return capo;
	}

	public void setCapo(YesNo capo) {
		this.capo = capo;
	}

	public YesNo getUsCustom() {
		return usCustom;
	}

	public void setUsCustom(YesNo usCustom) {
		this.usCustom = usCustom;
	}

	public String getTTYInbound() {
		return TTYInbound;
	}

	public void setTTYInbound(String tTYInbound) {
		TTYInbound = tTYInbound;
	}

	public String getTTYOutbound() {
		return TTYOutbound;
	}

	public void setTTYOutbound(String tTYOutbound) {
		TTYOutbound = tTYOutbound;
	}

	public Date getRefundDate() {
		return refundDate;
	}

	public void setRefundDate(Date refundDate) {
		this.refundDate = refundDate;
	}

	public LocalDateTime getDepartureDateTime() {
		return departureDateTime;
	}

	public void setDepartureDateTime(LocalDateTime departureDateTime) {
		this.departureDateTime = departureDateTime;
	}

	public LocalDateTime getArrivalDateTime() {
		return arrivalDateTime;
	}

	public void setArrivalDateTime(LocalDateTime arrivalDateTime) {
		this.arrivalDateTime = arrivalDateTime;
	}
}
