package com.flyairnorth.integration.entity;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.flyairnorth.integration.enumerator.YesNo;

@Entity
@IdClass(BookedLegsPK.class)
@Table(name = "booked_legs")
public class BookedLegs {

//	@Id
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
//	private Long id;

	@Column(name = "datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createDatetime;

	@Column(name = "agent", length = 17)
	private String agent;
	
	@Id
	@Column (name = "fdate")
	private LocalDate fDate;
	
	@Id
	@Column (name = "leg")
	private Integer leg;
	
	@Column(name = "fromcode", length = 3)
	private String fromCode;
	
	@Column(name = "tocode", length = 3)
	private String toCode;
	
	@Column(name = "tdepart")
	private LocalTime tDepart; 
	
	@Column(name = "tarrive")
	private LocalTime tArrive;
	
	@Column(name = "day")
	private Integer day;
	
	@Column (name = "equip", length = 3)
	private String equip;
	
	@Column (name = "distance")
	private Integer distance;
	
	@Column(name = "tone")
	private Integer tOne;
	
	@Column(name = "ttwo")
	private Integer tTwo;
	
	@Column(name = "tthree")
	private Integer tThree;
	
	@Column(name = "tfour")
	private Integer tFour;
	
	@Column(name = "tfive")
	private Integer tFive;
	
	@Column(name = "wone")
	private Integer wOne;
	
	@Column(name= "wtwo")
	private Integer wTwo;
	
	@Column(name = "wthree")
	private Integer wThree;
	
	@Column(name = "wfour")
	private Integer wFour;
	
	@Column(name = "wfive")
	private Integer wFive;

	@Enumerated(EnumType.STRING)
	@Column(name = "assignseats")
	private YesNo assignSeats;

//	@ManyToOne(fetch=FetchType.LAZY)
//	@JoinColumn(name="flight_id")
//	private Flights flight;

	public String getAgent() {
		return agent;
	}

	public void setAgent(String agent) {
		this.agent = agent;
	}

	public LocalDate getfDate() {
		return fDate;
	}

	public void setfDate(LocalDate fDate) {
		this.fDate = fDate;
	}

	public Integer getLeg() {
		return leg;
	}

	public void setLeg(Integer leg) {
		this.leg = leg;
	}

	public String getFromCode() {
		return fromCode;
	}

	public void setFromCode(String fromCode) {
		this.fromCode = fromCode;
	}

	public String getToCode() {
		return toCode;
	}

	public void setToCode(String toCode) {
		this.toCode = toCode;
	}

	public LocalTime gettDepart() {
		return tDepart;
	}

	public void settDepart(LocalTime tDepart) {
		this.tDepart = tDepart;
	}

	public LocalTime gettArrive() {
		return tArrive;
	}

	public void settArrive(LocalTime tArrive) {
		this.tArrive = tArrive;
	}

	public Integer getDay() {
		return day;
	}

	public void setDay(Integer day) {
		this.day = day;
	}

	public String getEquip() {
		return equip;
	}

	public void setEquip(String equip) {
		this.equip = equip;
	}

	public Integer getDistance() {
		return distance;
	}

	public void setDistance(Integer distance) {
		this.distance = distance;
	}

	public Integer gettOne() {
		return tOne;
	}

	public void settOne(Integer tOne) {
		this.tOne = tOne;
	}

	public Integer gettTwo() {
		return tTwo;
	}

	public void settTwo(Integer tTwo) {
		this.tTwo = tTwo;
	}

	public Integer gettThree() {
		return tThree;
	}

	public void settThree(Integer tThree) {
		this.tThree = tThree;
	}

	public Integer gettFour() {
		return tFour;
	}

	public void settFour(Integer tFour) {
		this.tFour = tFour;
	}

	public Integer gettFive() {
		return tFive;
	}

	public void settFive(Integer tFive) {
		this.tFive = tFive;
	}

	public Integer getwOne() {
		return wOne;
	}

	public void setwOne(Integer wOne) {
		this.wOne = wOne;
	}

	public Integer getwTwo() {
		return wTwo;
	}

	public void setwTwo(Integer wTwo) {
		this.wTwo = wTwo;
	}

	public Integer getwThree() {
		return wThree;
	}

	public void setwThree(Integer wThree) {
		this.wThree = wThree;
	}

	public Integer getwFour() {
		return wFour;
	}

	public void setwFour(Integer wFour) {
		this.wFour = wFour;
	}

	public Integer getwFive() {
		return wFive;
	}

	public void setwFive(Integer wFive) {
		this.wFive = wFive;
	}

	public YesNo getAssignSeats() {
		return assignSeats;
	}

	public void setAssignSeats(YesNo assignSeats) {
		this.assignSeats = assignSeats;
	}

//	public Long getId() {
//		return id;
//	}
//
//	public void setId(Long id) {
//		this.id = id;
//	}

	public Date getCreateDatetime() {
		return createDatetime;
	}

	public void setCreateDatetime(Date createDatetime) {
		this.createDatetime = createDatetime;
	}

//	public Flights getFlight() {
//		return flight;
//	}
//
//	public void setFlight(Flights flight) {
//		this.flight = flight;
//	}

	@Override
	public BookedLegs clone() {
		BookedLegs dolly = new BookedLegs();

		dolly.fDate = this.fDate;
		dolly.leg = this.leg;
		dolly.fromCode = this.fromCode;
		dolly.toCode = this.toCode;
		dolly.tDepart = this.tDepart;
		dolly.tArrive = this.tArrive;
		dolly.day = this.day;
		dolly.equip = this.equip;
		dolly.distance = this.distance;
		dolly.tOne = this.tOne;
		dolly.tTwo = this.tTwo;
		dolly.tThree = this.tThree;
		dolly.tFour = this.tFour;
		dolly.tFive = this.tFive;
		dolly.wOne = this.wOne;
		dolly.wTwo = this.wTwo;
		dolly.wThree = this.wThree;
		dolly.wFour = this.wFour;
		dolly.wFive = this.wFive;
		dolly.assignSeats = this.assignSeats;
//		dolly.flight = this.flight;

		return dolly;
	}
}
