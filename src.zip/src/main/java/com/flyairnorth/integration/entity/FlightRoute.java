package com.flyairnorth.integration.entity;

import java.util.Date;

import com.flyairnorth.integration.enumerator.YesNo;

//@Entity
//@Table(name = "flight_route")
public class FlightRoute {

//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

//	@Column(name = "route_id", precision = 11)
	private Long routeId;

//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "flight_id")
	private Flights flight;

//	@Column(name = "fromcode", length = 3)
	private String fromCode;

//	@Column(name = "tocode", length = 3)
	private String toCode;

//	@Column(name = "stops", precision=11)
	private Long stops;
//
//	@Column(name = "legnum", precision = 11)
	private Long legnum;

//	@Column(name = "seq_order", precision = 11)
	private Long seqOrder;

//	@Enumerated(EnumType.STRING)
//	@Column(name = "active")
	private YesNo active;

//	@Temporal(TemporalType.TIMESTAMP)
//	@Column(name = "createdatetime")
	private Date createDatetime;

//	@Column(name = "createuserid", length = 45)
	private String createUserId;

//	@Temporal(TemporalType.TIMESTAMP)
//	@Column(name = "updatedatetime")
	private Date updateDatetime;

//	@Column(name = "updateuserid", length = 45)
	private String updateUserid;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getRouteId() {
		return routeId;
	}

	public void setRouteId(Long routeId) {
		this.routeId = routeId;
	}

	public Flights getFlight() {
		return flight;
	}

	public void setFlight(Flights flight) {
		this.flight = flight;
	}

	public String getFromCode() {
		return fromCode;
	}

	public void setFromCode(String fromCode) {
		this.fromCode = fromCode;
	}

	public String getToCode() {
		return toCode;
	}

	public void setToCode(String toCode) {
		this.toCode = toCode;
	}

	public Long getStops() {
		return stops;
	}

	public void setStops(Long stops) {
		this.stops = stops;
	}

	public Long getLegnum() {
		return legnum;
	}

	public void setLegnum(Long legnum) {
		this.legnum = legnum;
	}

	public Long getSeqOrder() {
		return seqOrder;
	}

	public void setSeqOrder(Long seqOrder) {
		this.seqOrder = seqOrder;
	}

	public YesNo getActive() {
		return active;
	}

	public void setActive(YesNo active) {
		this.active = active;
	}

	public Date getCreateDatetime() {
		return createDatetime;
	}

	public void setCreateDatetime(Date createDatetime) {
		this.createDatetime = createDatetime;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Date getUpdateDatetime() {
		return updateDatetime;
	}

	public void setUpdateDatetime(Date updateDatetime) {
		this.updateDatetime = updateDatetime;
	}

	public String getUpdateUserid() {
		return updateUserid;
	}

	public void setUpdateUserid(String updateUserid) {
		this.updateUserid = updateUserid;
	}
}
