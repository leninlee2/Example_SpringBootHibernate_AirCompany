package com.flyairnorth.integration.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "transactioncode")
public class TransactionCode {

	 @Id
	 @GeneratedValue(strategy=GenerationType.IDENTITY)
	 @Column(name = "id")
	 private Long id;

	 @ManyToOne(fetch=FetchType.LAZY)
	 @JoinColumn(name = "sourceid")
	 private TransactionSource transactionSource;

	 @Column(name = "tranCode", length = 20)
	 private String tranCode;

	 @Column(name = "shortDesc", length = 20)
	 private String shortDesc;
	 
	 @Column(name = "description", length = 100)
	 private String description;
	 
	 @Column(name = "createUserid", length = 45) 
	 private String createUserId;
	 
	 @Column(name = "createDateTime")
	 private LocalDateTime createDateTime;
	 
	 @Column(name = "updateUserId", length =45) 
	 private String updateUserId;

	 @Column(name = "updateDateTime")
	 private LocalDateTime updateDateTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TransactionSource getTransactionSource() {
		return transactionSource;
	}

	public void setTransactionSource(TransactionSource transactionSource) {
		this.transactionSource = transactionSource;
	}

	public String getTranCode() {
		return tranCode;
	}

	public void setTranCode(String tranCode) {
		this.tranCode = tranCode;
	}

	public String getShortDesc() {
		return shortDesc;
	}

	public void setShortDesc(String shortDesc) {
		this.shortDesc = shortDesc;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public LocalDateTime getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(LocalDateTime createDateTime) {
		this.createDateTime = createDateTime;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public LocalDateTime getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(LocalDateTime updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
}
