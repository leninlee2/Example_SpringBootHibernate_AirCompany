package com.flyairnorth.integration.entity;

import java.util.Date;

//@Entity
//@Table(name = "flight_log")
public class FlightLog {

//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "flight_id")
	private Flights flight;

//	@Column(name = "transaction_type", length = 45)
	private String transactionType;

//	@Temporal(TemporalType.TIMESTAMP)
//	@Column(name = "transaction_date")
	private Date transactionDate;

//	@Column(name = "user_id", length = 45)
	private String userId;

//	@Column(name = "action_message", length = 1000)
	private String actionMessage;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Flights getFlight() {
		return flight;
	}

	public void setFlight(Flights flight) {
		this.flight = flight;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getActionMessage() {
		return actionMessage;
	}

	public void setActionMessage(String actionMessage) {
		this.actionMessage = actionMessage;
	}
}
