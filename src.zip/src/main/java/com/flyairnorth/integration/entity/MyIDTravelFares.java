package com.flyairnorth.integration.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.flyairnorth.integration.enumerator.MyIDBookingType;
import com.flyairnorth.integration.enumerator.PaxType;

@Entity
@Table(name = "myidtravelfares")
public class MyIDTravelFares {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;

	@Column(name = "fromcode", length = 3)
	private String fromCode;
	
	@Column(name = "tocode", length = 3)
	private  String toCode;
	
	@Column(name = "fareclass", length = 45)
	private String fareClass;

	@Column(name = "farecode", length = 45)
	private String fareCode;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "paxtype")
	private PaxType paxType;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "bookingtype")
	private MyIDBookingType bookingType;
	
	@Column(name = "amount", precision = 10, scale=2)
	private BigDecimal amount;
	
	@Column(name = "currency")
	private String currency;
	
	@Column(name = "fareid")
	private Integer fareId;
	
	@Column(name = "createuserid", length = 45)
	private String createUserId;
	
	@Column(name = "createdatetime")
	private LocalDateTime createDateTime;
	
	@Column(name = "updateuserid", length = 45 )
	private String updateUserId;
	
	@Column(name = "updatedatetime")
	private LocalDateTime updateDateTime;
	
	@Transient
	private BigDecimal cadAmount;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFromCode() {
		return fromCode;
	}

	public void setFromCode(String fromCode) {
		this.fromCode = fromCode;
	}

	public String getToCode() {
		return toCode;
	}

	public void setToCode(String toCode) {
		this.toCode = toCode;
	}

	public String getFareClass() {
		return fareClass;
	}

	public void setFareClass(String fareClass) {
		this.fareClass = fareClass;
	}

	public String getFareCode() {
		return fareCode;
	}

	public void setFareCode(String fareCode) {
		this.fareCode = fareCode;
	}

	public PaxType getPaxType() {
		return paxType;
	}

	public void setPaxType(PaxType paxType) {
		this.paxType = paxType;
	}

	public MyIDBookingType getBookingType() {
		return bookingType;
	}

	public void setBookingType(MyIDBookingType myIDBookingType) {
		this.bookingType = myIDBookingType;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Integer getFareId() {
		return fareId;
	}

	public void setFareId(Integer fareId) {
		this.fareId = fareId;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public LocalDateTime getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(LocalDateTime createDateTime) {
		this.createDateTime = createDateTime;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public LocalDateTime getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(LocalDateTime updateDateTime) {
		this.updateDateTime = updateDateTime;
	}

	public BigDecimal getCadAmount() {
		if (cadAmount == null) {
			return this.amount;
		}
		return cadAmount;
	}

	public void setCadAmount(BigDecimal cadAmount) {
		this.cadAmount = cadAmount;
	}
}
