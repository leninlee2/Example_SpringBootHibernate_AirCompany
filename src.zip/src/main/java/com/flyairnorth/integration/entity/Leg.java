package com.flyairnorth.integration.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.flyairnorth.integration.enumerator.YesNo;

@Entity
@Table(name="leg")
public class Leg {

	@Column(name = "datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createDatetime;

	@Column(name = "fromcode", length=3)
	private String fromcode;

	@Column(name = "tocode", length=3)
	private String tocode;

	@Column(name = "tdepart", length=4)
	private String tdepart;

	@Column(name = "tarrive", length=4)
	private String tarrive;	

	@Column(name = "equip", length=3)
	private String equip;	

	@Id
	@Column(name = "legnum", nullable = true)
	private Integer legnum;	

	@Column(name = "tone")
	private Integer tone;	
	
	@Column(name = "ttwo")
	private Integer ttwo;	
	
	@Column(name = "tthree")
	private Integer tthree;	
	
	@Column(name = "tfour")
	private Integer tfour;	
	
	@Column(name = "tfive")
	private Integer tfive;	
	
	@Column(name = "wone")
	private Integer wone;	

	@Column(name = "wtwo")
	private Integer wtwo;	
	
	@Column(name = "wthree")
	private Integer wthree;	
	
	@Column(name = "wfour")
	private Integer wfour;	
	
	@Column(name = "wfive")
	private Integer wfive;	
	
	@Column(name = "distance")
	private Integer distance;	
	
	@Column(name = "day")
	private Integer day;	
	
	@Column(name = "assignseats")
	@Enumerated(EnumType.STRING)
	private YesNo assignseats;			
	
	@Column(name = "active")
	@Enumerated(EnumType.STRING)
	private YesNo active;
	
//	@Column(name = "createuserid", length = 45)
//	private String createUserid;

	public Date getCreateDatetime() {
		return createDatetime;
	}

	public void setCreateDatetime(Date createDatetime) {
		this.createDatetime = createDatetime;
	}

	public String getFromcode() {
		return fromcode;
	}

	public void setFromcode(String fromcode) {
		this.fromcode = fromcode;
	}

	public String getTocode() {
		return tocode;
	}

	public void setTocode(String tocode) {
		this.tocode = tocode;
	}

	public String getTdepart() {
		return tdepart;
	}

	public void setTdepart(String tdepart) {
		this.tdepart = tdepart;
	}

	public String getTarrive() {
		return tarrive;
	}

	public void setTarrive(String tarrive) {
		this.tarrive = tarrive;
	}

	public String getEquip() {
		return equip;
	}

	public void setEquip(String equip) {
		this.equip = equip;
	}

	public Integer getLegnum() {
		return legnum;
	}

	public void setLegnum(Integer legnum) {
		this.legnum = legnum;
	}

	public Integer getTone() {
		return tone;
	}

	public void setTone(Integer tone) {
		this.tone = tone;
	}

	public Integer getTtwo() {
		return ttwo;
	}

	public void setTtwo(Integer ttwo) {
		this.ttwo = ttwo;
	}

	public Integer getTthree() {
		return tthree;
	}

	public void setTthree(Integer tthree) {
		this.tthree = tthree;
	}

	public Integer getTfour() {
		return tfour;
	}

	public void setTfour(Integer tfour) {
		this.tfour = tfour;
	}

	public Integer getTfive() {
		return tfive;
	}

	public void setTfive(Integer tfive) {
		this.tfive = tfive;
	}

	public Integer getWone() {
		return wone;
	}

	public void setWone(Integer wone) {
		this.wone = wone;
	}

	public Integer getWtwo() {
		return wtwo;
	}

	public void setWtwo(Integer wtwo) {
		this.wtwo = wtwo;
	}

	public Integer getWthree() {
		return wthree;
	}

	public void setWthree(Integer wthree) {
		this.wthree = wthree;
	}

	public Integer getWfour() {
		return wfour;
	}

	public void setWfour(Integer wfour) {
		this.wfour = wfour;
	}

	public Integer getWfive() {
		return wfive;
	}

	public void setWfive(Integer wfive) {
		this.wfive = wfive;
	}

	public Integer getDistance() {
		return distance;
	}

	public void setDistance(Integer distance) {
		this.distance = distance;
	}

	public Integer getDay() {
		return day;
	}

	public void setDay(Integer day) {
		this.day = day;
	}

	public YesNo getAssignseats() {
		return assignseats;
	}

	public void setAssignseats(YesNo assignseats) {
		this.assignseats = assignseats;
	}

	public YesNo getActive() {
		return active;
	}

	public void setActive(YesNo active) {
		this.active = active;
	}

//	public String getCreateUserid() {
//		return createUserid;
//	}
//
//	public void setCreateUserid(String createUserid) {
//		this.createUserid = createUserid;
//	}
}
