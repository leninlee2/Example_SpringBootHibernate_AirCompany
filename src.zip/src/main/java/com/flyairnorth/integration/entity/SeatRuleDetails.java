package com.flyairnorth.integration.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.flyairnorth.integration.enumerator.YesNo;

@Entity
@Table(name = "seat_rule_details")
public class SeatRuleDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "rule_code", precision = 11)
	private Long ruleCode;
	
	@Column(name = "assigned_flight", length = 10)
	private String assignedFlight;
	
	@Column(name = "assigned_fromcode", length = 3)
	private String assignedFromCode;
	
	@Column(name = "assigned_tocode", length = 3)
	private String assignedToCode;
	
	@Column(name = "seat_color_code", length = 1)
	private String seatColorCode;
	
	@Column(name = "effect_flight", length = 10)
	private String effectFlight;
	
	@Column(name = "effect_fromcode", length = 3)
	private String effectFromCode;
	
	@Column(name = "effect_tocode", length = 3)
	private String effectToCode;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "active")
	private YesNo active;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "createdatetime")
	private Date createDatetime;
	
	@Column(name = "createuserid", length = 45)
	private String createUserId;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updatedatetime")
	private Date updateDatetime;
	
	@Column(name = "updateuserid", length = 45)
	private String updateUserId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getRuleCode() {
		return ruleCode;
	}

	public void setRuleCode(Long ruleCode) {
		this.ruleCode = ruleCode;
	}

	public String getAssignedFlight() {
		return assignedFlight;
	}

	public void setAssignedFlight(String assignedFlight) {
		this.assignedFlight = assignedFlight;
	}

	public String getAssignedFromCode() {
		return assignedFromCode;
	}

	public void setAssignedFromCode(String assignedFromCode) {
		this.assignedFromCode = assignedFromCode;
	}

	public String getAssignedToCode() {
		return assignedToCode;
	}

	public void setAssignedToCode(String assignedToCode) {
		this.assignedToCode = assignedToCode;
	}

	public String getSeatColorCode() {
		return seatColorCode;
	}

	public void setSeatColorCode(String seatColorCode) {
		this.seatColorCode = seatColorCode;
	}

	public String getEffectFlight() {
		return effectFlight;
	}

	public void setEffectFlight(String effectFlight) {
		this.effectFlight = effectFlight;
	}

	public String getEffectFromCode() {
		return effectFromCode;
	}

	public void setEffectFromCode(String effectFromCode) {
		this.effectFromCode = effectFromCode;
	}

	public String getEffectToCode() {
		return effectToCode;
	}

	public void setEffectToCode(String effectToCode) {
		this.effectToCode = effectToCode;
	}

	public YesNo getActive() {
		return active;
	}

	public void setActive(YesNo active) {
		this.active = active;
	}

	public Date getCreateDatetime() {
		return createDatetime;
	}

	public void setCreateDatetime(Date createDatetime) {
		this.createDatetime = createDatetime;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Date getUpdateDatetime() {
		return updateDatetime;
	}

	public void setUpdateDatetime(Date updateDatetime) {
		this.updateDatetime = updateDatetime;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}
}
