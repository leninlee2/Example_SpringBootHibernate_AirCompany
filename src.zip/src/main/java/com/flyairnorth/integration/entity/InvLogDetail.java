package com.flyairnorth.integration.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "invlogdtl")
public class InvLogDetail {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "invlog_id")
	private InvLog invLog;

	@Column(name = "fareCode", length = 20, nullable = false)
	private String fareCode;

	@Column(name = "fareclasss", length = 45)
	private String fareClass;

	@Column(name = "current_allowed_inv")
	private Integer currentAllowedInv;

	@Column(name = "new_allowed_inv")
	private Integer newAllowedInv;

	@Column(name = "Current_sold_inv")
	private Integer currentSoldInv;

	@Column(name = "createuserid", length = 30)
	private String createUserId;

	@Column(name = "createdatetime")
	private LocalDateTime createdatetime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public InvLog getInvLog() {
		return invLog;
	}

	public void setInvLog(InvLog invLog) {
		this.invLog = invLog;
	}

	public String getFareCode() {
		return fareCode;
	}

	public void setFareCode(String fareCode) {
		this.fareCode = fareCode;
	}

	public String getFareClass() {
		return fareClass;
	}

	public void setFareClass(String fareClass) {
		this.fareClass = fareClass;
	}

	public Integer getCurrentAllowedInv() {
		return currentAllowedInv;
	}

	public void setCurrentAllowedInv(Integer currentAllowedInv) {
		this.currentAllowedInv = currentAllowedInv;
	}

	public Integer getNewAllowedInv() {
		return newAllowedInv;
	}

	public void setNewAllowedInv(Integer newAllowedInv) {
		this.newAllowedInv = newAllowedInv;
	}

	public Integer getCurrentSoldInv() {
		return currentSoldInv;
	}

	public void setCurrentSoldInv(Integer currentSoldInv) {
		this.currentSoldInv = currentSoldInv;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public LocalDateTime getCreatedatetime() {
		return createdatetime;
	}

	public void setCreatedatetime(LocalDateTime createdatetime) {
		this.createdatetime = createdatetime;
	}
}
