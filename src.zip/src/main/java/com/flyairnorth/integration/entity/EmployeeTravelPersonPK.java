package com.flyairnorth.integration.entity;

import java.io.Serializable;

public class EmployeeTravelPersonPK implements Serializable {

	private static final long serialVersionUID = -5326409903682588804L;
	protected String passengerId;
	protected String type;
	protected String first;
	protected String last;

	public EmployeeTravelPersonPK() {
	}

	public EmployeeTravelPersonPK(String passengerId, String type, String first, String last) {
		super();
		this.passengerId = passengerId;
		this.type = type;
		this.first = first;
		this.last = last;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((first == null) ? 0 : first.hashCode());
		result = prime * result + ((last == null) ? 0 : last.hashCode());
		result = prime * result + ((passengerId == null) ? 0 : passengerId.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeTravelPersonPK other = (EmployeeTravelPersonPK) obj;
		if (first == null) {
			if (other.first != null)
				return false;
		} else if (!first.equals(other.first))
			return false;
		if (last == null) {
			if (other.last != null)
				return false;
		} else if (!last.equals(other.last))
			return false;
		if (passengerId == null) {
			if (other.passengerId != null)
				return false;
		} else if (!passengerId.equals(other.passengerId))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}
}
