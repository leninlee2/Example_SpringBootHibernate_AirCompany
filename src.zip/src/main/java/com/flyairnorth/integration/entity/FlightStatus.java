package com.flyairnorth.integration.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.flyairnorth.integration.enumerator.Status;
import com.flyairnorth.integration.enumerator.YesNo;

@Entity
@Table(name = "flight_status")
@IdClass(FlightStatusPK.class)
public class FlightStatus {

	@Column(name = "datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date datetime;

	@Column(name = "username", length = 17)
	private String username;

	@Id
	@Column(name = "flight", length = 10)
	private String flight;

	@Id
	@Column(name = "fdate")
	@Temporal(TemporalType.DATE)
	private Date fdate;

	@Column(name = "fromcode", length = 3)
	private String fromcode;

	@Column(name = "tocode", length = 3)
	private String tocode;

	@Column(name = "status")
	private Status status;

	@Column(name = "group_code", length = 6)
	private String groupCode;

	@Column(name = "code", length = 3)
	private String code;

	@Column(name = "code_description", length = 200)
	private String codeDescription;

	@Column(name = "delaytime", length = 10)
	private String delayTime;

	@Column(name = "group_code2", length = 6)
	private String groupCode2;

	@Column(name = "code2", length = 3)
	private String code2;

	@Column(name = "delaytime2", length = 10)
	private String delayTime2;

	@Column(name = "group_code3", length = 6)
	private String groupCode3;

	@Column(name = "code3", length = 3)
	private String code3;

	@Column(name = "code_description3", length = 200)
	private String codeDescription3;

	@Column(name = "delaytime3", length = 10)
	private String delayTime3;

	@Column(name = "group_code4", length = 6)
	private String groupCode4;

	@Column(name = "code4", length = 3)
	private String code4;

	@Column(name = "code_description4", length = 200)
	private String codeDescription4;

	@Column(name = "delaytime4", length = 10)
	private String delayTime4;

	@Column(name = "group_code5", length = 6)
	private String groupCode5;

	@Column(name = "code5", length = 3)
	private String code5;

	@Column(name = "code_description5", length = 200)
	private String codeDescription5;

	@Column(name = "delaytime5", length = 10)
	private String delayTime5;

	@Column(name = "code_desciption2", length = 200)
	private String codeDescription2;

	@Column(name = "scheduled_departure")
	@Temporal(TemporalType.TIMESTAMP)
	private Date scheduledDeparture;

	@Column(name = "scheduled_arrival")
	@Temporal(TemporalType.TIMESTAMP)
	private Date scheduledArrival;

	@Column(name = "estimated_departure")
	@Temporal(TemporalType.TIMESTAMP)
	private Date estimated_departure;

	@Column(name = "estimated_arrival")
	@Temporal(TemporalType.TIMESTAMP)
	private Date estimatedArrival;

	@Column(name = "actual_departure")
	@Temporal(TemporalType.TIMESTAMP)
	private Date actualDeparture;

	@Column(name = "actual_arrival")
	@Temporal(TemporalType.TIMESTAMP)
	private Date actualArrival;

	@Column(name = "offblocks")
	@Temporal(TemporalType.TIMESTAMP)
	private Date offBlocks;

	@Column(name = "onblocks")
	@Temporal(TemporalType.TIMESTAMP)
	private Date onBlocks;

	@Column(name = "airborne")
	@Temporal(TemporalType.TIMESTAMP)
	private Date airborne;

	@Column(name = "touchdown")
	@Temporal(TemporalType.TIMESTAMP)
	private Date touchdown;

	@Column(name = "public_comment", length = 255)
	private String publicComment;

	@Column(name = "private_comment")
	private String privateComment;

	@Column(name = "private_comment2", length = 255)
	private String privateComment2;

	@Column(name = "checkin_open")
	@Temporal(TemporalType.TIMESTAMP)
	private Date checkinOpen;

	@Column(name = "boarding_open")
	@Temporal(TemporalType.TIMESTAMP)
	private Date boardingOpen;

	@Column(name = "boarding_gate", length = 5)
	private String boardingGate;

	@Column(name = "isOnline")
  	private YesNo isOnline;

	public Date getDatetime() {
		return datetime;
	}

	public void setDatetime(Date datetime) {
		this.datetime = datetime;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFlight() {
		return flight;
	}

	public void setFlight(String flight) {
		this.flight = flight;
	}

	public Date getFdate() {
		return fdate;
	}

	public void setFdate(Date fdate) {
		this.fdate = fdate;
	}

	public String getFromcode() {
		return fromcode;
	}

	public void setFromcode(String fromcode) {
		this.fromcode = fromcode;
	}

	public String getTocode() {
		return tocode;
	}

	public void setTocode(String tocode) {
		this.tocode = tocode;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCodeDescription() {
		return codeDescription;
	}

	public void setCodeDescription(String codeDescription) {
		this.codeDescription = codeDescription;
	}

	public String getDelayTime() {
		return delayTime;
	}

	public void setDelayTime(String delayTime) {
		this.delayTime = delayTime;
	}

	public String getGroupCode2() {
		return groupCode2;
	}

	public void setGroupCode2(String groupCode2) {
		this.groupCode2 = groupCode2;
	}

	public String getCode2() {
		return code2;
	}

	public void setCode2(String code2) {
		this.code2 = code2;
	}

	public String getDelayTime2() {
		return delayTime2;
	}

	public void setDelayTime2(String delayTime2) {
		this.delayTime2 = delayTime2;
	}

	public String getGroupCode3() {
		return groupCode3;
	}

	public void setGroupCode3(String groupCode3) {
		this.groupCode3 = groupCode3;
	}

	public String getCode3() {
		return code3;
	}

	public void setCode3(String code3) {
		this.code3 = code3;
	}

	public String getCodeDescription3() {
		return codeDescription3;
	}

	public void setCodeDescription3(String codeDescription3) {
		this.codeDescription3 = codeDescription3;
	}

	public String getDelayTime3() {
		return delayTime3;
	}

	public void setDelayTime3(String delayTime3) {
		this.delayTime3 = delayTime3;
	}

	public String getGroupCode4() {
		return groupCode4;
	}

	public void setGroupCode4(String groupCode4) {
		this.groupCode4 = groupCode4;
	}

	public String getCode4() {
		return code4;
	}

	public void setCode4(String code4) {
		this.code4 = code4;
	}

	public String getCodeDescription4() {
		return codeDescription4;
	}

	public void setCodeDescription4(String codeDescription4) {
		this.codeDescription4 = codeDescription4;
	}

	public String getDelayTime4() {
		return delayTime4;
	}

	public void setDelayTime4(String delayTime4) {
		this.delayTime4 = delayTime4;
	}

	public String getGroupCode5() {
		return groupCode5;
	}

	public void setGroupCode5(String groupCode5) {
		this.groupCode5 = groupCode5;
	}

	public String getCode5() {
		return code5;
	}

	public void setCode5(String code5) {
		this.code5 = code5;
	}

	public String getCodeDescription5() {
		return codeDescription5;
	}

	public void setCodeDescription5(String codeDescription5) {
		this.codeDescription5 = codeDescription5;
	}

	public String getDelayTime5() {
		return delayTime5;
	}

	public void setDelayTime5(String delayTime5) {
		this.delayTime5 = delayTime5;
	}

	public String getCodeDescription2() {
		return codeDescription2;
	}

	public void setCodeDescription2(String codeDescription2) {
		this.codeDescription2 = codeDescription2;
	}

	public Date getScheduledDeparture() {
		return scheduledDeparture;
	}

	public void setScheduledDeparture(Date scheduledDeparture) {
		this.scheduledDeparture = scheduledDeparture;
	}

	public Date getScheduledArrival() {
		return scheduledArrival;
	}

	public void setScheduledArrival(Date scheduledArrival) {
		this.scheduledArrival = scheduledArrival;
	}

	public Date getEstimated_departure() {
		return estimated_departure;
	}

	public void setEstimated_departure(Date estimated_departure) {
		this.estimated_departure = estimated_departure;
	}

	public Date getEstimatedArrival() {
		return estimatedArrival;
	}

	public void setEstimatedArrival(Date estimatedArrival) {
		this.estimatedArrival = estimatedArrival;
	}

	public Date getActualDeparture() {
		return actualDeparture;
	}

	public void setActualDeparture(Date actualDeparture) {
		this.actualDeparture = actualDeparture;
	}

	public Date getActualArrival() {
		return actualArrival;
	}

	public void setActualArrival(Date actualArrival) {
		this.actualArrival = actualArrival;
	}

	public Date getOffBlocks() {
		return offBlocks;
	}

	public void setOffBlocks(Date offBlocks) {
		this.offBlocks = offBlocks;
	}

	public Date getOnBlocks() {
		return onBlocks;
	}

	public void setOnBlocks(Date onBlocks) {
		this.onBlocks = onBlocks;
	}

	public Date getAirborne() {
		return airborne;
	}

	public void setAirborne(Date airborne) {
		this.airborne = airborne;
	}

	public Date getTouchdown() {
		return touchdown;
	}

	public void setTouchdown(Date touchdown) {
		this.touchdown = touchdown;
	}

	public String getPublicComment() {
		return publicComment;
	}

	public void setPublicComment(String publicComment) {
		this.publicComment = publicComment;
	}

	public String getPrivateComment() {
		return privateComment;
	}

	public void setPrivateComment(String privateComment) {
		this.privateComment = privateComment;
	}

	public String getPrivateComment2() {
		return privateComment2;
	}

	public void setPrivateComment2(String privateComment2) {
		this.privateComment2 = privateComment2;
	}

	public Date getCheckinOpen() {
		return checkinOpen;
	}

	public void setCheckinOpen(Date checkinOpen) {
		this.checkinOpen = checkinOpen;
	}

	public Date getBoardingOpen() {
		return boardingOpen;
	}

	public void setBoardingOpen(Date boardingOpen) {
		this.boardingOpen = boardingOpen;
	}

	public String getBoardingGate() {
		return boardingGate;
	}

	public void setBoardingGate(String boardingGate) {
		this.boardingGate = boardingGate;
	}

	public YesNo getIsOnline() {
		return isOnline;
	}

	public void setIsOnline(YesNo isOnline) {
		this.isOnline = isOnline;
	}
}
