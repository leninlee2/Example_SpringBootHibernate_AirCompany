
package com.flyairnorth.integration.org.opentravel.ota._2003._05;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for List_OfferDistanceUOM.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="List_OfferDistanceUOM">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Block"/>
 *     &lt;enumeration value="Mile"/>
 *     &lt;enumeration value="Kilometer"/>
 *     &lt;enumeration value="Other_"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "List_OfferDistanceUOM")
@XmlEnum
public enum ListOfferDistanceUOM {

    @XmlEnumValue("Block")
    BLOCK("Block"),
    @XmlEnumValue("Mile")
    MILE("Mile"),
    @XmlEnumValue("Kilometer")
    KILOMETER("Kilometer"),

    /**
     * This is a string list of enumerations with an "Other_" literal to support an open enumeration list. Use the "Other_" value in combination with the @OtherType attribute to exchange a literal that is not in the list and is known to your trading partners.
     * 
     */
    @XmlEnumValue("Other_")
    OTHER("Other_");
    private final String value;

    ListOfferDistanceUOM(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ListOfferDistanceUOM fromValue(String v) {
        for (ListOfferDistanceUOM c: ListOfferDistanceUOM.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
