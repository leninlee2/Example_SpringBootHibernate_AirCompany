
package com.flyairnorth.integration.org.opentravel.ota._2003._05;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Priced ancillary offer information.
 * 
 * <p>Java class for AirPricedOfferType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AirPricedOfferType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ServiceFamily" type="{http://www.opentravel.org/OTA/2003/05}AncillaryServiceDetailType"/>
 *         &lt;element name="ShortDescription" type="{http://www.opentravel.org/OTA/2003/05}FormattedTextTextType" maxOccurs="9" minOccurs="0"/>
 *         &lt;element name="LongDescription" type="{http://www.opentravel.org/OTA/2003/05}FormattedTextType" maxOccurs="9" minOccurs="0"/>
 *         &lt;element name="Pricing">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="PricingDetail" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="TaxInfo" type="{http://www.opentravel.org/OTA/2003/05}TaxType" maxOccurs="99" minOccurs="0"/>
 *                             &lt;element name="RedemptionPoints" type="{http://www.opentravel.org/OTA/2003/05}AirRedemptionMilesType" minOccurs="0"/>
 *                           &lt;/sequence>
 *                           &lt;attribute name="TravelerRPH" type="{http://www.opentravel.org/OTA/2003/05}RPH_Type" />
 *                           &lt;attribute name="OfferPricingRefID" type="{http://www.opentravel.org/OTA/2003/05}RPH_Type" />
 *                           &lt;attribute name="PreTaxAmount" type="{http://www.opentravel.org/OTA/2003/05}Money" />
 *                           &lt;attribute name="TaxAmount" type="{http://www.opentravel.org/OTA/2003/05}Money" />
 *                           &lt;attribute name="Amount" type="{http://www.opentravel.org/OTA/2003/05}Money" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="TaxInfo" type="{http://www.opentravel.org/OTA/2003/05}TaxType" maxOccurs="99" minOccurs="0"/>
 *                   &lt;element name="RedemptionPoints" type="{http://www.opentravel.org/OTA/2003/05}AirRedemptionMilesType" minOccurs="0"/>
 *                   &lt;element name="AppliedRule" type="{http://www.opentravel.org/OTA/2003/05}AppliedRuleType" maxOccurs="99" minOccurs="0"/>
 *                   &lt;element name="PricingQualifier" type="{http://www.opentravel.org/OTA/2003/05}AirPricingQualifierType" maxOccurs="99" minOccurs="0"/>
 *                   &lt;element name="ApplyTo" type="{http://www.opentravel.org/OTA/2003/05}ApplyPriceToType" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attGroup ref="{http://www.opentravel.org/OTA/2003/05}ExchangeRateGroup"/>
 *                 &lt;attribute name="OfferQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                 &lt;attribute name="PassengerQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                 &lt;attribute name="PreTaxAmount" type="{http://www.opentravel.org/OTA/2003/05}Money" />
 *                 &lt;attribute name="TaxAmount" type="{http://www.opentravel.org/OTA/2003/05}Money" />
 *                 &lt;attribute name="Amount" type="{http://www.opentravel.org/OTA/2003/05}Money" />
 *                 &lt;attribute name="PricingCurrency" type="{http://www.opentravel.org/OTA/2003/05}AlphaLength3" />
 *                 &lt;attribute name="DecimalPlaces" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *                 &lt;attribute name="BaseNUC_Amount" type="{http://www.opentravel.org/OTA/2003/05}Money" />
 *                 &lt;attribute name="OfferRPH" type="{http://www.opentravel.org/OTA/2003/05}RPH_Type" />
 *                 &lt;attribute name="TravelerRPH" type="{http://www.opentravel.org/OTA/2003/05}ListOfRPH" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="OriginDestination" maxOccurs="10" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OriginDestinationInformationType">
 *                 &lt;sequence>
 *                   &lt;element name="AlternateLocationInfo" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;attribute name="OriginLocation" type="{http://www.opentravel.org/OTA/2003/05}ListOfStringLength1to8" />
 *                           &lt;attribute name="DestinationLocation" type="{http://www.opentravel.org/OTA/2003/05}ListOfStringLength1to8" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element ref="{http://www.opentravel.org/OTA/2003/05}TPA_Extensions" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="RPH" type="{http://www.opentravel.org/OTA/2003/05}RPH_Type" />
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="SeatInfo" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}AirSeatMarketingClassType">
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="OtherServices" maxOccurs="99" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}AirLandProductType">
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="TripInsurance" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="CoveredTraveler" maxOccurs="9" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;extension base="{http://www.opentravel.org/OTA/2003/05}SearchTravelerType">
 *                           &lt;attribute name="TravelerRPH" type="{http://www.opentravel.org/OTA/2003/05}RPH_Type" />
 *                         &lt;/extension>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="CoverageLimit" type="{http://www.opentravel.org/OTA/2003/05}CoverageLimitType" minOccurs="0"/>
 *                   &lt;element name="PlanCost" type="{http://www.opentravel.org/OTA/2003/05}PlanCostType" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attGroup ref="{http://www.opentravel.org/OTA/2003/05}DateTimeSpanGroup"/>
 *                 &lt;attribute name="Code" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="SellingComponentCode" type="{http://www.w3.org/2001/XMLSchema}string" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BookingInstruction" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="SSR_Info" type="{http://www.opentravel.org/OTA/2003/05}SpecialServiceRequestType" maxOccurs="unbounded" minOccurs="0"/>
 *                   &lt;element name="OSI_Info" type="{http://www.opentravel.org/OTA/2003/05}OtherServiceInfoType" maxOccurs="unbounded" minOccurs="0"/>
 *                   &lt;element name="Upgrade" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="Instruction" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                           &lt;/sequence>
 *                           &lt;attribute name="UpgradeMethod">
 *                             &lt;simpleType>
 *                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                 &lt;enumeration value="S_SpecialServiceRequest"/>
 *                                 &lt;enumeration value="A_AutoUpgrade"/>
 *                               &lt;/restriction>
 *                             &lt;/simpleType>
 *                           &lt;/attribute>
 *                           &lt;attribute name="UpgradeDesigCode" type="{http://www.opentravel.org/OTA/2003/05}UpperCaseAlphaLength1to2" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *                 &lt;attribute name="BookingMethod">
 *                   &lt;simpleType>
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;enumeration value="SSR_SpecialServiceRequest"/>
 *                       &lt;enumeration value="OSI_OtherServiceInformation"/>
 *                       &lt;enumeration value="API_AdvancedPassengerInformation"/>
 *                     &lt;/restriction>
 *                   &lt;/simpleType>
 *                 &lt;/attribute>
 *                 &lt;attribute name="EMD_Type">
 *                   &lt;simpleType>
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;enumeration value="EMD-S"/>
 *                       &lt;enumeration value="EMD-A"/>
 *                     &lt;/restriction>
 *                   &lt;/simpleType>
 *                 &lt;/attribute>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Restriction" maxOccurs="99" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="TripMinOfferQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                 &lt;attribute name="TripMaxOfferQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                 &lt;attribute name="TravelerMinOfferQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                 &lt;attribute name="TravelerMaxOfferQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                 &lt;attribute name="EffectiveDate" type="{http://www.w3.org/2001/XMLSchema}date" />
 *                 &lt;attribute name="ExpireDate" type="{http://www.w3.org/2001/XMLSchema}date" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="TermsAndConditions" maxOccurs="99" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="VoluntaryChanges" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;extension base="{http://www.opentravel.org/OTA/2003/05}VoluntaryChangesType">
 *                           &lt;attribute name="Description" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                         &lt;/extension>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="VoluntaryRefunds" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;extension base="{http://www.opentravel.org/OTA/2003/05}VoluntaryChangesType">
 *                           &lt;attribute name="Description" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                         &lt;/extension>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="Other" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="RefundableInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *                 &lt;attribute name="ReusableFundsInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Commission" type="{http://www.opentravel.org/OTA/2003/05}CommissionType" maxOccurs="9" minOccurs="0"/>
 *         &lt;element name="Multimedia" maxOccurs="9" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}ImageDescriptionType">
 *                 &lt;attribute name="Sequence" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                 &lt;attribute name="ContentUsageType" type="{http://www.w3.org/2001/XMLSchema}string" />
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BookingReferenceID" type="{http://www.opentravel.org/OTA/2003/05}UniqueID_Type" maxOccurs="99" minOccurs="0"/>
 *         &lt;element ref="{http://www.opentravel.org/OTA/2003/05}TPA_Extensions" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="ID" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="BundleInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="BundleID" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Name" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="MandatoryInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="AcceptInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="TripInsuranceInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AirPricedOfferType", propOrder = {
    "serviceFamily",
    "shortDescription",
    "longDescription",
    "pricing",
    "originDestination",
    "seatInfo",
    "otherServices",
    "tripInsurance",
    "bookingInstruction",
    "restriction",
    "termsAndConditions",
    "commission",
    "multimedia",
    "bookingReferenceID",
    "tpaExtensions"
})
@XmlSeeAlso({
    com.flyairnorth.integration.org.opentravel.ota._2003._05.AirOfferChoiceType.Priced.class
})
public class AirPricedOfferType {

    @XmlElement(name = "ServiceFamily", required = true)
    protected AncillaryServiceDetailType serviceFamily;
    @XmlElement(name = "ShortDescription")
    protected List<FormattedTextTextType> shortDescription;
    @XmlElement(name = "LongDescription")
    protected List<FormattedTextType> longDescription;
    @XmlElement(name = "Pricing", required = true)
    protected AirPricedOfferType.Pricing pricing;
    @XmlElement(name = "OriginDestination")
    protected List<AirPricedOfferType.OriginDestination> originDestination;
    @XmlElement(name = "SeatInfo")
    protected AirPricedOfferType.SeatInfo seatInfo;
    @XmlElement(name = "OtherServices")
    protected List<AirPricedOfferType.OtherServices> otherServices;
    @XmlElement(name = "TripInsurance")
    protected AirPricedOfferType.TripInsurance tripInsurance;
    @XmlElement(name = "BookingInstruction")
    protected AirPricedOfferType.BookingInstruction bookingInstruction;
    @XmlElement(name = "Restriction")
    protected List<AirPricedOfferType.Restriction> restriction;
    @XmlElement(name = "TermsAndConditions")
    protected List<AirPricedOfferType.TermsAndConditions> termsAndConditions;
    @XmlElement(name = "Commission")
    protected List<CommissionType> commission;
    @XmlElement(name = "Multimedia")
    protected List<AirPricedOfferType.Multimedia> multimedia;
    @XmlElement(name = "BookingReferenceID")
    protected List<UniqueIDType> bookingReferenceID;
    @XmlElement(name = "TPA_Extensions")
    protected TPAExtensionsType tpaExtensions;
    @XmlAttribute(name = "ID")
    protected String id;
    @XmlAttribute(name = "BundleInd")
    protected Boolean bundleInd;
    @XmlAttribute(name = "BundleID")
    protected String bundleID;
    @XmlAttribute(name = "Name")
    protected String name;
    @XmlAttribute(name = "MandatoryInd")
    protected Boolean mandatoryInd;
    @XmlAttribute(name = "AcceptInd")
    protected Boolean acceptInd;
    @XmlAttribute(name = "TripInsuranceInd")
    protected Boolean tripInsuranceInd;

    /**
     * Gets the value of the serviceFamily property.
     * 
     * @return
     *     possible object is
     *     {@link AncillaryServiceDetailType }
     *     
     */
    public AncillaryServiceDetailType getServiceFamily() {
        return serviceFamily;
    }

    /**
     * Sets the value of the serviceFamily property.
     * 
     * @param value
     *     allowed object is
     *     {@link AncillaryServiceDetailType }
     *     
     */
    public void setServiceFamily(AncillaryServiceDetailType value) {
        this.serviceFamily = value;
    }

    /**
     * Gets the value of the shortDescription property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the shortDescription property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getShortDescription().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FormattedTextTextType }
     * 
     * 
     */
    public List<FormattedTextTextType> getShortDescription() {
        if (shortDescription == null) {
            shortDescription = new ArrayList<FormattedTextTextType>();
        }
        return this.shortDescription;
    }

    /**
     * Gets the value of the longDescription property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the longDescription property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLongDescription().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FormattedTextType }
     * 
     * 
     */
    public List<FormattedTextType> getLongDescription() {
        if (longDescription == null) {
            longDescription = new ArrayList<FormattedTextType>();
        }
        return this.longDescription;
    }

    /**
     * Gets the value of the pricing property.
     * 
     * @return
     *     possible object is
     *     {@link AirPricedOfferType.Pricing }
     *     
     */
    public AirPricedOfferType.Pricing getPricing() {
        return pricing;
    }

    /**
     * Sets the value of the pricing property.
     * 
     * @param value
     *     allowed object is
     *     {@link AirPricedOfferType.Pricing }
     *     
     */
    public void setPricing(AirPricedOfferType.Pricing value) {
        this.pricing = value;
    }

    /**
     * Gets the value of the originDestination property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the originDestination property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOriginDestination().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AirPricedOfferType.OriginDestination }
     * 
     * 
     */
    public List<AirPricedOfferType.OriginDestination> getOriginDestination() {
        if (originDestination == null) {
            originDestination = new ArrayList<AirPricedOfferType.OriginDestination>();
        }
        return this.originDestination;
    }

    /**
     * Gets the value of the seatInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AirPricedOfferType.SeatInfo }
     *     
     */
    public AirPricedOfferType.SeatInfo getSeatInfo() {
        return seatInfo;
    }

    /**
     * Sets the value of the seatInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AirPricedOfferType.SeatInfo }
     *     
     */
    public void setSeatInfo(AirPricedOfferType.SeatInfo value) {
        this.seatInfo = value;
    }

    /**
     * Gets the value of the otherServices property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the otherServices property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOtherServices().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AirPricedOfferType.OtherServices }
     * 
     * 
     */
    public List<AirPricedOfferType.OtherServices> getOtherServices() {
        if (otherServices == null) {
            otherServices = new ArrayList<AirPricedOfferType.OtherServices>();
        }
        return this.otherServices;
    }

    /**
     * Gets the value of the tripInsurance property.
     * 
     * @return
     *     possible object is
     *     {@link AirPricedOfferType.TripInsurance }
     *     
     */
    public AirPricedOfferType.TripInsurance getTripInsurance() {
        return tripInsurance;
    }

    /**
     * Sets the value of the tripInsurance property.
     * 
     * @param value
     *     allowed object is
     *     {@link AirPricedOfferType.TripInsurance }
     *     
     */
    public void setTripInsurance(AirPricedOfferType.TripInsurance value) {
        this.tripInsurance = value;
    }

    /**
     * Gets the value of the bookingInstruction property.
     * 
     * @return
     *     possible object is
     *     {@link AirPricedOfferType.BookingInstruction }
     *     
     */
    public AirPricedOfferType.BookingInstruction getBookingInstruction() {
        return bookingInstruction;
    }

    /**
     * Sets the value of the bookingInstruction property.
     * 
     * @param value
     *     allowed object is
     *     {@link AirPricedOfferType.BookingInstruction }
     *     
     */
    public void setBookingInstruction(AirPricedOfferType.BookingInstruction value) {
        this.bookingInstruction = value;
    }

    /**
     * Gets the value of the restriction property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the restriction property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRestriction().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AirPricedOfferType.Restriction }
     * 
     * 
     */
    public List<AirPricedOfferType.Restriction> getRestriction() {
        if (restriction == null) {
            restriction = new ArrayList<AirPricedOfferType.Restriction>();
        }
        return this.restriction;
    }

    /**
     * Gets the value of the termsAndConditions property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the termsAndConditions property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTermsAndConditions().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AirPricedOfferType.TermsAndConditions }
     * 
     * 
     */
    public List<AirPricedOfferType.TermsAndConditions> getTermsAndConditions() {
        if (termsAndConditions == null) {
            termsAndConditions = new ArrayList<AirPricedOfferType.TermsAndConditions>();
        }
        return this.termsAndConditions;
    }

    /**
     * Gets the value of the commission property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the commission property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCommission().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CommissionType }
     * 
     * 
     */
    public List<CommissionType> getCommission() {
        if (commission == null) {
            commission = new ArrayList<CommissionType>();
        }
        return this.commission;
    }

    /**
     * Gets the value of the multimedia property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the multimedia property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMultimedia().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AirPricedOfferType.Multimedia }
     * 
     * 
     */
    public List<AirPricedOfferType.Multimedia> getMultimedia() {
        if (multimedia == null) {
            multimedia = new ArrayList<AirPricedOfferType.Multimedia>();
        }
        return this.multimedia;
    }

    /**
     * Gets the value of the bookingReferenceID property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the bookingReferenceID property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBookingReferenceID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link UniqueIDType }
     * 
     * 
     */
    public List<UniqueIDType> getBookingReferenceID() {
        if (bookingReferenceID == null) {
            bookingReferenceID = new ArrayList<UniqueIDType>();
        }
        return this.bookingReferenceID;
    }

    /**
     * Gets the value of the tpaExtensions property.
     * 
     * @return
     *     possible object is
     *     {@link TPAExtensionsType }
     *     
     */
    public TPAExtensionsType getTPAExtensions() {
        return tpaExtensions;
    }

    /**
     * Sets the value of the tpaExtensions property.
     * 
     * @param value
     *     allowed object is
     *     {@link TPAExtensionsType }
     *     
     */
    public void setTPAExtensions(TPAExtensionsType value) {
        this.tpaExtensions = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getID() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setID(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the bundleInd property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isBundleInd() {
        return bundleInd;
    }

    /**
     * Sets the value of the bundleInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setBundleInd(Boolean value) {
        this.bundleInd = value;
    }

    /**
     * Gets the value of the bundleID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBundleID() {
        return bundleID;
    }

    /**
     * Sets the value of the bundleID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBundleID(String value) {
        this.bundleID = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the mandatoryInd property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMandatoryInd() {
        return mandatoryInd;
    }

    /**
     * Sets the value of the mandatoryInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMandatoryInd(Boolean value) {
        this.mandatoryInd = value;
    }

    /**
     * Gets the value of the acceptInd property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAcceptInd() {
        return acceptInd;
    }

    /**
     * Sets the value of the acceptInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAcceptInd(Boolean value) {
        this.acceptInd = value;
    }

    /**
     * Gets the value of the tripInsuranceInd property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isTripInsuranceInd() {
        return tripInsuranceInd;
    }

    /**
     * Sets the value of the tripInsuranceInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setTripInsuranceInd(Boolean value) {
        this.tripInsuranceInd = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="SSR_Info" type="{http://www.opentravel.org/OTA/2003/05}SpecialServiceRequestType" maxOccurs="unbounded" minOccurs="0"/>
     *         &lt;element name="OSI_Info" type="{http://www.opentravel.org/OTA/2003/05}OtherServiceInfoType" maxOccurs="unbounded" minOccurs="0"/>
     *         &lt;element name="Upgrade" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Instruction" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *                 &lt;/sequence>
     *                 &lt;attribute name="UpgradeMethod">
     *                   &lt;simpleType>
     *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                       &lt;enumeration value="S_SpecialServiceRequest"/>
     *                       &lt;enumeration value="A_AutoUpgrade"/>
     *                     &lt;/restriction>
     *                   &lt;/simpleType>
     *                 &lt;/attribute>
     *                 &lt;attribute name="UpgradeDesigCode" type="{http://www.opentravel.org/OTA/2003/05}UpperCaseAlphaLength1to2" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *       &lt;attribute name="BookingMethod">
     *         &lt;simpleType>
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;enumeration value="SSR_SpecialServiceRequest"/>
     *             &lt;enumeration value="OSI_OtherServiceInformation"/>
     *             &lt;enumeration value="API_AdvancedPassengerInformation"/>
     *           &lt;/restriction>
     *         &lt;/simpleType>
     *       &lt;/attribute>
     *       &lt;attribute name="EMD_Type">
     *         &lt;simpleType>
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;enumeration value="EMD-S"/>
     *             &lt;enumeration value="EMD-A"/>
     *           &lt;/restriction>
     *         &lt;/simpleType>
     *       &lt;/attribute>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "ssrInfo",
        "osiInfo",
        "upgrade"
    })
    public static class BookingInstruction {

        @XmlElement(name = "SSR_Info")
        protected List<SpecialServiceRequestType> ssrInfo;
        @XmlElement(name = "OSI_Info")
        protected List<OtherServiceInfoType> osiInfo;
        @XmlElement(name = "Upgrade")
        protected AirPricedOfferType.BookingInstruction.Upgrade upgrade;
        @XmlAttribute(name = "BookingMethod")
        protected String bookingMethod;
        @XmlAttribute(name = "EMD_Type")
        protected String emdType;

        /**
         * Gets the value of the ssrInfo property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the ssrInfo property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getSSRInfo().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link SpecialServiceRequestType }
         * 
         * 
         */
        public List<SpecialServiceRequestType> getSSRInfo() {
            if (ssrInfo == null) {
                ssrInfo = new ArrayList<SpecialServiceRequestType>();
            }
            return this.ssrInfo;
        }

        /**
         * Gets the value of the osiInfo property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the osiInfo property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getOSIInfo().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link OtherServiceInfoType }
         * 
         * 
         */
        public List<OtherServiceInfoType> getOSIInfo() {
            if (osiInfo == null) {
                osiInfo = new ArrayList<OtherServiceInfoType>();
            }
            return this.osiInfo;
        }

        /**
         * Gets the value of the upgrade property.
         * 
         * @return
         *     possible object is
         *     {@link AirPricedOfferType.BookingInstruction.Upgrade }
         *     
         */
        public AirPricedOfferType.BookingInstruction.Upgrade getUpgrade() {
            return upgrade;
        }

        /**
         * Sets the value of the upgrade property.
         * 
         * @param value
         *     allowed object is
         *     {@link AirPricedOfferType.BookingInstruction.Upgrade }
         *     
         */
        public void setUpgrade(AirPricedOfferType.BookingInstruction.Upgrade value) {
            this.upgrade = value;
        }

        /**
         * Gets the value of the bookingMethod property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getBookingMethod() {
            return bookingMethod;
        }

        /**
         * Sets the value of the bookingMethod property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setBookingMethod(String value) {
            this.bookingMethod = value;
        }

        /**
         * Gets the value of the emdType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getEMDType() {
            return emdType;
        }

        /**
         * Sets the value of the emdType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setEMDType(String value) {
            this.emdType = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="Instruction" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
         *       &lt;/sequence>
         *       &lt;attribute name="UpgradeMethod">
         *         &lt;simpleType>
         *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *             &lt;enumeration value="S_SpecialServiceRequest"/>
         *             &lt;enumeration value="A_AutoUpgrade"/>
         *           &lt;/restriction>
         *         &lt;/simpleType>
         *       &lt;/attribute>
         *       &lt;attribute name="UpgradeDesigCode" type="{http://www.opentravel.org/OTA/2003/05}UpperCaseAlphaLength1to2" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "instruction"
        })
        public static class Upgrade {

            @XmlElement(name = "Instruction")
            protected List<String> instruction;
            @XmlAttribute(name = "UpgradeMethod")
            protected String upgradeMethod;
            @XmlAttribute(name = "UpgradeDesigCode")
            protected String upgradeDesigCode;

            /**
             * Gets the value of the instruction property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the instruction property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getInstruction().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link String }
             * 
             * 
             */
            public List<String> getInstruction() {
                if (instruction == null) {
                    instruction = new ArrayList<String>();
                }
                return this.instruction;
            }

            /**
             * Gets the value of the upgradeMethod property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getUpgradeMethod() {
                return upgradeMethod;
            }

            /**
             * Sets the value of the upgradeMethod property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setUpgradeMethod(String value) {
                this.upgradeMethod = value;
            }

            /**
             * Gets the value of the upgradeDesigCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getUpgradeDesigCode() {
                return upgradeDesigCode;
            }

            /**
             * Sets the value of the upgradeDesigCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setUpgradeDesigCode(String value) {
                this.upgradeDesigCode = value;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}ImageDescriptionType">
     *       &lt;attribute name="Sequence" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *       &lt;attribute name="ContentUsageType" type="{http://www.w3.org/2001/XMLSchema}string" />
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class Multimedia
        extends ImageDescriptionType
    {

        @XmlAttribute(name = "Sequence")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger sequence;
        @XmlAttribute(name = "ContentUsageType")
        protected String contentUsageType;

        /**
         * Gets the value of the sequence property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getSequence() {
            return sequence;
        }

        /**
         * Sets the value of the sequence property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setSequence(BigInteger value) {
            this.sequence = value;
        }

        /**
         * Gets the value of the contentUsageType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getContentUsageType() {
            return contentUsageType;
        }

        /**
         * Sets the value of the contentUsageType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setContentUsageType(String value) {
            this.contentUsageType = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OriginDestinationInformationType">
     *       &lt;sequence>
     *         &lt;element name="AlternateLocationInfo" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;attribute name="OriginLocation" type="{http://www.opentravel.org/OTA/2003/05}ListOfStringLength1to8" />
     *                 &lt;attribute name="DestinationLocation" type="{http://www.opentravel.org/OTA/2003/05}ListOfStringLength1to8" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element ref="{http://www.opentravel.org/OTA/2003/05}TPA_Extensions" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="RPH" type="{http://www.opentravel.org/OTA/2003/05}RPH_Type" />
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "alternateLocationInfo",
        "tpaExtensions"
    })
    public static class OriginDestination
        extends OriginDestinationInformationType
    {

        @XmlElement(name = "AlternateLocationInfo")
        protected AirPricedOfferType.OriginDestination.AlternateLocationInfo alternateLocationInfo;
        @XmlElement(name = "TPA_Extensions")
        protected TPAExtensionsType tpaExtensions;
        @XmlAttribute(name = "RPH")
        protected String rph;

        /**
         * Gets the value of the alternateLocationInfo property.
         * 
         * @return
         *     possible object is
         *     {@link AirPricedOfferType.OriginDestination.AlternateLocationInfo }
         *     
         */
        public AirPricedOfferType.OriginDestination.AlternateLocationInfo getAlternateLocationInfo() {
            return alternateLocationInfo;
        }

        /**
         * Sets the value of the alternateLocationInfo property.
         * 
         * @param value
         *     allowed object is
         *     {@link AirPricedOfferType.OriginDestination.AlternateLocationInfo }
         *     
         */
        public void setAlternateLocationInfo(AirPricedOfferType.OriginDestination.AlternateLocationInfo value) {
            this.alternateLocationInfo = value;
        }

        /**
         * Gets the value of the tpaExtensions property.
         * 
         * @return
         *     possible object is
         *     {@link TPAExtensionsType }
         *     
         */
        public TPAExtensionsType getTPAExtensions() {
            return tpaExtensions;
        }

        /**
         * Sets the value of the tpaExtensions property.
         * 
         * @param value
         *     allowed object is
         *     {@link TPAExtensionsType }
         *     
         */
        public void setTPAExtensions(TPAExtensionsType value) {
            this.tpaExtensions = value;
        }

        /**
         * Gets the value of the rph property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRPH() {
            return rph;
        }

        /**
         * Sets the value of the rph property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRPH(String value) {
            this.rph = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;attribute name="OriginLocation" type="{http://www.opentravel.org/OTA/2003/05}ListOfStringLength1to8" />
         *       &lt;attribute name="DestinationLocation" type="{http://www.opentravel.org/OTA/2003/05}ListOfStringLength1to8" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class AlternateLocationInfo {

            @XmlAttribute(name = "OriginLocation")
            protected List<String> originLocation;
            @XmlAttribute(name = "DestinationLocation")
            protected List<String> destinationLocation;

            /**
             * Gets the value of the originLocation property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the originLocation property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getOriginLocation().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link String }
             * 
             * 
             */
            public List<String> getOriginLocation() {
                if (originLocation == null) {
                    originLocation = new ArrayList<String>();
                }
                return this.originLocation;
            }

            /**
             * Gets the value of the destinationLocation property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the destinationLocation property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getDestinationLocation().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link String }
             * 
             * 
             */
            public List<String> getDestinationLocation() {
                if (destinationLocation == null) {
                    destinationLocation = new ArrayList<String>();
                }
                return this.destinationLocation;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}AirLandProductType">
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class OtherServices
        extends AirLandProductType
    {


    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="PricingDetail" maxOccurs="unbounded" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="TaxInfo" type="{http://www.opentravel.org/OTA/2003/05}TaxType" maxOccurs="99" minOccurs="0"/>
     *                   &lt;element name="RedemptionPoints" type="{http://www.opentravel.org/OTA/2003/05}AirRedemptionMilesType" minOccurs="0"/>
     *                 &lt;/sequence>
     *                 &lt;attribute name="TravelerRPH" type="{http://www.opentravel.org/OTA/2003/05}RPH_Type" />
     *                 &lt;attribute name="OfferPricingRefID" type="{http://www.opentravel.org/OTA/2003/05}RPH_Type" />
     *                 &lt;attribute name="PreTaxAmount" type="{http://www.opentravel.org/OTA/2003/05}Money" />
     *                 &lt;attribute name="TaxAmount" type="{http://www.opentravel.org/OTA/2003/05}Money" />
     *                 &lt;attribute name="Amount" type="{http://www.opentravel.org/OTA/2003/05}Money" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="TaxInfo" type="{http://www.opentravel.org/OTA/2003/05}TaxType" maxOccurs="99" minOccurs="0"/>
     *         &lt;element name="RedemptionPoints" type="{http://www.opentravel.org/OTA/2003/05}AirRedemptionMilesType" minOccurs="0"/>
     *         &lt;element name="AppliedRule" type="{http://www.opentravel.org/OTA/2003/05}AppliedRuleType" maxOccurs="99" minOccurs="0"/>
     *         &lt;element name="PricingQualifier" type="{http://www.opentravel.org/OTA/2003/05}AirPricingQualifierType" maxOccurs="99" minOccurs="0"/>
     *         &lt;element name="ApplyTo" type="{http://www.opentravel.org/OTA/2003/05}ApplyPriceToType" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attGroup ref="{http://www.opentravel.org/OTA/2003/05}ExchangeRateGroup"/>
     *       &lt;attribute name="OfferQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *       &lt;attribute name="PassengerQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *       &lt;attribute name="PreTaxAmount" type="{http://www.opentravel.org/OTA/2003/05}Money" />
     *       &lt;attribute name="TaxAmount" type="{http://www.opentravel.org/OTA/2003/05}Money" />
     *       &lt;attribute name="Amount" type="{http://www.opentravel.org/OTA/2003/05}Money" />
     *       &lt;attribute name="PricingCurrency" type="{http://www.opentravel.org/OTA/2003/05}AlphaLength3" />
     *       &lt;attribute name="DecimalPlaces" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
     *       &lt;attribute name="BaseNUC_Amount" type="{http://www.opentravel.org/OTA/2003/05}Money" />
     *       &lt;attribute name="OfferRPH" type="{http://www.opentravel.org/OTA/2003/05}RPH_Type" />
     *       &lt;attribute name="TravelerRPH" type="{http://www.opentravel.org/OTA/2003/05}ListOfRPH" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "pricingDetail",
        "taxInfo",
        "redemptionPoints",
        "appliedRule",
        "pricingQualifier",
        "applyTo"
    })
    public static class Pricing {

        @XmlElement(name = "PricingDetail")
        protected List<AirPricedOfferType.Pricing.PricingDetail> pricingDetail;
        @XmlElement(name = "TaxInfo")
        protected List<TaxType> taxInfo;
        @XmlElement(name = "RedemptionPoints")
        protected AirRedemptionMilesType redemptionPoints;
        @XmlElement(name = "AppliedRule")
        protected List<AppliedRuleType> appliedRule;
        @XmlElement(name = "PricingQualifier")
        protected List<AirPricingQualifierType> pricingQualifier;
        @XmlElement(name = "ApplyTo")
        protected ApplyPriceToType applyTo;
        @XmlAttribute(name = "OfferQty")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger offerQty;
        @XmlAttribute(name = "PassengerQty")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger passengerQty;
        @XmlAttribute(name = "PreTaxAmount")
        protected BigDecimal preTaxAmount;
        @XmlAttribute(name = "TaxAmount")
        protected BigDecimal taxAmount;
        @XmlAttribute(name = "Amount")
        protected BigDecimal amount;
        @XmlAttribute(name = "PricingCurrency")
        protected String pricingCurrency;
        @XmlAttribute(name = "DecimalPlaces")
        @XmlSchemaType(name = "nonNegativeInteger")
        protected BigInteger decimalPlaces;
        @XmlAttribute(name = "BaseNUC_Amount")
        protected BigDecimal baseNUCAmount;
        @XmlAttribute(name = "OfferRPH")
        protected String offerRPH;
        @XmlAttribute(name = "TravelerRPH")
        protected List<String> travelerRPH;
        @XmlAttribute(name = "FromCurrency")
        protected String fromCurrency;
        @XmlAttribute(name = "ToCurrency")
        protected String toCurrency;
        @XmlAttribute(name = "Rate")
        protected BigDecimal rate;
        @XmlAttribute(name = "Date")
        @XmlSchemaType(name = "date")
        protected XMLGregorianCalendar date;

        /**
         * Gets the value of the pricingDetail property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the pricingDetail property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPricingDetail().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link AirPricedOfferType.Pricing.PricingDetail }
         * 
         * 
         */
        public List<AirPricedOfferType.Pricing.PricingDetail> getPricingDetail() {
            if (pricingDetail == null) {
                pricingDetail = new ArrayList<AirPricedOfferType.Pricing.PricingDetail>();
            }
            return this.pricingDetail;
        }

        /**
         * Gets the value of the taxInfo property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the taxInfo property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTaxInfo().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link TaxType }
         * 
         * 
         */
        public List<TaxType> getTaxInfo() {
            if (taxInfo == null) {
                taxInfo = new ArrayList<TaxType>();
            }
            return this.taxInfo;
        }

        /**
         * Gets the value of the redemptionPoints property.
         * 
         * @return
         *     possible object is
         *     {@link AirRedemptionMilesType }
         *     
         */
        public AirRedemptionMilesType getRedemptionPoints() {
            return redemptionPoints;
        }

        /**
         * Sets the value of the redemptionPoints property.
         * 
         * @param value
         *     allowed object is
         *     {@link AirRedemptionMilesType }
         *     
         */
        public void setRedemptionPoints(AirRedemptionMilesType value) {
            this.redemptionPoints = value;
        }

        /**
         * Gets the value of the appliedRule property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the appliedRule property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getAppliedRule().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link AppliedRuleType }
         * 
         * 
         */
        public List<AppliedRuleType> getAppliedRule() {
            if (appliedRule == null) {
                appliedRule = new ArrayList<AppliedRuleType>();
            }
            return this.appliedRule;
        }

        /**
         * Gets the value of the pricingQualifier property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the pricingQualifier property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPricingQualifier().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link AirPricingQualifierType }
         * 
         * 
         */
        public List<AirPricingQualifierType> getPricingQualifier() {
            if (pricingQualifier == null) {
                pricingQualifier = new ArrayList<AirPricingQualifierType>();
            }
            return this.pricingQualifier;
        }

        /**
         * Gets the value of the applyTo property.
         * 
         * @return
         *     possible object is
         *     {@link ApplyPriceToType }
         *     
         */
        public ApplyPriceToType getApplyTo() {
            return applyTo;
        }

        /**
         * Sets the value of the applyTo property.
         * 
         * @param value
         *     allowed object is
         *     {@link ApplyPriceToType }
         *     
         */
        public void setApplyTo(ApplyPriceToType value) {
            this.applyTo = value;
        }

        /**
         * Gets the value of the offerQty property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getOfferQty() {
            return offerQty;
        }

        /**
         * Sets the value of the offerQty property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setOfferQty(BigInteger value) {
            this.offerQty = value;
        }

        /**
         * Gets the value of the passengerQty property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getPassengerQty() {
            return passengerQty;
        }

        /**
         * Sets the value of the passengerQty property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setPassengerQty(BigInteger value) {
            this.passengerQty = value;
        }

        /**
         * Gets the value of the preTaxAmount property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getPreTaxAmount() {
            return preTaxAmount;
        }

        /**
         * Sets the value of the preTaxAmount property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setPreTaxAmount(BigDecimal value) {
            this.preTaxAmount = value;
        }

        /**
         * Gets the value of the taxAmount property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getTaxAmount() {
            return taxAmount;
        }

        /**
         * Sets the value of the taxAmount property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setTaxAmount(BigDecimal value) {
            this.taxAmount = value;
        }

        /**
         * Gets the value of the amount property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getAmount() {
            return amount;
        }

        /**
         * Sets the value of the amount property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setAmount(BigDecimal value) {
            this.amount = value;
        }

        /**
         * Gets the value of the pricingCurrency property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPricingCurrency() {
            return pricingCurrency;
        }

        /**
         * Sets the value of the pricingCurrency property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPricingCurrency(String value) {
            this.pricingCurrency = value;
        }

        /**
         * Gets the value of the decimalPlaces property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getDecimalPlaces() {
            return decimalPlaces;
        }

        /**
         * Sets the value of the decimalPlaces property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setDecimalPlaces(BigInteger value) {
            this.decimalPlaces = value;
        }

        /**
         * Gets the value of the baseNUCAmount property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getBaseNUCAmount() {
            return baseNUCAmount;
        }

        /**
         * Sets the value of the baseNUCAmount property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setBaseNUCAmount(BigDecimal value) {
            this.baseNUCAmount = value;
        }

        /**
         * Gets the value of the offerRPH property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getOfferRPH() {
            return offerRPH;
        }

        /**
         * Sets the value of the offerRPH property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setOfferRPH(String value) {
            this.offerRPH = value;
        }

        /**
         * Gets the value of the travelerRPH property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the travelerRPH property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTravelerRPH().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getTravelerRPH() {
            if (travelerRPH == null) {
                travelerRPH = new ArrayList<String>();
            }
            return this.travelerRPH;
        }

        /**
         * Gets the value of the fromCurrency property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFromCurrency() {
            return fromCurrency;
        }

        /**
         * Sets the value of the fromCurrency property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFromCurrency(String value) {
            this.fromCurrency = value;
        }

        /**
         * Gets the value of the toCurrency property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getToCurrency() {
            return toCurrency;
        }

        /**
         * Sets the value of the toCurrency property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setToCurrency(String value) {
            this.toCurrency = value;
        }

        /**
         * Gets the value of the rate property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getRate() {
            return rate;
        }

        /**
         * Sets the value of the rate property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setRate(BigDecimal value) {
            this.rate = value;
        }

        /**
         * Gets the value of the date property.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getDate() {
            return date;
        }

        /**
         * Sets the value of the date property.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setDate(XMLGregorianCalendar value) {
            this.date = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="TaxInfo" type="{http://www.opentravel.org/OTA/2003/05}TaxType" maxOccurs="99" minOccurs="0"/>
         *         &lt;element name="RedemptionPoints" type="{http://www.opentravel.org/OTA/2003/05}AirRedemptionMilesType" minOccurs="0"/>
         *       &lt;/sequence>
         *       &lt;attribute name="TravelerRPH" type="{http://www.opentravel.org/OTA/2003/05}RPH_Type" />
         *       &lt;attribute name="OfferPricingRefID" type="{http://www.opentravel.org/OTA/2003/05}RPH_Type" />
         *       &lt;attribute name="PreTaxAmount" type="{http://www.opentravel.org/OTA/2003/05}Money" />
         *       &lt;attribute name="TaxAmount" type="{http://www.opentravel.org/OTA/2003/05}Money" />
         *       &lt;attribute name="Amount" type="{http://www.opentravel.org/OTA/2003/05}Money" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "taxInfo",
            "redemptionPoints"
        })
        public static class PricingDetail {

            @XmlElement(name = "TaxInfo")
            protected List<TaxType> taxInfo;
            @XmlElement(name = "RedemptionPoints")
            protected AirRedemptionMilesType redemptionPoints;
            @XmlAttribute(name = "TravelerRPH")
            protected String travelerRPH;
            @XmlAttribute(name = "OfferPricingRefID")
            protected String offerPricingRefID;
            @XmlAttribute(name = "PreTaxAmount")
            protected BigDecimal preTaxAmount;
            @XmlAttribute(name = "TaxAmount")
            protected BigDecimal taxAmount;
            @XmlAttribute(name = "Amount")
            protected BigDecimal amount;

            /**
             * Gets the value of the taxInfo property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the taxInfo property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getTaxInfo().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link TaxType }
             * 
             * 
             */
            public List<TaxType> getTaxInfo() {
                if (taxInfo == null) {
                    taxInfo = new ArrayList<TaxType>();
                }
                return this.taxInfo;
            }

            /**
             * Gets the value of the redemptionPoints property.
             * 
             * @return
             *     possible object is
             *     {@link AirRedemptionMilesType }
             *     
             */
            public AirRedemptionMilesType getRedemptionPoints() {
                return redemptionPoints;
            }

            /**
             * Sets the value of the redemptionPoints property.
             * 
             * @param value
             *     allowed object is
             *     {@link AirRedemptionMilesType }
             *     
             */
            public void setRedemptionPoints(AirRedemptionMilesType value) {
                this.redemptionPoints = value;
            }

            /**
             * Gets the value of the travelerRPH property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getTravelerRPH() {
                return travelerRPH;
            }

            /**
             * Sets the value of the travelerRPH property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setTravelerRPH(String value) {
                this.travelerRPH = value;
            }

            /**
             * Gets the value of the offerPricingRefID property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getOfferPricingRefID() {
                return offerPricingRefID;
            }

            /**
             * Sets the value of the offerPricingRefID property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setOfferPricingRefID(String value) {
                this.offerPricingRefID = value;
            }

            /**
             * Gets the value of the preTaxAmount property.
             * 
             * @return
             *     possible object is
             *     {@link BigDecimal }
             *     
             */
            public BigDecimal getPreTaxAmount() {
                return preTaxAmount;
            }

            /**
             * Sets the value of the preTaxAmount property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigDecimal }
             *     
             */
            public void setPreTaxAmount(BigDecimal value) {
                this.preTaxAmount = value;
            }

            /**
             * Gets the value of the taxAmount property.
             * 
             * @return
             *     possible object is
             *     {@link BigDecimal }
             *     
             */
            public BigDecimal getTaxAmount() {
                return taxAmount;
            }

            /**
             * Sets the value of the taxAmount property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigDecimal }
             *     
             */
            public void setTaxAmount(BigDecimal value) {
                this.taxAmount = value;
            }

            /**
             * Gets the value of the amount property.
             * 
             * @return
             *     possible object is
             *     {@link BigDecimal }
             *     
             */
            public BigDecimal getAmount() {
                return amount;
            }

            /**
             * Sets the value of the amount property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigDecimal }
             *     
             */
            public void setAmount(BigDecimal value) {
                this.amount = value;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="TripMinOfferQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *       &lt;attribute name="TripMaxOfferQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *       &lt;attribute name="TravelerMinOfferQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *       &lt;attribute name="TravelerMaxOfferQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *       &lt;attribute name="EffectiveDate" type="{http://www.w3.org/2001/XMLSchema}date" />
     *       &lt;attribute name="ExpireDate" type="{http://www.w3.org/2001/XMLSchema}date" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "description"
    })
    public static class Restriction {

        @XmlElement(name = "Description")
        protected String description;
        @XmlAttribute(name = "TripMinOfferQty")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger tripMinOfferQty;
        @XmlAttribute(name = "TripMaxOfferQty")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger tripMaxOfferQty;
        @XmlAttribute(name = "TravelerMinOfferQty")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger travelerMinOfferQty;
        @XmlAttribute(name = "TravelerMaxOfferQty")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger travelerMaxOfferQty;
        @XmlAttribute(name = "EffectiveDate")
        @XmlSchemaType(name = "date")
        protected XMLGregorianCalendar effectiveDate;
        @XmlAttribute(name = "ExpireDate")
        @XmlSchemaType(name = "date")
        protected XMLGregorianCalendar expireDate;

        /**
         * Gets the value of the description property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDescription() {
            return description;
        }

        /**
         * Sets the value of the description property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDescription(String value) {
            this.description = value;
        }

        /**
         * Gets the value of the tripMinOfferQty property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getTripMinOfferQty() {
            return tripMinOfferQty;
        }

        /**
         * Sets the value of the tripMinOfferQty property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setTripMinOfferQty(BigInteger value) {
            this.tripMinOfferQty = value;
        }

        /**
         * Gets the value of the tripMaxOfferQty property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getTripMaxOfferQty() {
            return tripMaxOfferQty;
        }

        /**
         * Sets the value of the tripMaxOfferQty property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setTripMaxOfferQty(BigInteger value) {
            this.tripMaxOfferQty = value;
        }

        /**
         * Gets the value of the travelerMinOfferQty property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getTravelerMinOfferQty() {
            return travelerMinOfferQty;
        }

        /**
         * Sets the value of the travelerMinOfferQty property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setTravelerMinOfferQty(BigInteger value) {
            this.travelerMinOfferQty = value;
        }

        /**
         * Gets the value of the travelerMaxOfferQty property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getTravelerMaxOfferQty() {
            return travelerMaxOfferQty;
        }

        /**
         * Sets the value of the travelerMaxOfferQty property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setTravelerMaxOfferQty(BigInteger value) {
            this.travelerMaxOfferQty = value;
        }

        /**
         * Gets the value of the effectiveDate property.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getEffectiveDate() {
            return effectiveDate;
        }

        /**
         * Sets the value of the effectiveDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setEffectiveDate(XMLGregorianCalendar value) {
            this.effectiveDate = value;
        }

        /**
         * Gets the value of the expireDate property.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getExpireDate() {
            return expireDate;
        }

        /**
         * Sets the value of the expireDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setExpireDate(XMLGregorianCalendar value) {
            this.expireDate = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}AirSeatMarketingClassType">
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class SeatInfo
        extends AirSeatMarketingClassType
    {


    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="VoluntaryChanges" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}VoluntaryChangesType">
     *                 &lt;attribute name="Description" type="{http://www.w3.org/2001/XMLSchema}string" />
     *               &lt;/extension>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="VoluntaryRefunds" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}VoluntaryChangesType">
     *                 &lt;attribute name="Description" type="{http://www.w3.org/2001/XMLSchema}string" />
     *               &lt;/extension>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="Other" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="RefundableInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
     *       &lt;attribute name="ReusableFundsInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "voluntaryChanges",
        "voluntaryRefunds",
        "other"
    })
    public static class TermsAndConditions {

        @XmlElement(name = "VoluntaryChanges")
        protected AirPricedOfferType.TermsAndConditions.VoluntaryChanges voluntaryChanges;
        @XmlElement(name = "VoluntaryRefunds")
        protected AirPricedOfferType.TermsAndConditions.VoluntaryRefunds voluntaryRefunds;
        @XmlElement(name = "Other")
        protected String other;
        @XmlAttribute(name = "RefundableInd")
        protected Boolean refundableInd;
        @XmlAttribute(name = "ReusableFundsInd")
        protected Boolean reusableFundsInd;

        /**
         * Gets the value of the voluntaryChanges property.
         * 
         * @return
         *     possible object is
         *     {@link AirPricedOfferType.TermsAndConditions.VoluntaryChanges }
         *     
         */
        public AirPricedOfferType.TermsAndConditions.VoluntaryChanges getVoluntaryChanges() {
            return voluntaryChanges;
        }

        /**
         * Sets the value of the voluntaryChanges property.
         * 
         * @param value
         *     allowed object is
         *     {@link AirPricedOfferType.TermsAndConditions.VoluntaryChanges }
         *     
         */
        public void setVoluntaryChanges(AirPricedOfferType.TermsAndConditions.VoluntaryChanges value) {
            this.voluntaryChanges = value;
        }

        /**
         * Gets the value of the voluntaryRefunds property.
         * 
         * @return
         *     possible object is
         *     {@link AirPricedOfferType.TermsAndConditions.VoluntaryRefunds }
         *     
         */
        public AirPricedOfferType.TermsAndConditions.VoluntaryRefunds getVoluntaryRefunds() {
            return voluntaryRefunds;
        }

        /**
         * Sets the value of the voluntaryRefunds property.
         * 
         * @param value
         *     allowed object is
         *     {@link AirPricedOfferType.TermsAndConditions.VoluntaryRefunds }
         *     
         */
        public void setVoluntaryRefunds(AirPricedOfferType.TermsAndConditions.VoluntaryRefunds value) {
            this.voluntaryRefunds = value;
        }

        /**
         * Gets the value of the other property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getOther() {
            return other;
        }

        /**
         * Sets the value of the other property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setOther(String value) {
            this.other = value;
        }

        /**
         * Gets the value of the refundableInd property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public Boolean isRefundableInd() {
            return refundableInd;
        }

        /**
         * Sets the value of the refundableInd property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setRefundableInd(Boolean value) {
            this.refundableInd = value;
        }

        /**
         * Gets the value of the reusableFundsInd property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public Boolean isReusableFundsInd() {
            return reusableFundsInd;
        }

        /**
         * Sets the value of the reusableFundsInd property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setReusableFundsInd(Boolean value) {
            this.reusableFundsInd = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}VoluntaryChangesType">
         *       &lt;attribute name="Description" type="{http://www.w3.org/2001/XMLSchema}string" />
         *     &lt;/extension>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class VoluntaryChanges
            extends VoluntaryChangesType
        {

            @XmlAttribute(name = "Description")
            protected String description;

            /**
             * Gets the value of the description property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getDescription() {
                return description;
            }

            /**
             * Sets the value of the description property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setDescription(String value) {
                this.description = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}VoluntaryChangesType">
         *       &lt;attribute name="Description" type="{http://www.w3.org/2001/XMLSchema}string" />
         *     &lt;/extension>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class VoluntaryRefunds
            extends VoluntaryChangesType
        {

            @XmlAttribute(name = "Description")
            protected String description;

            /**
             * Gets the value of the description property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getDescription() {
                return description;
            }

            /**
             * Sets the value of the description property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setDescription(String value) {
                this.description = value;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="CoveredTraveler" maxOccurs="9" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}SearchTravelerType">
     *                 &lt;attribute name="TravelerRPH" type="{http://www.opentravel.org/OTA/2003/05}RPH_Type" />
     *               &lt;/extension>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="CoverageLimit" type="{http://www.opentravel.org/OTA/2003/05}CoverageLimitType" minOccurs="0"/>
     *         &lt;element name="PlanCost" type="{http://www.opentravel.org/OTA/2003/05}PlanCostType" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attGroup ref="{http://www.opentravel.org/OTA/2003/05}DateTimeSpanGroup"/>
     *       &lt;attribute name="Code" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="SellingComponentCode" type="{http://www.w3.org/2001/XMLSchema}string" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "coveredTraveler",
        "coverageLimit",
        "planCost"
    })
    public static class TripInsurance {

        @XmlElement(name = "CoveredTraveler")
        protected List<AirPricedOfferType.TripInsurance.CoveredTraveler> coveredTraveler;
        @XmlElement(name = "CoverageLimit")
        protected CoverageLimitType coverageLimit;
        @XmlElement(name = "PlanCost")
        protected PlanCostType planCost;
        @XmlAttribute(name = "Code")
        protected String code;
        @XmlAttribute(name = "SellingComponentCode")
        protected String sellingComponentCode;
        @XmlAttribute(name = "Start")
        protected String start;
        @XmlAttribute(name = "Duration")
        protected String duration;
        @XmlAttribute(name = "End")
        protected String end;

        /**
         * Gets the value of the coveredTraveler property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the coveredTraveler property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getCoveredTraveler().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link AirPricedOfferType.TripInsurance.CoveredTraveler }
         * 
         * 
         */
        public List<AirPricedOfferType.TripInsurance.CoveredTraveler> getCoveredTraveler() {
            if (coveredTraveler == null) {
                coveredTraveler = new ArrayList<AirPricedOfferType.TripInsurance.CoveredTraveler>();
            }
            return this.coveredTraveler;
        }

        /**
         * Gets the value of the coverageLimit property.
         * 
         * @return
         *     possible object is
         *     {@link CoverageLimitType }
         *     
         */
        public CoverageLimitType getCoverageLimit() {
            return coverageLimit;
        }

        /**
         * Sets the value of the coverageLimit property.
         * 
         * @param value
         *     allowed object is
         *     {@link CoverageLimitType }
         *     
         */
        public void setCoverageLimit(CoverageLimitType value) {
            this.coverageLimit = value;
        }

        /**
         * Gets the value of the planCost property.
         * 
         * @return
         *     possible object is
         *     {@link PlanCostType }
         *     
         */
        public PlanCostType getPlanCost() {
            return planCost;
        }

        /**
         * Sets the value of the planCost property.
         * 
         * @param value
         *     allowed object is
         *     {@link PlanCostType }
         *     
         */
        public void setPlanCost(PlanCostType value) {
            this.planCost = value;
        }

        /**
         * Gets the value of the code property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCode() {
            return code;
        }

        /**
         * Sets the value of the code property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCode(String value) {
            this.code = value;
        }

        /**
         * Gets the value of the sellingComponentCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSellingComponentCode() {
            return sellingComponentCode;
        }

        /**
         * Sets the value of the sellingComponentCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSellingComponentCode(String value) {
            this.sellingComponentCode = value;
        }

        /**
         * Gets the value of the start property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getStart() {
            return start;
        }

        /**
         * Sets the value of the start property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setStart(String value) {
            this.start = value;
        }

        /**
         * Gets the value of the duration property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDuration() {
            return duration;
        }

        /**
         * Sets the value of the duration property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDuration(String value) {
            this.duration = value;
        }

        /**
         * Gets the value of the end property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getEnd() {
            return end;
        }

        /**
         * Sets the value of the end property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setEnd(String value) {
            this.end = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}SearchTravelerType">
         *       &lt;attribute name="TravelerRPH" type="{http://www.opentravel.org/OTA/2003/05}RPH_Type" />
         *     &lt;/extension>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class CoveredTraveler
            extends SearchTravelerType
        {

            @XmlAttribute(name = "TravelerRPH")
            protected String travelerRPH;

            /**
             * Gets the value of the travelerRPH property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getTravelerRPH() {
                return travelerRPH;
            }

            /**
             * Sets the value of the travelerRPH property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setTravelerRPH(String value) {
                this.travelerRPH = value;
            }

        }

    }

}
