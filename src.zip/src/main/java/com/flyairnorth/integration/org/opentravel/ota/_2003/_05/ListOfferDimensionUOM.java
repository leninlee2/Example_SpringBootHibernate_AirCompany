
package com.flyairnorth.integration.org.opentravel.ota._2003._05;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for List_OfferDimensionUOM.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="List_OfferDimensionUOM">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Centimeter"/>
 *     &lt;enumeration value="Foot/Feet"/>
 *     &lt;enumeration value="Inch"/>
 *     &lt;enumeration value="Metre/Meter"/>
 *     &lt;enumeration value="Other_"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "List_OfferDimensionUOM")
@XmlEnum
public enum ListOfferDimensionUOM {

    @XmlEnumValue("Centimeter")
    CENTIMETER("Centimeter"),
    @XmlEnumValue("Foot/Feet")
    FOOT_FEET("Foot/Feet"),
    @XmlEnumValue("Inch")
    INCH("Inch"),
    @XmlEnumValue("Metre/Meter")
    METRE_METER("Metre/Meter"),

    /**
     * This is a string list of enumerations with an "Other_" literal to support an open enumeration list. Use the "Other_" value in combination with the @OtherType attribute to exchange a literal that is not in the list and is known to your trading partners.
     * 
     */
    @XmlEnumValue("Other_")
    OTHER("Other_");
    private final String value;

    ListOfferDimensionUOM(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ListOfferDimensionUOM fromValue(String v) {
        for (ListOfferDimensionUOM c: ListOfferDimensionUOM.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
