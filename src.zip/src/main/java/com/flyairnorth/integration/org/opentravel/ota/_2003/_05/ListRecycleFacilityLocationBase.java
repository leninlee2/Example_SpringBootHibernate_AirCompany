
package com.flyairnorth.integration.org.opentravel.ota._2003._05;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for List_RecycleFacilityLocation_Base.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="List_RecycleFacilityLocation_Base">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="CommonAreas"/>
 *     &lt;enumeration value="Garage"/>
 *     &lt;enumeration value="GuestRoom"/>
 *     &lt;enumeration value="MeetingRoom"/>
 *     &lt;enumeration value="Restaurant"/>
 *     &lt;enumeration value="StaffArea"/>
 *     &lt;enumeration value="Other_"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "List_RecycleFacilityLocation_Base")
@XmlEnum
public enum ListRecycleFacilityLocationBase {

    @XmlEnumValue("CommonAreas")
    COMMON_AREAS("CommonAreas"),
    @XmlEnumValue("Garage")
    GARAGE("Garage"),
    @XmlEnumValue("GuestRoom")
    GUEST_ROOM("GuestRoom"),
    @XmlEnumValue("MeetingRoom")
    MEETING_ROOM("MeetingRoom"),
    @XmlEnumValue("Restaurant")
    RESTAURANT("Restaurant"),
    @XmlEnumValue("StaffArea")
    STAFF_AREA("StaffArea"),

    /**
     * Use: Select this enumeration to exchange a value that is not in the enumerated list by entering the value information in the Code Extension fields.
     * 
     */
    @XmlEnumValue("Other_")
    OTHER("Other_");
    private final String value;

    ListRecycleFacilityLocationBase(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ListRecycleFacilityLocationBase fromValue(String v) {
        for (ListRecycleFacilityLocationBase c: ListRecycleFacilityLocationBase.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
