
package com.flyairnorth.integration.org.opentravel.ota._2003._05;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Fees associated with a code item.
 * 
 * <p>Java class for CodeListFeeType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CodeListFeeType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Amount" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;choice>
 *                   &lt;element name="Currency">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;attribute name="Amount" use="required" type="{http://www.w3.org/2001/XMLSchema}decimal" />
 *                           &lt;attribute name="CurrencyCode">
 *                             &lt;simpleType>
 *                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                 &lt;pattern value="[a-zA-Z]{3}"/>
 *                               &lt;/restriction>
 *                             &lt;/simpleType>
 *                           &lt;/attribute>
 *                           &lt;attribute name="DecimalPlaces" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="AlternateCurrency">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;extension base="{http://www.opentravel.org/OTA/2003/05}List_LoyaltyPrgCurrency">
 *                           &lt;attribute name="Quantity" use="required" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                         &lt;/extension>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="Percent">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal">
 *                         &lt;minInclusive value="0.00"/>
 *                         &lt;maxInclusive value="100.00"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                 &lt;/choice>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Type" type="{http://www.opentravel.org/OTA/2003/05}List_FeeTaxType" minOccurs="0"/>
 *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="5" minOccurs="0"/>
 *         &lt;element name="Qualifiers" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="ChargeUnit" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="Unit" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;simpleContent>
 *                                   &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeUnit">
 *                                     &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                                     &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                                   &lt;/extension>
 *                                 &lt;/simpleContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="Frequency" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;simpleContent>
 *                                   &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeFrequency">
 *                                     &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                                     &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                                   &lt;/extension>
 *                                 &lt;/simpleContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *                 &lt;attribute name="EffectiveDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" />
 *                 &lt;attribute name="ExpireDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" />
 *                 &lt;attribute name="MaxAge" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                 &lt;attribute name="MinAge" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Taxes" maxOccurs="unbounded" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Amount" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;choice>
 *                             &lt;element name="Currency">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;attribute name="Amount" use="required" type="{http://www.w3.org/2001/XMLSchema}decimal" />
 *                                     &lt;attribute name="CurrencyCode">
 *                                       &lt;simpleType>
 *                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                           &lt;pattern value="[a-zA-Z]{3}"/>
 *                                         &lt;/restriction>
 *                                       &lt;/simpleType>
 *                                     &lt;/attribute>
 *                                     &lt;attribute name="DecimalPlaces" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="AlternateCurrency">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;extension base="{http://www.opentravel.org/OTA/2003/05}List_LoyaltyPrgCurrency">
 *                                     &lt;attribute name="Quantity" use="required" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                                   &lt;/extension>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="Percent">
 *                               &lt;simpleType>
 *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal">
 *                                   &lt;minInclusive value="0.00"/>
 *                                   &lt;maxInclusive value="100.00"/>
 *                                 &lt;/restriction>
 *                               &lt;/simpleType>
 *                             &lt;/element>
 *                           &lt;/choice>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="Type" type="{http://www.opentravel.org/OTA/2003/05}List_FeeTaxType" minOccurs="0"/>
 *                   &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="5" minOccurs="0"/>
 *                   &lt;element name="Qualifiers" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="ChargeUnit" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="Unit" minOccurs="0">
 *                                         &lt;complexType>
 *                                           &lt;simpleContent>
 *                                             &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeUnit">
 *                                               &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                                               &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                                             &lt;/extension>
 *                                           &lt;/simpleContent>
 *                                         &lt;/complexType>
 *                                       &lt;/element>
 *                                       &lt;element name="Frequency" minOccurs="0">
 *                                         &lt;complexType>
 *                                           &lt;simpleContent>
 *                                             &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeFrequency">
 *                                               &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                                               &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                                             &lt;/extension>
 *                                           &lt;/simpleContent>
 *                                         &lt;/complexType>
 *                                       &lt;/element>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                           &lt;attribute name="EffectiveDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" />
 *                           &lt;attribute name="ExpireDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" />
 *                           &lt;attribute name="MaxAge" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                           &lt;attribute name="MinAge" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *                 &lt;attribute name="MandatoryInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *                 &lt;attribute name="TaxRPH">
 *                   &lt;simpleType>
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;pattern value="[0-9]{1,8}"/>
 *                     &lt;/restriction>
 *                   &lt;/simpleType>
 *                 &lt;/attribute>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="MandatoryInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="TaxInclusiveInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="TaxableInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="DeterminationMethod">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;enumeration value="Cumulative"/>
 *             &lt;enumeration value="Exclusive"/>
 *             &lt;enumeration value="Inclusive"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *       &lt;attribute name="FeeRPH">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;pattern value="[0-9]{1,8}"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CodeListFeeType", propOrder = {
    "amount",
    "type",
    "description",
    "qualifiers",
    "taxes"
})
public class CodeListFeeType {

    @XmlElement(name = "Amount")
    protected CodeListFeeType.Amount amount;
    @XmlElement(name = "Type")
    protected ListFeeTaxType type;
    @XmlElement(name = "Description")
    protected List<String> description;
    @XmlElement(name = "Qualifiers")
    protected CodeListFeeType.Qualifiers qualifiers;
    @XmlElement(name = "Taxes")
    protected List<CodeListFeeType.Taxes> taxes;
    @XmlAttribute(name = "MandatoryInd")
    protected Boolean mandatoryInd;
    @XmlAttribute(name = "TaxInclusiveInd")
    protected Boolean taxInclusiveInd;
    @XmlAttribute(name = "TaxableInd")
    protected Boolean taxableInd;
    @XmlAttribute(name = "DeterminationMethod")
    protected String determinationMethod;
    @XmlAttribute(name = "FeeRPH")
    protected String feeRPH;

    /**
     * Gets the value of the amount property.
     * 
     * @return
     *     possible object is
     *     {@link CodeListFeeType.Amount }
     *     
     */
    public CodeListFeeType.Amount getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     * @param value
     *     allowed object is
     *     {@link CodeListFeeType.Amount }
     *     
     */
    public void setAmount(CodeListFeeType.Amount value) {
        this.amount = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link ListFeeTaxType }
     *     
     */
    public ListFeeTaxType getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListFeeTaxType }
     *     
     */
    public void setType(ListFeeTaxType value) {
        this.type = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the description property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDescription().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getDescription() {
        if (description == null) {
            description = new ArrayList<String>();
        }
        return this.description;
    }

    /**
     * Gets the value of the qualifiers property.
     * 
     * @return
     *     possible object is
     *     {@link CodeListFeeType.Qualifiers }
     *     
     */
    public CodeListFeeType.Qualifiers getQualifiers() {
        return qualifiers;
    }

    /**
     * Sets the value of the qualifiers property.
     * 
     * @param value
     *     allowed object is
     *     {@link CodeListFeeType.Qualifiers }
     *     
     */
    public void setQualifiers(CodeListFeeType.Qualifiers value) {
        this.qualifiers = value;
    }

    /**
     * Gets the value of the taxes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the taxes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTaxes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CodeListFeeType.Taxes }
     * 
     * 
     */
    public List<CodeListFeeType.Taxes> getTaxes() {
        if (taxes == null) {
            taxes = new ArrayList<CodeListFeeType.Taxes>();
        }
        return this.taxes;
    }

    /**
     * Gets the value of the mandatoryInd property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMandatoryInd() {
        return mandatoryInd;
    }

    /**
     * Sets the value of the mandatoryInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMandatoryInd(Boolean value) {
        this.mandatoryInd = value;
    }

    /**
     * Gets the value of the taxInclusiveInd property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isTaxInclusiveInd() {
        return taxInclusiveInd;
    }

    /**
     * Sets the value of the taxInclusiveInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setTaxInclusiveInd(Boolean value) {
        this.taxInclusiveInd = value;
    }

    /**
     * Gets the value of the taxableInd property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isTaxableInd() {
        return taxableInd;
    }

    /**
     * Sets the value of the taxableInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setTaxableInd(Boolean value) {
        this.taxableInd = value;
    }

    /**
     * Gets the value of the determinationMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeterminationMethod() {
        return determinationMethod;
    }

    /**
     * Sets the value of the determinationMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeterminationMethod(String value) {
        this.determinationMethod = value;
    }

    /**
     * Gets the value of the feeRPH property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFeeRPH() {
        return feeRPH;
    }

    /**
     * Sets the value of the feeRPH property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFeeRPH(String value) {
        this.feeRPH = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;choice>
     *         &lt;element name="Currency">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;attribute name="Amount" use="required" type="{http://www.w3.org/2001/XMLSchema}decimal" />
     *                 &lt;attribute name="CurrencyCode">
     *                   &lt;simpleType>
     *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                       &lt;pattern value="[a-zA-Z]{3}"/>
     *                     &lt;/restriction>
     *                   &lt;/simpleType>
     *                 &lt;/attribute>
     *                 &lt;attribute name="DecimalPlaces" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="AlternateCurrency">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}List_LoyaltyPrgCurrency">
     *                 &lt;attribute name="Quantity" use="required" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *               &lt;/extension>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="Percent">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal">
     *               &lt;minInclusive value="0.00"/>
     *               &lt;maxInclusive value="100.00"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *       &lt;/choice>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "currency",
        "alternateCurrency",
        "percent"
    })
    public static class Amount {

        @XmlElement(name = "Currency")
        protected CodeListFeeType.Amount.Currency currency;
        @XmlElement(name = "AlternateCurrency")
        protected CodeListFeeType.Amount.AlternateCurrency alternateCurrency;
        @XmlElement(name = "Percent")
        protected BigDecimal percent;

        /**
         * Gets the value of the currency property.
         * 
         * @return
         *     possible object is
         *     {@link CodeListFeeType.Amount.Currency }
         *     
         */
        public CodeListFeeType.Amount.Currency getCurrency() {
            return currency;
        }

        /**
         * Sets the value of the currency property.
         * 
         * @param value
         *     allowed object is
         *     {@link CodeListFeeType.Amount.Currency }
         *     
         */
        public void setCurrency(CodeListFeeType.Amount.Currency value) {
            this.currency = value;
        }

        /**
         * Gets the value of the alternateCurrency property.
         * 
         * @return
         *     possible object is
         *     {@link CodeListFeeType.Amount.AlternateCurrency }
         *     
         */
        public CodeListFeeType.Amount.AlternateCurrency getAlternateCurrency() {
            return alternateCurrency;
        }

        /**
         * Sets the value of the alternateCurrency property.
         * 
         * @param value
         *     allowed object is
         *     {@link CodeListFeeType.Amount.AlternateCurrency }
         *     
         */
        public void setAlternateCurrency(CodeListFeeType.Amount.AlternateCurrency value) {
            this.alternateCurrency = value;
        }

        /**
         * Gets the value of the percent property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getPercent() {
            return percent;
        }

        /**
         * Sets the value of the percent property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setPercent(BigDecimal value) {
            this.percent = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}List_LoyaltyPrgCurrency">
         *       &lt;attribute name="Quantity" use="required" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *     &lt;/extension>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class AlternateCurrency
            extends ListLoyaltyPrgCurrency
        {

            @XmlAttribute(name = "Quantity", required = true)
            @XmlSchemaType(name = "positiveInteger")
            protected BigInteger quantity;

            /**
             * Gets the value of the quantity property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getQuantity() {
                return quantity;
            }

            /**
             * Sets the value of the quantity property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setQuantity(BigInteger value) {
                this.quantity = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;attribute name="Amount" use="required" type="{http://www.w3.org/2001/XMLSchema}decimal" />
         *       &lt;attribute name="CurrencyCode">
         *         &lt;simpleType>
         *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *             &lt;pattern value="[a-zA-Z]{3}"/>
         *           &lt;/restriction>
         *         &lt;/simpleType>
         *       &lt;/attribute>
         *       &lt;attribute name="DecimalPlaces" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class Currency {

            @XmlAttribute(name = "Amount", required = true)
            protected BigDecimal amount;
            @XmlAttribute(name = "CurrencyCode")
            protected String currencyCode;
            @XmlAttribute(name = "DecimalPlaces")
            @XmlSchemaType(name = "nonNegativeInteger")
            protected BigInteger decimalPlaces;

            /**
             * Gets the value of the amount property.
             * 
             * @return
             *     possible object is
             *     {@link BigDecimal }
             *     
             */
            public BigDecimal getAmount() {
                return amount;
            }

            /**
             * Sets the value of the amount property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigDecimal }
             *     
             */
            public void setAmount(BigDecimal value) {
                this.amount = value;
            }

            /**
             * Gets the value of the currencyCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCurrencyCode() {
                return currencyCode;
            }

            /**
             * Sets the value of the currencyCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCurrencyCode(String value) {
                this.currencyCode = value;
            }

            /**
             * Gets the value of the decimalPlaces property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getDecimalPlaces() {
                return decimalPlaces;
            }

            /**
             * Sets the value of the decimalPlaces property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setDecimalPlaces(BigInteger value) {
                this.decimalPlaces = value;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="ChargeUnit" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Unit" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;simpleContent>
     *                         &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeUnit">
     *                           &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *                           &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *                         &lt;/extension>
     *                       &lt;/simpleContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="Frequency" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;simpleContent>
     *                         &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeFrequency">
     *                           &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *                           &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *                         &lt;/extension>
     *                       &lt;/simpleContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *       &lt;attribute name="EffectiveDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" />
     *       &lt;attribute name="ExpireDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" />
     *       &lt;attribute name="MaxAge" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *       &lt;attribute name="MinAge" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "chargeUnit"
    })
    public static class Qualifiers {

        @XmlElement(name = "ChargeUnit")
        protected CodeListFeeType.Qualifiers.ChargeUnit chargeUnit;
        @XmlAttribute(name = "EffectiveDateTime")
        @XmlSchemaType(name = "dateTime")
        protected XMLGregorianCalendar effectiveDateTime;
        @XmlAttribute(name = "ExpireDateTime")
        @XmlSchemaType(name = "dateTime")
        protected XMLGregorianCalendar expireDateTime;
        @XmlAttribute(name = "MaxAge")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger maxAge;
        @XmlAttribute(name = "MinAge")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger minAge;

        /**
         * Gets the value of the chargeUnit property.
         * 
         * @return
         *     possible object is
         *     {@link CodeListFeeType.Qualifiers.ChargeUnit }
         *     
         */
        public CodeListFeeType.Qualifiers.ChargeUnit getChargeUnit() {
            return chargeUnit;
        }

        /**
         * Sets the value of the chargeUnit property.
         * 
         * @param value
         *     allowed object is
         *     {@link CodeListFeeType.Qualifiers.ChargeUnit }
         *     
         */
        public void setChargeUnit(CodeListFeeType.Qualifiers.ChargeUnit value) {
            this.chargeUnit = value;
        }

        /**
         * Gets the value of the effectiveDateTime property.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getEffectiveDateTime() {
            return effectiveDateTime;
        }

        /**
         * Sets the value of the effectiveDateTime property.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setEffectiveDateTime(XMLGregorianCalendar value) {
            this.effectiveDateTime = value;
        }

        /**
         * Gets the value of the expireDateTime property.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getExpireDateTime() {
            return expireDateTime;
        }

        /**
         * Sets the value of the expireDateTime property.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setExpireDateTime(XMLGregorianCalendar value) {
            this.expireDateTime = value;
        }

        /**
         * Gets the value of the maxAge property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getMaxAge() {
            return maxAge;
        }

        /**
         * Sets the value of the maxAge property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setMaxAge(BigInteger value) {
            this.maxAge = value;
        }

        /**
         * Gets the value of the minAge property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getMinAge() {
            return minAge;
        }

        /**
         * Sets the value of the minAge property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setMinAge(BigInteger value) {
            this.minAge = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="Unit" minOccurs="0">
         *           &lt;complexType>
         *             &lt;simpleContent>
         *               &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeUnit">
         *                 &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *                 &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *               &lt;/extension>
         *             &lt;/simpleContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="Frequency" minOccurs="0">
         *           &lt;complexType>
         *             &lt;simpleContent>
         *               &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeFrequency">
         *                 &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *                 &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *               &lt;/extension>
         *             &lt;/simpleContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "unit",
            "frequency"
        })
        public static class ChargeUnit {

            @XmlElement(name = "Unit")
            protected CodeListFeeType.Qualifiers.ChargeUnit.Unit unit;
            @XmlElement(name = "Frequency")
            protected CodeListFeeType.Qualifiers.ChargeUnit.Frequency frequency;

            /**
             * Gets the value of the unit property.
             * 
             * @return
             *     possible object is
             *     {@link CodeListFeeType.Qualifiers.ChargeUnit.Unit }
             *     
             */
            public CodeListFeeType.Qualifiers.ChargeUnit.Unit getUnit() {
                return unit;
            }

            /**
             * Sets the value of the unit property.
             * 
             * @param value
             *     allowed object is
             *     {@link CodeListFeeType.Qualifiers.ChargeUnit.Unit }
             *     
             */
            public void setUnit(CodeListFeeType.Qualifiers.ChargeUnit.Unit value) {
                this.unit = value;
            }

            /**
             * Gets the value of the frequency property.
             * 
             * @return
             *     possible object is
             *     {@link CodeListFeeType.Qualifiers.ChargeUnit.Frequency }
             *     
             */
            public CodeListFeeType.Qualifiers.ChargeUnit.Frequency getFrequency() {
                return frequency;
            }

            /**
             * Sets the value of the frequency property.
             * 
             * @param value
             *     allowed object is
             *     {@link CodeListFeeType.Qualifiers.ChargeUnit.Frequency }
             *     
             */
            public void setFrequency(CodeListFeeType.Qualifiers.ChargeUnit.Frequency value) {
                this.frequency = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;simpleContent>
             *     &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeFrequency">
             *       &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
             *       &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
             *     &lt;/extension>
             *   &lt;/simpleContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "")
            public static class Frequency
                extends ListChargeFrequency
            {

                @XmlAttribute(name = "ExemptQty")
                @XmlSchemaType(name = "positiveInteger")
                protected BigInteger exemptQty;
                @XmlAttribute(name = "MaximumQty")
                @XmlSchemaType(name = "positiveInteger")
                protected BigInteger maximumQty;

                /**
                 * Gets the value of the exemptQty property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigInteger }
                 *     
                 */
                public BigInteger getExemptQty() {
                    return exemptQty;
                }

                /**
                 * Sets the value of the exemptQty property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigInteger }
                 *     
                 */
                public void setExemptQty(BigInteger value) {
                    this.exemptQty = value;
                }

                /**
                 * Gets the value of the maximumQty property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigInteger }
                 *     
                 */
                public BigInteger getMaximumQty() {
                    return maximumQty;
                }

                /**
                 * Sets the value of the maximumQty property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigInteger }
                 *     
                 */
                public void setMaximumQty(BigInteger value) {
                    this.maximumQty = value;
                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;simpleContent>
             *     &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeUnit">
             *       &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
             *       &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
             *     &lt;/extension>
             *   &lt;/simpleContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "")
            public static class Unit
                extends ListChargeUnit
            {

                @XmlAttribute(name = "ExemptQty")
                @XmlSchemaType(name = "positiveInteger")
                protected BigInteger exemptQty;
                @XmlAttribute(name = "MaximumQty")
                @XmlSchemaType(name = "positiveInteger")
                protected BigInteger maximumQty;

                /**
                 * Gets the value of the exemptQty property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigInteger }
                 *     
                 */
                public BigInteger getExemptQty() {
                    return exemptQty;
                }

                /**
                 * Sets the value of the exemptQty property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigInteger }
                 *     
                 */
                public void setExemptQty(BigInteger value) {
                    this.exemptQty = value;
                }

                /**
                 * Gets the value of the maximumQty property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigInteger }
                 *     
                 */
                public BigInteger getMaximumQty() {
                    return maximumQty;
                }

                /**
                 * Sets the value of the maximumQty property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigInteger }
                 *     
                 */
                public void setMaximumQty(BigInteger value) {
                    this.maximumQty = value;
                }

            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Amount" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;choice>
     *                   &lt;element name="Currency">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;attribute name="Amount" use="required" type="{http://www.w3.org/2001/XMLSchema}decimal" />
     *                           &lt;attribute name="CurrencyCode">
     *                             &lt;simpleType>
     *                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                                 &lt;pattern value="[a-zA-Z]{3}"/>
     *                               &lt;/restriction>
     *                             &lt;/simpleType>
     *                           &lt;/attribute>
     *                           &lt;attribute name="DecimalPlaces" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="AlternateCurrency">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;extension base="{http://www.opentravel.org/OTA/2003/05}List_LoyaltyPrgCurrency">
     *                           &lt;attribute name="Quantity" use="required" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *                         &lt;/extension>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="Percent">
     *                     &lt;simpleType>
     *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal">
     *                         &lt;minInclusive value="0.00"/>
     *                         &lt;maxInclusive value="100.00"/>
     *                       &lt;/restriction>
     *                     &lt;/simpleType>
     *                   &lt;/element>
     *                 &lt;/choice>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="Type" type="{http://www.opentravel.org/OTA/2003/05}List_FeeTaxType" minOccurs="0"/>
     *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="5" minOccurs="0"/>
     *         &lt;element name="Qualifiers" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="ChargeUnit" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="Unit" minOccurs="0">
     *                               &lt;complexType>
     *                                 &lt;simpleContent>
     *                                   &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeUnit">
     *                                     &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *                                     &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *                                   &lt;/extension>
     *                                 &lt;/simpleContent>
     *                               &lt;/complexType>
     *                             &lt;/element>
     *                             &lt;element name="Frequency" minOccurs="0">
     *                               &lt;complexType>
     *                                 &lt;simpleContent>
     *                                   &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeFrequency">
     *                                     &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *                                     &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *                                   &lt;/extension>
     *                                 &lt;/simpleContent>
     *                               &lt;/complexType>
     *                             &lt;/element>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *                 &lt;attribute name="EffectiveDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" />
     *                 &lt;attribute name="ExpireDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" />
     *                 &lt;attribute name="MaxAge" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *                 &lt;attribute name="MinAge" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *       &lt;attribute name="MandatoryInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
     *       &lt;attribute name="TaxRPH">
     *         &lt;simpleType>
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;pattern value="[0-9]{1,8}"/>
     *           &lt;/restriction>
     *         &lt;/simpleType>
     *       &lt;/attribute>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "amount",
        "type",
        "description",
        "qualifiers"
    })
    public static class Taxes {

        @XmlElement(name = "Amount")
        protected CodeListFeeType.Taxes.Amount amount;
        @XmlElement(name = "Type")
        protected ListFeeTaxType type;
        @XmlElement(name = "Description")
        protected List<String> description;
        @XmlElement(name = "Qualifiers")
        protected CodeListFeeType.Taxes.Qualifiers qualifiers;
        @XmlAttribute(name = "MandatoryInd")
        protected Boolean mandatoryInd;
        @XmlAttribute(name = "TaxRPH")
        protected String taxRPH;

        /**
         * Gets the value of the amount property.
         * 
         * @return
         *     possible object is
         *     {@link CodeListFeeType.Taxes.Amount }
         *     
         */
        public CodeListFeeType.Taxes.Amount getAmount() {
            return amount;
        }

        /**
         * Sets the value of the amount property.
         * 
         * @param value
         *     allowed object is
         *     {@link CodeListFeeType.Taxes.Amount }
         *     
         */
        public void setAmount(CodeListFeeType.Taxes.Amount value) {
            this.amount = value;
        }

        /**
         * Gets the value of the type property.
         * 
         * @return
         *     possible object is
         *     {@link ListFeeTaxType }
         *     
         */
        public ListFeeTaxType getType() {
            return type;
        }

        /**
         * Sets the value of the type property.
         * 
         * @param value
         *     allowed object is
         *     {@link ListFeeTaxType }
         *     
         */
        public void setType(ListFeeTaxType value) {
            this.type = value;
        }

        /**
         * Gets the value of the description property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the description property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDescription().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getDescription() {
            if (description == null) {
                description = new ArrayList<String>();
            }
            return this.description;
        }

        /**
         * Gets the value of the qualifiers property.
         * 
         * @return
         *     possible object is
         *     {@link CodeListFeeType.Taxes.Qualifiers }
         *     
         */
        public CodeListFeeType.Taxes.Qualifiers getQualifiers() {
            return qualifiers;
        }

        /**
         * Sets the value of the qualifiers property.
         * 
         * @param value
         *     allowed object is
         *     {@link CodeListFeeType.Taxes.Qualifiers }
         *     
         */
        public void setQualifiers(CodeListFeeType.Taxes.Qualifiers value) {
            this.qualifiers = value;
        }

        /**
         * Gets the value of the mandatoryInd property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public Boolean isMandatoryInd() {
            return mandatoryInd;
        }

        /**
         * Sets the value of the mandatoryInd property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setMandatoryInd(Boolean value) {
            this.mandatoryInd = value;
        }

        /**
         * Gets the value of the taxRPH property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTaxRPH() {
            return taxRPH;
        }

        /**
         * Sets the value of the taxRPH property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTaxRPH(String value) {
            this.taxRPH = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;choice>
         *         &lt;element name="Currency">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;attribute name="Amount" use="required" type="{http://www.w3.org/2001/XMLSchema}decimal" />
         *                 &lt;attribute name="CurrencyCode">
         *                   &lt;simpleType>
         *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *                       &lt;pattern value="[a-zA-Z]{3}"/>
         *                     &lt;/restriction>
         *                   &lt;/simpleType>
         *                 &lt;/attribute>
         *                 &lt;attribute name="DecimalPlaces" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="AlternateCurrency">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}List_LoyaltyPrgCurrency">
         *                 &lt;attribute name="Quantity" use="required" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *               &lt;/extension>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="Percent">
         *           &lt;simpleType>
         *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal">
         *               &lt;minInclusive value="0.00"/>
         *               &lt;maxInclusive value="100.00"/>
         *             &lt;/restriction>
         *           &lt;/simpleType>
         *         &lt;/element>
         *       &lt;/choice>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "currency",
            "alternateCurrency",
            "percent"
        })
        public static class Amount {

            @XmlElement(name = "Currency")
            protected CodeListFeeType.Taxes.Amount.Currency currency;
            @XmlElement(name = "AlternateCurrency")
            protected CodeListFeeType.Taxes.Amount.AlternateCurrency alternateCurrency;
            @XmlElement(name = "Percent")
            protected BigDecimal percent;

            /**
             * Gets the value of the currency property.
             * 
             * @return
             *     possible object is
             *     {@link CodeListFeeType.Taxes.Amount.Currency }
             *     
             */
            public CodeListFeeType.Taxes.Amount.Currency getCurrency() {
                return currency;
            }

            /**
             * Sets the value of the currency property.
             * 
             * @param value
             *     allowed object is
             *     {@link CodeListFeeType.Taxes.Amount.Currency }
             *     
             */
            public void setCurrency(CodeListFeeType.Taxes.Amount.Currency value) {
                this.currency = value;
            }

            /**
             * Gets the value of the alternateCurrency property.
             * 
             * @return
             *     possible object is
             *     {@link CodeListFeeType.Taxes.Amount.AlternateCurrency }
             *     
             */
            public CodeListFeeType.Taxes.Amount.AlternateCurrency getAlternateCurrency() {
                return alternateCurrency;
            }

            /**
             * Sets the value of the alternateCurrency property.
             * 
             * @param value
             *     allowed object is
             *     {@link CodeListFeeType.Taxes.Amount.AlternateCurrency }
             *     
             */
            public void setAlternateCurrency(CodeListFeeType.Taxes.Amount.AlternateCurrency value) {
                this.alternateCurrency = value;
            }

            /**
             * Gets the value of the percent property.
             * 
             * @return
             *     possible object is
             *     {@link BigDecimal }
             *     
             */
            public BigDecimal getPercent() {
                return percent;
            }

            /**
             * Sets the value of the percent property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigDecimal }
             *     
             */
            public void setPercent(BigDecimal value) {
                this.percent = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}List_LoyaltyPrgCurrency">
             *       &lt;attribute name="Quantity" use="required" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
             *     &lt;/extension>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "")
            public static class AlternateCurrency
                extends ListLoyaltyPrgCurrency
            {

                @XmlAttribute(name = "Quantity", required = true)
                @XmlSchemaType(name = "positiveInteger")
                protected BigInteger quantity;

                /**
                 * Gets the value of the quantity property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigInteger }
                 *     
                 */
                public BigInteger getQuantity() {
                    return quantity;
                }

                /**
                 * Sets the value of the quantity property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigInteger }
                 *     
                 */
                public void setQuantity(BigInteger value) {
                    this.quantity = value;
                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;attribute name="Amount" use="required" type="{http://www.w3.org/2001/XMLSchema}decimal" />
             *       &lt;attribute name="CurrencyCode">
             *         &lt;simpleType>
             *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
             *             &lt;pattern value="[a-zA-Z]{3}"/>
             *           &lt;/restriction>
             *         &lt;/simpleType>
             *       &lt;/attribute>
             *       &lt;attribute name="DecimalPlaces" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "")
            public static class Currency {

                @XmlAttribute(name = "Amount", required = true)
                protected BigDecimal amount;
                @XmlAttribute(name = "CurrencyCode")
                protected String currencyCode;
                @XmlAttribute(name = "DecimalPlaces")
                @XmlSchemaType(name = "nonNegativeInteger")
                protected BigInteger decimalPlaces;

                /**
                 * Gets the value of the amount property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getAmount() {
                    return amount;
                }

                /**
                 * Sets the value of the amount property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setAmount(BigDecimal value) {
                    this.amount = value;
                }

                /**
                 * Gets the value of the currencyCode property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCurrencyCode() {
                    return currencyCode;
                }

                /**
                 * Sets the value of the currencyCode property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCurrencyCode(String value) {
                    this.currencyCode = value;
                }

                /**
                 * Gets the value of the decimalPlaces property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigInteger }
                 *     
                 */
                public BigInteger getDecimalPlaces() {
                    return decimalPlaces;
                }

                /**
                 * Sets the value of the decimalPlaces property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigInteger }
                 *     
                 */
                public void setDecimalPlaces(BigInteger value) {
                    this.decimalPlaces = value;
                }

            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="ChargeUnit" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="Unit" minOccurs="0">
         *                     &lt;complexType>
         *                       &lt;simpleContent>
         *                         &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeUnit">
         *                           &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *                           &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *                         &lt;/extension>
         *                       &lt;/simpleContent>
         *                     &lt;/complexType>
         *                   &lt;/element>
         *                   &lt;element name="Frequency" minOccurs="0">
         *                     &lt;complexType>
         *                       &lt;simpleContent>
         *                         &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeFrequency">
         *                           &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *                           &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *                         &lt;/extension>
         *                       &lt;/simpleContent>
         *                     &lt;/complexType>
         *                   &lt;/element>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *       &lt;attribute name="EffectiveDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" />
         *       &lt;attribute name="ExpireDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" />
         *       &lt;attribute name="MaxAge" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *       &lt;attribute name="MinAge" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "chargeUnit"
        })
        public static class Qualifiers {

            @XmlElement(name = "ChargeUnit")
            protected CodeListFeeType.Taxes.Qualifiers.ChargeUnit chargeUnit;
            @XmlAttribute(name = "EffectiveDateTime")
            @XmlSchemaType(name = "dateTime")
            protected XMLGregorianCalendar effectiveDateTime;
            @XmlAttribute(name = "ExpireDateTime")
            @XmlSchemaType(name = "dateTime")
            protected XMLGregorianCalendar expireDateTime;
            @XmlAttribute(name = "MaxAge")
            @XmlSchemaType(name = "positiveInteger")
            protected BigInteger maxAge;
            @XmlAttribute(name = "MinAge")
            @XmlSchemaType(name = "positiveInteger")
            protected BigInteger minAge;

            /**
             * Gets the value of the chargeUnit property.
             * 
             * @return
             *     possible object is
             *     {@link CodeListFeeType.Taxes.Qualifiers.ChargeUnit }
             *     
             */
            public CodeListFeeType.Taxes.Qualifiers.ChargeUnit getChargeUnit() {
                return chargeUnit;
            }

            /**
             * Sets the value of the chargeUnit property.
             * 
             * @param value
             *     allowed object is
             *     {@link CodeListFeeType.Taxes.Qualifiers.ChargeUnit }
             *     
             */
            public void setChargeUnit(CodeListFeeType.Taxes.Qualifiers.ChargeUnit value) {
                this.chargeUnit = value;
            }

            /**
             * Gets the value of the effectiveDateTime property.
             * 
             * @return
             *     possible object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public XMLGregorianCalendar getEffectiveDateTime() {
                return effectiveDateTime;
            }

            /**
             * Sets the value of the effectiveDateTime property.
             * 
             * @param value
             *     allowed object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public void setEffectiveDateTime(XMLGregorianCalendar value) {
                this.effectiveDateTime = value;
            }

            /**
             * Gets the value of the expireDateTime property.
             * 
             * @return
             *     possible object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public XMLGregorianCalendar getExpireDateTime() {
                return expireDateTime;
            }

            /**
             * Sets the value of the expireDateTime property.
             * 
             * @param value
             *     allowed object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public void setExpireDateTime(XMLGregorianCalendar value) {
                this.expireDateTime = value;
            }

            /**
             * Gets the value of the maxAge property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getMaxAge() {
                return maxAge;
            }

            /**
             * Sets the value of the maxAge property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setMaxAge(BigInteger value) {
                this.maxAge = value;
            }

            /**
             * Gets the value of the minAge property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getMinAge() {
                return minAge;
            }

            /**
             * Sets the value of the minAge property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setMinAge(BigInteger value) {
                this.minAge = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="Unit" minOccurs="0">
             *           &lt;complexType>
             *             &lt;simpleContent>
             *               &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeUnit">
             *                 &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
             *                 &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
             *               &lt;/extension>
             *             &lt;/simpleContent>
             *           &lt;/complexType>
             *         &lt;/element>
             *         &lt;element name="Frequency" minOccurs="0">
             *           &lt;complexType>
             *             &lt;simpleContent>
             *               &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeFrequency">
             *                 &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
             *                 &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
             *               &lt;/extension>
             *             &lt;/simpleContent>
             *           &lt;/complexType>
             *         &lt;/element>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "unit",
                "frequency"
            })
            public static class ChargeUnit {

                @XmlElement(name = "Unit")
                protected CodeListFeeType.Taxes.Qualifiers.ChargeUnit.Unit unit;
                @XmlElement(name = "Frequency")
                protected CodeListFeeType.Taxes.Qualifiers.ChargeUnit.Frequency frequency;

                /**
                 * Gets the value of the unit property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link CodeListFeeType.Taxes.Qualifiers.ChargeUnit.Unit }
                 *     
                 */
                public CodeListFeeType.Taxes.Qualifiers.ChargeUnit.Unit getUnit() {
                    return unit;
                }

                /**
                 * Sets the value of the unit property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link CodeListFeeType.Taxes.Qualifiers.ChargeUnit.Unit }
                 *     
                 */
                public void setUnit(CodeListFeeType.Taxes.Qualifiers.ChargeUnit.Unit value) {
                    this.unit = value;
                }

                /**
                 * Gets the value of the frequency property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link CodeListFeeType.Taxes.Qualifiers.ChargeUnit.Frequency }
                 *     
                 */
                public CodeListFeeType.Taxes.Qualifiers.ChargeUnit.Frequency getFrequency() {
                    return frequency;
                }

                /**
                 * Sets the value of the frequency property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link CodeListFeeType.Taxes.Qualifiers.ChargeUnit.Frequency }
                 *     
                 */
                public void setFrequency(CodeListFeeType.Taxes.Qualifiers.ChargeUnit.Frequency value) {
                    this.frequency = value;
                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType>
                 *   &lt;simpleContent>
                 *     &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeFrequency">
                 *       &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
                 *       &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
                 *     &lt;/extension>
                 *   &lt;/simpleContent>
                 * &lt;/complexType>
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "")
                public static class Frequency
                    extends ListChargeFrequency
                {

                    @XmlAttribute(name = "ExemptQty")
                    @XmlSchemaType(name = "positiveInteger")
                    protected BigInteger exemptQty;
                    @XmlAttribute(name = "MaximumQty")
                    @XmlSchemaType(name = "positiveInteger")
                    protected BigInteger maximumQty;

                    /**
                     * Gets the value of the exemptQty property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link BigInteger }
                     *     
                     */
                    public BigInteger getExemptQty() {
                        return exemptQty;
                    }

                    /**
                     * Sets the value of the exemptQty property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link BigInteger }
                     *     
                     */
                    public void setExemptQty(BigInteger value) {
                        this.exemptQty = value;
                    }

                    /**
                     * Gets the value of the maximumQty property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link BigInteger }
                     *     
                     */
                    public BigInteger getMaximumQty() {
                        return maximumQty;
                    }

                    /**
                     * Sets the value of the maximumQty property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link BigInteger }
                     *     
                     */
                    public void setMaximumQty(BigInteger value) {
                        this.maximumQty = value;
                    }

                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType>
                 *   &lt;simpleContent>
                 *     &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_ChargeUnit">
                 *       &lt;attribute name="ExemptQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
                 *       &lt;attribute name="MaximumQty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
                 *     &lt;/extension>
                 *   &lt;/simpleContent>
                 * &lt;/complexType>
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "")
                public static class Unit
                    extends ListChargeUnit
                {

                    @XmlAttribute(name = "ExemptQty")
                    @XmlSchemaType(name = "positiveInteger")
                    protected BigInteger exemptQty;
                    @XmlAttribute(name = "MaximumQty")
                    @XmlSchemaType(name = "positiveInteger")
                    protected BigInteger maximumQty;

                    /**
                     * Gets the value of the exemptQty property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link BigInteger }
                     *     
                     */
                    public BigInteger getExemptQty() {
                        return exemptQty;
                    }

                    /**
                     * Sets the value of the exemptQty property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link BigInteger }
                     *     
                     */
                    public void setExemptQty(BigInteger value) {
                        this.exemptQty = value;
                    }

                    /**
                     * Gets the value of the maximumQty property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link BigInteger }
                     *     
                     */
                    public BigInteger getMaximumQty() {
                        return maximumQty;
                    }

                    /**
                     * Sets the value of the maximumQty property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link BigInteger }
                     *     
                     */
                    public void setMaximumQty(BigInteger value) {
                        this.maximumQty = value;
                    }

                }

            }

        }

    }

}
