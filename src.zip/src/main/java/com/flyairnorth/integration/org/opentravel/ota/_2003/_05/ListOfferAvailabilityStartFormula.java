
package com.flyairnorth.integration.org.opentravel.ota._2003._05;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for List_OfferAvailabilityStartFormula.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="List_OfferAvailabilityStartFormula">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="CustomerSpecified"/>
 *     &lt;enumeration value="FlightArrival"/>
 *     &lt;enumeration value="RentalCarDropOff"/>
 *     &lt;enumeration value="TravelGracePeriod_Distance"/>
 *     &lt;enumeration value="TravelGracePeriod_PrivateSchedule"/>
 *     &lt;enumeration value="TravelGracePeriod_PublicSchedule"/>
 *     &lt;enumeration value="Other_"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "List_OfferAvailabilityStartFormula")
@XmlEnum
public enum ListOfferAvailabilityStartFormula {


    /**
     * The customer has specified the earliest start date or date and time.
     * 
     */
    @XmlEnumValue("CustomerSpecified")
    CUSTOMER_SPECIFIED("CustomerSpecified"),
    @XmlEnumValue("FlightArrival")
    FLIGHT_ARRIVAL("FlightArrival"),
    @XmlEnumValue("RentalCarDropOff")
    RENTAL_CAR_DROP_OFF("RentalCarDropOff"),

    /**
     * The travel grace period (travel time between two locations) has been estimated based on the calculated distance between the known start and end locations.
     * 
     */
    @XmlEnumValue("TravelGracePeriod_Distance")
    TRAVEL_GRACE_PERIOD_DISTANCE("TravelGracePeriod_Distance"),

    /**
     * The travel grace period (travel time between two locations) has been estimated based on a known operating schedule for a supplier or prearranged mode of transportation between the start and end locations.
     * 
     */
    @XmlEnumValue("TravelGracePeriod_PrivateSchedule")
    TRAVEL_GRACE_PERIOD_PRIVATE_SCHEDULE("TravelGracePeriod_PrivateSchedule"),

    /**
     * The travel grace period (travel time between two locations) has been estimated based on a known operating schedule for a public mode of transportation between the start and end locations.
     * 
     */
    @XmlEnumValue("TravelGracePeriod_PublicSchedule")
    TRAVEL_GRACE_PERIOD_PUBLIC_SCHEDULE("TravelGracePeriod_PublicSchedule"),

    /**
     * This is a string list of enumerations with an "Other_" literal to support an open enumeration list. Use the "Other_" value in combination with the @OtherType attribute to exchange a literal that is not in the list and is known to your trading partners.
     * 
     */
    @XmlEnumValue("Other_")
    OTHER("Other_");
    private final String value;

    ListOfferAvailabilityStartFormula(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ListOfferAvailabilityStartFormula fromValue(String v) {
        for (ListOfferAvailabilityStartFormula c: ListOfferAvailabilityStartFormula.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
