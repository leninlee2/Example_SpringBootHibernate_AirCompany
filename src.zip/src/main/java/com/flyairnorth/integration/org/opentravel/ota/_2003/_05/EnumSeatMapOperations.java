
package com.flyairnorth.integration.org.opentravel.ota._2003._05;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Enum_SeatMapOperations.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="Enum_SeatMapOperations">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="GetSeatAssignment"/>
 *     &lt;enumeration value="GetSeatMap"/>
 *     &lt;enumeration value="GetSeatMapForPNR"/>
 *     &lt;enumeration value="GetSeatMapWithRules"/>
 *     &lt;enumeration value="GetSeatPurchases"/>
 *     &lt;enumeration value="GetSeatMapForSeatType"/>
 *     &lt;enumeration value="GetSeatZones"/>
 *     &lt;enumeration value="GetSeatMapForUpgrade"/>
 *     &lt;enumeration value="Other_"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "Enum_SeatMapOperations")
@XmlEnum
public enum EnumSeatMapOperations {


    /**
     * Get a seat map for one or more already assigned seats. [Flight, PNR, Traveler]
     * 
     */
    @XmlEnumValue("GetSeatAssignment")
    GET_SEAT_ASSIGNMENT("GetSeatAssignment"),

    /**
     * Get a seat map for the specified criteria [Flight, PNR, Traveler].
     * 
     */
    @XmlEnumValue("GetSeatMap")
    GET_SEAT_MAP("GetSeatMap"),

    /**
     * Get a seat map fpr a specified passenger name record. [Multiple crafts, multi flight segments]
     * 
     */
    @XmlEnumValue("GetSeatMapForPNR")
    GET_SEAT_MAP_FOR_PNR("GetSeatMapForPNR"),

    /**
     * Get a seat map that includes fare, upgrade and other associated rules for each seat.
     * 
     */
    @XmlEnumValue("GetSeatMapWithRules")
    GET_SEAT_MAP_WITH_RULES("GetSeatMapWithRules"),

    /**
     * Get a list of purchased seats for travelers and/or by aircraft.
     * 
     */
    @XmlEnumValue("GetSeatPurchases")
    GET_SEAT_PURCHASES("GetSeatPurchases"),

    /**
     * Get a seat map for a specified seat type and/or traveler special requirements.
     * 
     */
    @XmlEnumValue("GetSeatMapForSeatType")
    GET_SEAT_MAP_FOR_SEAT_TYPE("GetSeatMapForSeatType"),

    /**
     * Get a seat map organized by one or more seating zones.
     * 
     */
    @XmlEnumValue("GetSeatZones")
    GET_SEAT_ZONES("GetSeatZones"),

    /**
     * Get a seat map for an upgrade (which may be voluntary or in-voluntary.
     * 
     */
    @XmlEnumValue("GetSeatMapForUpgrade")
    GET_SEAT_MAP_FOR_UPGRADE("GetSeatMapForUpgrade"),

    /**
     * It is strongly recommended that you submit a comment to have any of your extended list values permanently added to the OpenTravel specification to support maximum trading partner interoperability. http://www.opentraveldevelopersnetwork.com/specificationcomments/2/entercomment.html
     * 
     */
    @XmlEnumValue("Other_")
    OTHER("Other_");
    private final String value;

    EnumSeatMapOperations(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static EnumSeatMapOperations fromValue(String v) {
        for (EnumSeatMapOperations c: EnumSeatMapOperations.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
