
package com.flyairnorth.integration.org.opentravel.ota._2003._05;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Traveler and trip information used for targeted multi-modal offers.
 * 
 * <p>Java class for MultiModalOfferType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MultiModalOfferType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RequestingParty">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyCompanyType">
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Ontology" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyDefinitionType">
 *                 &lt;sequence>
 *                   &lt;element name="CompatibleWith" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyDefinitionType">
 *                         &lt;/extension>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="RequestedOffer">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="OfferTypes" type="{http://www.opentravel.org/OTA/2003/05}OntologyOfferType"/>
 *                   &lt;element name="TimePeriod">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="EarliestStart">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="CalculationMethod" minOccurs="0">
 *                                         &lt;complexType>
 *                                           &lt;complexContent>
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                               &lt;sequence>
 *                                                 &lt;element name="Formula" minOccurs="0">
 *                                                   &lt;complexType>
 *                                                     &lt;simpleContent>
 *                                                       &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_OfferAvailabilityStartFormula">
 *                                                         &lt;attribute name="OtherType">
 *                                                           &lt;simpleType>
 *                                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                                               &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
 *                                                             &lt;/restriction>
 *                                                           &lt;/simpleType>
 *                                                         &lt;/attribute>
 *                                                         &lt;attribute name="OntologyRefID">
 *                                                           &lt;simpleType>
 *                                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                                               &lt;pattern value="[0-9]{1,8}"/>
 *                                                             &lt;/restriction>
 *                                                           &lt;/simpleType>
 *                                                         &lt;/attribute>
 *                                                       &lt;/extension>
 *                                                     &lt;/simpleContent>
 *                                                   &lt;/complexType>
 *                                                 &lt;/element>
 *                                                 &lt;element name="Distance" minOccurs="0">
 *                                                   &lt;complexType>
 *                                                     &lt;complexContent>
 *                                                       &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyDistanceType">
 *                                                       &lt;/extension>
 *                                                     &lt;/complexContent>
 *                                                   &lt;/complexType>
 *                                                 &lt;/element>
 *                                                 &lt;element name="Duration" minOccurs="0">
 *                                                   &lt;complexType>
 *                                                     &lt;simpleContent>
 *                                                       &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_OfferDurationUOM">
 *                                                         &lt;attribute name="DecimalValue" use="required" type="{http://www.w3.org/2001/XMLSchema}decimal" />
 *                                                         &lt;attribute name="OtherType">
 *                                                           &lt;simpleType>
 *                                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                                               &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
 *                                                             &lt;/restriction>
 *                                                           &lt;/simpleType>
 *                                                         &lt;/attribute>
 *                                                         &lt;attribute name="OntologyRefID">
 *                                                           &lt;simpleType>
 *                                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                                               &lt;pattern value="[0-9]{1,8}"/>
 *                                                             &lt;/restriction>
 *                                                           &lt;/simpleType>
 *                                                         &lt;/attribute>
 *                                                       &lt;/extension>
 *                                                     &lt;/simpleContent>
 *                                                   &lt;/complexType>
 *                                                 &lt;/element>
 *                                                 &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
 *                                               &lt;/sequence>
 *                                               &lt;attribute name="OtherType">
 *                                                 &lt;simpleType>
 *                                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                                     &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
 *                                                   &lt;/restriction>
 *                                                 &lt;/simpleType>
 *                                               &lt;/attribute>
 *                                               &lt;attribute name="OntologyRefID">
 *                                                 &lt;simpleType>
 *                                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                                     &lt;pattern value="[0-9]{1,8}"/>
 *                                                   &lt;/restriction>
 *                                                 &lt;/simpleType>
 *                                               &lt;/attribute>
 *                                             &lt;/restriction>
 *                                           &lt;/complexContent>
 *                                         &lt;/complexType>
 *                                       &lt;/element>
 *                                       &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                     &lt;attribute name="DateTime" use="required" type="{http://www.w3.org/2001/XMLSchema}dateTime" />
 *                                     &lt;attribute name="OntologyRefID">
 *                                       &lt;simpleType>
 *                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                           &lt;pattern value="[0-9]{1,8}"/>
 *                                         &lt;/restriction>
 *                                       &lt;/simpleType>
 *                                     &lt;/attribute>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="MaximumDuration" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;simpleContent>
 *                                   &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_OfferDurationUOM">
 *                                     &lt;attribute name="DecimalValue" use="required" type="{http://www.w3.org/2001/XMLSchema}decimal" />
 *                                     &lt;attribute name="OtherType">
 *                                       &lt;simpleType>
 *                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                           &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
 *                                         &lt;/restriction>
 *                                       &lt;/simpleType>
 *                                     &lt;/attribute>
 *                                     &lt;attribute name="OntologyRefID">
 *                                       &lt;simpleType>
 *                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                           &lt;pattern value="[0-9]{1,8}"/>
 *                                         &lt;/restriction>
 *                                       &lt;/simpleType>
 *                                     &lt;/attribute>
 *                                   &lt;/extension>
 *                                 &lt;/simpleContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
 *                           &lt;/sequence>
 *                           &lt;attribute name="OntologyRefID">
 *                             &lt;simpleType>
 *                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                 &lt;pattern value="[0-9]{1,8}"/>
 *                               &lt;/restriction>
 *                             &lt;/simpleType>
 *                           &lt;/attribute>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="GuidelinePricing" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="MaximumPrice" type="{http://www.opentravel.org/OTA/2003/05}OntologyCurrencyType"/>
 *                             &lt;element name="Method" type="{http://www.opentravel.org/OTA/2003/05}OntologyPricingMethodType" minOccurs="0"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="TripPurpose" type="{http://www.opentravel.org/OTA/2003/05}OntologyTripPurposeType" minOccurs="0"/>
 *                   &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="NumberInParty" use="required" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="TripCharacteristics" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Mode" type="{http://www.opentravel.org/OTA/2003/05}OntologyTripModeType"/>
 *                   &lt;element name="BookingMethod" type="{http://www.opentravel.org/OTA/2003/05}OntologyBookingMethodType" minOccurs="0"/>
 *                   &lt;element name="DateTimeDuration" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyTimeDurationType">
 *                         &lt;/extension>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="Location" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyLocationType">
 *                         &lt;/extension>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="PriceAndPayment" type="{http://www.opentravel.org/OTA/2003/05}OntologyPaymentType" minOccurs="0"/>
 *                   &lt;element name="ReservationStatus" type="{http://www.opentravel.org/OTA/2003/05}OntologyReservationStatusType" minOccurs="0"/>
 *                   &lt;element name="Baggage" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyBaggageType">
 *                         &lt;/extension>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="Animals" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyAnimalType">
 *                         &lt;/extension>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="Activity" type="{http://www.opentravel.org/OTA/2003/05}OntologyActivityType" minOccurs="0"/>
 *                   &lt;element name="Lodging" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyLodgingType">
 *                         &lt;/extension>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="Transportation" type="{http://www.opentravel.org/OTA/2003/05}OntologyTransportationType" minOccurs="0"/>
 *                   &lt;element name="TripValue" type="{http://www.opentravel.org/OTA/2003/05}OntologyValueType" minOccurs="0"/>
 *                   &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="TravelerCharacteristics" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="TripPurpose" type="{http://www.opentravel.org/OTA/2003/05}OntologyTripPurposeType" minOccurs="0"/>
 *                   &lt;element name="Classification" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyTravelerClassType">
 *                         &lt;/extension>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="DetailInfo" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="Identification" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="Name" type="{http://www.opentravel.org/OTA/2003/05}OntologyNameType" minOccurs="0"/>
 *                                       &lt;element name="Age" type="{http://www.opentravel.org/OTA/2003/05}OntologyAgeBirthDateType" minOccurs="0"/>
 *                                       &lt;element name="Address" type="{http://www.opentravel.org/OTA/2003/05}OntologyAddressType" minOccurs="0"/>
 *                                       &lt;element name="Contact" type="{http://www.opentravel.org/OTA/2003/05}OntologyContactType" minOccurs="0"/>
 *                                       &lt;element name="LoyaltyProgram" type="{http://www.opentravel.org/OTA/2003/05}OntologyLoyaltyType" maxOccurs="unbounded" minOccurs="0"/>
 *                                       &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="CustomerValue" type="{http://www.opentravel.org/OTA/2003/05}OntologyValueType" minOccurs="0"/>
 *                           &lt;/sequence>
 *                           &lt;attribute name="ServiceAnimalInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *                           &lt;attribute name="DisabledInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *                           &lt;attribute name="FemaleInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *                           &lt;attribute name="MaleInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MultiModalOfferType", propOrder = {
    "requestingParty",
    "ontology",
    "requestedOffer",
    "tripCharacteristics",
    "travelerCharacteristics",
    "ontologyExtension"
})
public class MultiModalOfferType {

    @XmlElement(name = "RequestingParty", required = true)
    protected MultiModalOfferType.RequestingParty requestingParty;
    @XmlElement(name = "Ontology")
    protected MultiModalOfferType.Ontology ontology;
    @XmlElement(name = "RequestedOffer", required = true)
    protected MultiModalOfferType.RequestedOffer requestedOffer;
    @XmlElement(name = "TripCharacteristics")
    protected MultiModalOfferType.TripCharacteristics tripCharacteristics;
    @XmlElement(name = "TravelerCharacteristics")
    protected MultiModalOfferType.TravelerCharacteristics travelerCharacteristics;
    @XmlElement(name = "OntologyExtension")
    protected OntologyExtensionType ontologyExtension;

    /**
     * Gets the value of the requestingParty property.
     * 
     * @return
     *     possible object is
     *     {@link MultiModalOfferType.RequestingParty }
     *     
     */
    public MultiModalOfferType.RequestingParty getRequestingParty() {
        return requestingParty;
    }

    /**
     * Sets the value of the requestingParty property.
     * 
     * @param value
     *     allowed object is
     *     {@link MultiModalOfferType.RequestingParty }
     *     
     */
    public void setRequestingParty(MultiModalOfferType.RequestingParty value) {
        this.requestingParty = value;
    }

    /**
     * Gets the value of the ontology property.
     * 
     * @return
     *     possible object is
     *     {@link MultiModalOfferType.Ontology }
     *     
     */
    public MultiModalOfferType.Ontology getOntology() {
        return ontology;
    }

    /**
     * Sets the value of the ontology property.
     * 
     * @param value
     *     allowed object is
     *     {@link MultiModalOfferType.Ontology }
     *     
     */
    public void setOntology(MultiModalOfferType.Ontology value) {
        this.ontology = value;
    }

    /**
     * Gets the value of the requestedOffer property.
     * 
     * @return
     *     possible object is
     *     {@link MultiModalOfferType.RequestedOffer }
     *     
     */
    public MultiModalOfferType.RequestedOffer getRequestedOffer() {
        return requestedOffer;
    }

    /**
     * Sets the value of the requestedOffer property.
     * 
     * @param value
     *     allowed object is
     *     {@link MultiModalOfferType.RequestedOffer }
     *     
     */
    public void setRequestedOffer(MultiModalOfferType.RequestedOffer value) {
        this.requestedOffer = value;
    }

    /**
     * Gets the value of the tripCharacteristics property.
     * 
     * @return
     *     possible object is
     *     {@link MultiModalOfferType.TripCharacteristics }
     *     
     */
    public MultiModalOfferType.TripCharacteristics getTripCharacteristics() {
        return tripCharacteristics;
    }

    /**
     * Sets the value of the tripCharacteristics property.
     * 
     * @param value
     *     allowed object is
     *     {@link MultiModalOfferType.TripCharacteristics }
     *     
     */
    public void setTripCharacteristics(MultiModalOfferType.TripCharacteristics value) {
        this.tripCharacteristics = value;
    }

    /**
     * Gets the value of the travelerCharacteristics property.
     * 
     * @return
     *     possible object is
     *     {@link MultiModalOfferType.TravelerCharacteristics }
     *     
     */
    public MultiModalOfferType.TravelerCharacteristics getTravelerCharacteristics() {
        return travelerCharacteristics;
    }

    /**
     * Sets the value of the travelerCharacteristics property.
     * 
     * @param value
     *     allowed object is
     *     {@link MultiModalOfferType.TravelerCharacteristics }
     *     
     */
    public void setTravelerCharacteristics(MultiModalOfferType.TravelerCharacteristics value) {
        this.travelerCharacteristics = value;
    }

    /**
     * Gets the value of the ontologyExtension property.
     * 
     * @return
     *     possible object is
     *     {@link OntologyExtensionType }
     *     
     */
    public OntologyExtensionType getOntologyExtension() {
        return ontologyExtension;
    }

    /**
     * Sets the value of the ontologyExtension property.
     * 
     * @param value
     *     allowed object is
     *     {@link OntologyExtensionType }
     *     
     */
    public void setOntologyExtension(OntologyExtensionType value) {
        this.ontologyExtension = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyDefinitionType">
     *       &lt;sequence>
     *         &lt;element name="CompatibleWith" maxOccurs="unbounded" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyDefinitionType">
     *               &lt;/extension>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "compatibleWith",
        "ontologyExtension"
    })
    public static class Ontology
        extends OntologyDefinitionType
    {

        @XmlElement(name = "CompatibleWith")
        protected List<MultiModalOfferType.Ontology.CompatibleWith> compatibleWith;
        @XmlElement(name = "OntologyExtension")
        protected OntologyExtensionType ontologyExtension;

        /**
         * Gets the value of the compatibleWith property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the compatibleWith property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getCompatibleWith().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link MultiModalOfferType.Ontology.CompatibleWith }
         * 
         * 
         */
        public List<MultiModalOfferType.Ontology.CompatibleWith> getCompatibleWith() {
            if (compatibleWith == null) {
                compatibleWith = new ArrayList<MultiModalOfferType.Ontology.CompatibleWith>();
            }
            return this.compatibleWith;
        }

        /**
         * Gets the value of the ontologyExtension property.
         * 
         * @return
         *     possible object is
         *     {@link OntologyExtensionType }
         *     
         */
        public OntologyExtensionType getOntologyExtension() {
            return ontologyExtension;
        }

        /**
         * Sets the value of the ontologyExtension property.
         * 
         * @param value
         *     allowed object is
         *     {@link OntologyExtensionType }
         *     
         */
        public void setOntologyExtension(OntologyExtensionType value) {
            this.ontologyExtension = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyDefinitionType">
         *     &lt;/extension>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class CompatibleWith
            extends OntologyDefinitionType
        {


        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="OfferTypes" type="{http://www.opentravel.org/OTA/2003/05}OntologyOfferType"/>
     *         &lt;element name="TimePeriod">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="EarliestStart">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="CalculationMethod" minOccurs="0">
     *                               &lt;complexType>
     *                                 &lt;complexContent>
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                     &lt;sequence>
     *                                       &lt;element name="Formula" minOccurs="0">
     *                                         &lt;complexType>
     *                                           &lt;simpleContent>
     *                                             &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_OfferAvailabilityStartFormula">
     *                                               &lt;attribute name="OtherType">
     *                                                 &lt;simpleType>
     *                                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                                                     &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
     *                                                   &lt;/restriction>
     *                                                 &lt;/simpleType>
     *                                               &lt;/attribute>
     *                                               &lt;attribute name="OntologyRefID">
     *                                                 &lt;simpleType>
     *                                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                                                     &lt;pattern value="[0-9]{1,8}"/>
     *                                                   &lt;/restriction>
     *                                                 &lt;/simpleType>
     *                                               &lt;/attribute>
     *                                             &lt;/extension>
     *                                           &lt;/simpleContent>
     *                                         &lt;/complexType>
     *                                       &lt;/element>
     *                                       &lt;element name="Distance" minOccurs="0">
     *                                         &lt;complexType>
     *                                           &lt;complexContent>
     *                                             &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyDistanceType">
     *                                             &lt;/extension>
     *                                           &lt;/complexContent>
     *                                         &lt;/complexType>
     *                                       &lt;/element>
     *                                       &lt;element name="Duration" minOccurs="0">
     *                                         &lt;complexType>
     *                                           &lt;simpleContent>
     *                                             &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_OfferDurationUOM">
     *                                               &lt;attribute name="DecimalValue" use="required" type="{http://www.w3.org/2001/XMLSchema}decimal" />
     *                                               &lt;attribute name="OtherType">
     *                                                 &lt;simpleType>
     *                                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                                                     &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
     *                                                   &lt;/restriction>
     *                                                 &lt;/simpleType>
     *                                               &lt;/attribute>
     *                                               &lt;attribute name="OntologyRefID">
     *                                                 &lt;simpleType>
     *                                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                                                     &lt;pattern value="[0-9]{1,8}"/>
     *                                                   &lt;/restriction>
     *                                                 &lt;/simpleType>
     *                                               &lt;/attribute>
     *                                             &lt;/extension>
     *                                           &lt;/simpleContent>
     *                                         &lt;/complexType>
     *                                       &lt;/element>
     *                                       &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
     *                                     &lt;/sequence>
     *                                     &lt;attribute name="OtherType">
     *                                       &lt;simpleType>
     *                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                                           &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
     *                                         &lt;/restriction>
     *                                       &lt;/simpleType>
     *                                     &lt;/attribute>
     *                                     &lt;attribute name="OntologyRefID">
     *                                       &lt;simpleType>
     *                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                                           &lt;pattern value="[0-9]{1,8}"/>
     *                                         &lt;/restriction>
     *                                       &lt;/simpleType>
     *                                     &lt;/attribute>
     *                                   &lt;/restriction>
     *                                 &lt;/complexContent>
     *                               &lt;/complexType>
     *                             &lt;/element>
     *                             &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
     *                           &lt;/sequence>
     *                           &lt;attribute name="DateTime" use="required" type="{http://www.w3.org/2001/XMLSchema}dateTime" />
     *                           &lt;attribute name="OntologyRefID">
     *                             &lt;simpleType>
     *                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                                 &lt;pattern value="[0-9]{1,8}"/>
     *                               &lt;/restriction>
     *                             &lt;/simpleType>
     *                           &lt;/attribute>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="MaximumDuration" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;simpleContent>
     *                         &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_OfferDurationUOM">
     *                           &lt;attribute name="DecimalValue" use="required" type="{http://www.w3.org/2001/XMLSchema}decimal" />
     *                           &lt;attribute name="OtherType">
     *                             &lt;simpleType>
     *                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                                 &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
     *                               &lt;/restriction>
     *                             &lt;/simpleType>
     *                           &lt;/attribute>
     *                           &lt;attribute name="OntologyRefID">
     *                             &lt;simpleType>
     *                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                                 &lt;pattern value="[0-9]{1,8}"/>
     *                               &lt;/restriction>
     *                             &lt;/simpleType>
     *                           &lt;/attribute>
     *                         &lt;/extension>
     *                       &lt;/simpleContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
     *                 &lt;/sequence>
     *                 &lt;attribute name="OntologyRefID">
     *                   &lt;simpleType>
     *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                       &lt;pattern value="[0-9]{1,8}"/>
     *                     &lt;/restriction>
     *                   &lt;/simpleType>
     *                 &lt;/attribute>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="GuidelinePricing" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="MaximumPrice" type="{http://www.opentravel.org/OTA/2003/05}OntologyCurrencyType"/>
     *                   &lt;element name="Method" type="{http://www.opentravel.org/OTA/2003/05}OntologyPricingMethodType" minOccurs="0"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="TripPurpose" type="{http://www.opentravel.org/OTA/2003/05}OntologyTripPurposeType" minOccurs="0"/>
     *         &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="NumberInParty" use="required" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "offerTypes",
        "timePeriod",
        "guidelinePricing",
        "tripPurpose",
        "ontologyExtension"
    })
    public static class RequestedOffer {

        @XmlElement(name = "OfferTypes", required = true)
        protected OntologyOfferType offerTypes;
        @XmlElement(name = "TimePeriod", required = true)
        protected MultiModalOfferType.RequestedOffer.TimePeriod timePeriod;
        @XmlElement(name = "GuidelinePricing")
        protected MultiModalOfferType.RequestedOffer.GuidelinePricing guidelinePricing;
        @XmlElement(name = "TripPurpose")
        protected OntologyTripPurposeType tripPurpose;
        @XmlElement(name = "OntologyExtension")
        protected OntologyExtensionType ontologyExtension;
        @XmlAttribute(name = "NumberInParty", required = true)
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger numberInParty;

        /**
         * Gets the value of the offerTypes property.
         * 
         * @return
         *     possible object is
         *     {@link OntologyOfferType }
         *     
         */
        public OntologyOfferType getOfferTypes() {
            return offerTypes;
        }

        /**
         * Sets the value of the offerTypes property.
         * 
         * @param value
         *     allowed object is
         *     {@link OntologyOfferType }
         *     
         */
        public void setOfferTypes(OntologyOfferType value) {
            this.offerTypes = value;
        }

        /**
         * Gets the value of the timePeriod property.
         * 
         * @return
         *     possible object is
         *     {@link MultiModalOfferType.RequestedOffer.TimePeriod }
         *     
         */
        public MultiModalOfferType.RequestedOffer.TimePeriod getTimePeriod() {
            return timePeriod;
        }

        /**
         * Sets the value of the timePeriod property.
         * 
         * @param value
         *     allowed object is
         *     {@link MultiModalOfferType.RequestedOffer.TimePeriod }
         *     
         */
        public void setTimePeriod(MultiModalOfferType.RequestedOffer.TimePeriod value) {
            this.timePeriod = value;
        }

        /**
         * Gets the value of the guidelinePricing property.
         * 
         * @return
         *     possible object is
         *     {@link MultiModalOfferType.RequestedOffer.GuidelinePricing }
         *     
         */
        public MultiModalOfferType.RequestedOffer.GuidelinePricing getGuidelinePricing() {
            return guidelinePricing;
        }

        /**
         * Sets the value of the guidelinePricing property.
         * 
         * @param value
         *     allowed object is
         *     {@link MultiModalOfferType.RequestedOffer.GuidelinePricing }
         *     
         */
        public void setGuidelinePricing(MultiModalOfferType.RequestedOffer.GuidelinePricing value) {
            this.guidelinePricing = value;
        }

        /**
         * Gets the value of the tripPurpose property.
         * 
         * @return
         *     possible object is
         *     {@link OntologyTripPurposeType }
         *     
         */
        public OntologyTripPurposeType getTripPurpose() {
            return tripPurpose;
        }

        /**
         * Sets the value of the tripPurpose property.
         * 
         * @param value
         *     allowed object is
         *     {@link OntologyTripPurposeType }
         *     
         */
        public void setTripPurpose(OntologyTripPurposeType value) {
            this.tripPurpose = value;
        }

        /**
         * Gets the value of the ontologyExtension property.
         * 
         * @return
         *     possible object is
         *     {@link OntologyExtensionType }
         *     
         */
        public OntologyExtensionType getOntologyExtension() {
            return ontologyExtension;
        }

        /**
         * Sets the value of the ontologyExtension property.
         * 
         * @param value
         *     allowed object is
         *     {@link OntologyExtensionType }
         *     
         */
        public void setOntologyExtension(OntologyExtensionType value) {
            this.ontologyExtension = value;
        }

        /**
         * Gets the value of the numberInParty property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getNumberInParty() {
            return numberInParty;
        }

        /**
         * Sets the value of the numberInParty property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setNumberInParty(BigInteger value) {
            this.numberInParty = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="MaximumPrice" type="{http://www.opentravel.org/OTA/2003/05}OntologyCurrencyType"/>
         *         &lt;element name="Method" type="{http://www.opentravel.org/OTA/2003/05}OntologyPricingMethodType" minOccurs="0"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "maximumPrice",
            "method"
        })
        public static class GuidelinePricing {

            @XmlElement(name = "MaximumPrice", required = true)
            protected OntologyCurrencyType maximumPrice;
            @XmlElement(name = "Method")
            protected OntologyPricingMethodType method;

            /**
             * Gets the value of the maximumPrice property.
             * 
             * @return
             *     possible object is
             *     {@link OntologyCurrencyType }
             *     
             */
            public OntologyCurrencyType getMaximumPrice() {
                return maximumPrice;
            }

            /**
             * Sets the value of the maximumPrice property.
             * 
             * @param value
             *     allowed object is
             *     {@link OntologyCurrencyType }
             *     
             */
            public void setMaximumPrice(OntologyCurrencyType value) {
                this.maximumPrice = value;
            }

            /**
             * Gets the value of the method property.
             * 
             * @return
             *     possible object is
             *     {@link OntologyPricingMethodType }
             *     
             */
            public OntologyPricingMethodType getMethod() {
                return method;
            }

            /**
             * Sets the value of the method property.
             * 
             * @param value
             *     allowed object is
             *     {@link OntologyPricingMethodType }
             *     
             */
            public void setMethod(OntologyPricingMethodType value) {
                this.method = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="EarliestStart">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="CalculationMethod" minOccurs="0">
         *                     &lt;complexType>
         *                       &lt;complexContent>
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                           &lt;sequence>
         *                             &lt;element name="Formula" minOccurs="0">
         *                               &lt;complexType>
         *                                 &lt;simpleContent>
         *                                   &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_OfferAvailabilityStartFormula">
         *                                     &lt;attribute name="OtherType">
         *                                       &lt;simpleType>
         *                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *                                           &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
         *                                         &lt;/restriction>
         *                                       &lt;/simpleType>
         *                                     &lt;/attribute>
         *                                     &lt;attribute name="OntologyRefID">
         *                                       &lt;simpleType>
         *                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *                                           &lt;pattern value="[0-9]{1,8}"/>
         *                                         &lt;/restriction>
         *                                       &lt;/simpleType>
         *                                     &lt;/attribute>
         *                                   &lt;/extension>
         *                                 &lt;/simpleContent>
         *                               &lt;/complexType>
         *                             &lt;/element>
         *                             &lt;element name="Distance" minOccurs="0">
         *                               &lt;complexType>
         *                                 &lt;complexContent>
         *                                   &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyDistanceType">
         *                                   &lt;/extension>
         *                                 &lt;/complexContent>
         *                               &lt;/complexType>
         *                             &lt;/element>
         *                             &lt;element name="Duration" minOccurs="0">
         *                               &lt;complexType>
         *                                 &lt;simpleContent>
         *                                   &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_OfferDurationUOM">
         *                                     &lt;attribute name="DecimalValue" use="required" type="{http://www.w3.org/2001/XMLSchema}decimal" />
         *                                     &lt;attribute name="OtherType">
         *                                       &lt;simpleType>
         *                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *                                           &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
         *                                         &lt;/restriction>
         *                                       &lt;/simpleType>
         *                                     &lt;/attribute>
         *                                     &lt;attribute name="OntologyRefID">
         *                                       &lt;simpleType>
         *                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *                                           &lt;pattern value="[0-9]{1,8}"/>
         *                                         &lt;/restriction>
         *                                       &lt;/simpleType>
         *                                     &lt;/attribute>
         *                                   &lt;/extension>
         *                                 &lt;/simpleContent>
         *                               &lt;/complexType>
         *                             &lt;/element>
         *                             &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
         *                           &lt;/sequence>
         *                           &lt;attribute name="OtherType">
         *                             &lt;simpleType>
         *                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *                                 &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
         *                               &lt;/restriction>
         *                             &lt;/simpleType>
         *                           &lt;/attribute>
         *                           &lt;attribute name="OntologyRefID">
         *                             &lt;simpleType>
         *                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *                                 &lt;pattern value="[0-9]{1,8}"/>
         *                               &lt;/restriction>
         *                             &lt;/simpleType>
         *                           &lt;/attribute>
         *                         &lt;/restriction>
         *                       &lt;/complexContent>
         *                     &lt;/complexType>
         *                   &lt;/element>
         *                   &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
         *                 &lt;/sequence>
         *                 &lt;attribute name="DateTime" use="required" type="{http://www.w3.org/2001/XMLSchema}dateTime" />
         *                 &lt;attribute name="OntologyRefID">
         *                   &lt;simpleType>
         *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *                       &lt;pattern value="[0-9]{1,8}"/>
         *                     &lt;/restriction>
         *                   &lt;/simpleType>
         *                 &lt;/attribute>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="MaximumDuration" minOccurs="0">
         *           &lt;complexType>
         *             &lt;simpleContent>
         *               &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_OfferDurationUOM">
         *                 &lt;attribute name="DecimalValue" use="required" type="{http://www.w3.org/2001/XMLSchema}decimal" />
         *                 &lt;attribute name="OtherType">
         *                   &lt;simpleType>
         *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *                       &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
         *                     &lt;/restriction>
         *                   &lt;/simpleType>
         *                 &lt;/attribute>
         *                 &lt;attribute name="OntologyRefID">
         *                   &lt;simpleType>
         *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *                       &lt;pattern value="[0-9]{1,8}"/>
         *                     &lt;/restriction>
         *                   &lt;/simpleType>
         *                 &lt;/attribute>
         *               &lt;/extension>
         *             &lt;/simpleContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
         *       &lt;/sequence>
         *       &lt;attribute name="OntologyRefID">
         *         &lt;simpleType>
         *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *             &lt;pattern value="[0-9]{1,8}"/>
         *           &lt;/restriction>
         *         &lt;/simpleType>
         *       &lt;/attribute>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "earliestStart",
            "maximumDuration",
            "ontologyExtension"
        })
        public static class TimePeriod {

            @XmlElement(name = "EarliestStart", required = true)
            protected MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart earliestStart;
            @XmlElement(name = "MaximumDuration")
            protected MultiModalOfferType.RequestedOffer.TimePeriod.MaximumDuration maximumDuration;
            @XmlElement(name = "OntologyExtension")
            protected OntologyExtensionType ontologyExtension;
            @XmlAttribute(name = "OntologyRefID")
            protected String ontologyRefID;

            /**
             * Gets the value of the earliestStart property.
             * 
             * @return
             *     possible object is
             *     {@link MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart }
             *     
             */
            public MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart getEarliestStart() {
                return earliestStart;
            }

            /**
             * Sets the value of the earliestStart property.
             * 
             * @param value
             *     allowed object is
             *     {@link MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart }
             *     
             */
            public void setEarliestStart(MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart value) {
                this.earliestStart = value;
            }

            /**
             * Gets the value of the maximumDuration property.
             * 
             * @return
             *     possible object is
             *     {@link MultiModalOfferType.RequestedOffer.TimePeriod.MaximumDuration }
             *     
             */
            public MultiModalOfferType.RequestedOffer.TimePeriod.MaximumDuration getMaximumDuration() {
                return maximumDuration;
            }

            /**
             * Sets the value of the maximumDuration property.
             * 
             * @param value
             *     allowed object is
             *     {@link MultiModalOfferType.RequestedOffer.TimePeriod.MaximumDuration }
             *     
             */
            public void setMaximumDuration(MultiModalOfferType.RequestedOffer.TimePeriod.MaximumDuration value) {
                this.maximumDuration = value;
            }

            /**
             * Gets the value of the ontologyExtension property.
             * 
             * @return
             *     possible object is
             *     {@link OntologyExtensionType }
             *     
             */
            public OntologyExtensionType getOntologyExtension() {
                return ontologyExtension;
            }

            /**
             * Sets the value of the ontologyExtension property.
             * 
             * @param value
             *     allowed object is
             *     {@link OntologyExtensionType }
             *     
             */
            public void setOntologyExtension(OntologyExtensionType value) {
                this.ontologyExtension = value;
            }

            /**
             * Gets the value of the ontologyRefID property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getOntologyRefID() {
                return ontologyRefID;
            }

            /**
             * Sets the value of the ontologyRefID property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setOntologyRefID(String value) {
                this.ontologyRefID = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="CalculationMethod" minOccurs="0">
             *           &lt;complexType>
             *             &lt;complexContent>
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                 &lt;sequence>
             *                   &lt;element name="Formula" minOccurs="0">
             *                     &lt;complexType>
             *                       &lt;simpleContent>
             *                         &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_OfferAvailabilityStartFormula">
             *                           &lt;attribute name="OtherType">
             *                             &lt;simpleType>
             *                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
             *                                 &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
             *                               &lt;/restriction>
             *                             &lt;/simpleType>
             *                           &lt;/attribute>
             *                           &lt;attribute name="OntologyRefID">
             *                             &lt;simpleType>
             *                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
             *                                 &lt;pattern value="[0-9]{1,8}"/>
             *                               &lt;/restriction>
             *                             &lt;/simpleType>
             *                           &lt;/attribute>
             *                         &lt;/extension>
             *                       &lt;/simpleContent>
             *                     &lt;/complexType>
             *                   &lt;/element>
             *                   &lt;element name="Distance" minOccurs="0">
             *                     &lt;complexType>
             *                       &lt;complexContent>
             *                         &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyDistanceType">
             *                         &lt;/extension>
             *                       &lt;/complexContent>
             *                     &lt;/complexType>
             *                   &lt;/element>
             *                   &lt;element name="Duration" minOccurs="0">
             *                     &lt;complexType>
             *                       &lt;simpleContent>
             *                         &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_OfferDurationUOM">
             *                           &lt;attribute name="DecimalValue" use="required" type="{http://www.w3.org/2001/XMLSchema}decimal" />
             *                           &lt;attribute name="OtherType">
             *                             &lt;simpleType>
             *                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
             *                                 &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
             *                               &lt;/restriction>
             *                             &lt;/simpleType>
             *                           &lt;/attribute>
             *                           &lt;attribute name="OntologyRefID">
             *                             &lt;simpleType>
             *                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
             *                                 &lt;pattern value="[0-9]{1,8}"/>
             *                               &lt;/restriction>
             *                             &lt;/simpleType>
             *                           &lt;/attribute>
             *                         &lt;/extension>
             *                       &lt;/simpleContent>
             *                     &lt;/complexType>
             *                   &lt;/element>
             *                   &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
             *                 &lt;/sequence>
             *                 &lt;attribute name="OtherType">
             *                   &lt;simpleType>
             *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
             *                       &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
             *                     &lt;/restriction>
             *                   &lt;/simpleType>
             *                 &lt;/attribute>
             *                 &lt;attribute name="OntologyRefID">
             *                   &lt;simpleType>
             *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
             *                       &lt;pattern value="[0-9]{1,8}"/>
             *                     &lt;/restriction>
             *                   &lt;/simpleType>
             *                 &lt;/attribute>
             *               &lt;/restriction>
             *             &lt;/complexContent>
             *           &lt;/complexType>
             *         &lt;/element>
             *         &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
             *       &lt;/sequence>
             *       &lt;attribute name="DateTime" use="required" type="{http://www.w3.org/2001/XMLSchema}dateTime" />
             *       &lt;attribute name="OntologyRefID">
             *         &lt;simpleType>
             *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
             *             &lt;pattern value="[0-9]{1,8}"/>
             *           &lt;/restriction>
             *         &lt;/simpleType>
             *       &lt;/attribute>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "calculationMethod",
                "ontologyExtension"
            })
            public static class EarliestStart {

                @XmlElement(name = "CalculationMethod")
                protected MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod calculationMethod;
                @XmlElement(name = "OntologyExtension")
                protected OntologyExtensionType ontologyExtension;
                @XmlAttribute(name = "DateTime", required = true)
                @XmlSchemaType(name = "dateTime")
                protected XMLGregorianCalendar dateTime;
                @XmlAttribute(name = "OntologyRefID")
                protected String ontologyRefID;

                /**
                 * Gets the value of the calculationMethod property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod }
                 *     
                 */
                public MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod getCalculationMethod() {
                    return calculationMethod;
                }

                /**
                 * Sets the value of the calculationMethod property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod }
                 *     
                 */
                public void setCalculationMethod(MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod value) {
                    this.calculationMethod = value;
                }

                /**
                 * Gets the value of the ontologyExtension property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link OntologyExtensionType }
                 *     
                 */
                public OntologyExtensionType getOntologyExtension() {
                    return ontologyExtension;
                }

                /**
                 * Sets the value of the ontologyExtension property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link OntologyExtensionType }
                 *     
                 */
                public void setOntologyExtension(OntologyExtensionType value) {
                    this.ontologyExtension = value;
                }

                /**
                 * Gets the value of the dateTime property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public XMLGregorianCalendar getDateTime() {
                    return dateTime;
                }

                /**
                 * Sets the value of the dateTime property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public void setDateTime(XMLGregorianCalendar value) {
                    this.dateTime = value;
                }

                /**
                 * Gets the value of the ontologyRefID property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getOntologyRefID() {
                    return ontologyRefID;
                }

                /**
                 * Sets the value of the ontologyRefID property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setOntologyRefID(String value) {
                    this.ontologyRefID = value;
                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType>
                 *   &lt;complexContent>
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
                 *       &lt;sequence>
                 *         &lt;element name="Formula" minOccurs="0">
                 *           &lt;complexType>
                 *             &lt;simpleContent>
                 *               &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_OfferAvailabilityStartFormula">
                 *                 &lt;attribute name="OtherType">
                 *                   &lt;simpleType>
                 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
                 *                       &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
                 *                     &lt;/restriction>
                 *                   &lt;/simpleType>
                 *                 &lt;/attribute>
                 *                 &lt;attribute name="OntologyRefID">
                 *                   &lt;simpleType>
                 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
                 *                       &lt;pattern value="[0-9]{1,8}"/>
                 *                     &lt;/restriction>
                 *                   &lt;/simpleType>
                 *                 &lt;/attribute>
                 *               &lt;/extension>
                 *             &lt;/simpleContent>
                 *           &lt;/complexType>
                 *         &lt;/element>
                 *         &lt;element name="Distance" minOccurs="0">
                 *           &lt;complexType>
                 *             &lt;complexContent>
                 *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyDistanceType">
                 *               &lt;/extension>
                 *             &lt;/complexContent>
                 *           &lt;/complexType>
                 *         &lt;/element>
                 *         &lt;element name="Duration" minOccurs="0">
                 *           &lt;complexType>
                 *             &lt;simpleContent>
                 *               &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_OfferDurationUOM">
                 *                 &lt;attribute name="DecimalValue" use="required" type="{http://www.w3.org/2001/XMLSchema}decimal" />
                 *                 &lt;attribute name="OtherType">
                 *                   &lt;simpleType>
                 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
                 *                       &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
                 *                     &lt;/restriction>
                 *                   &lt;/simpleType>
                 *                 &lt;/attribute>
                 *                 &lt;attribute name="OntologyRefID">
                 *                   &lt;simpleType>
                 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
                 *                       &lt;pattern value="[0-9]{1,8}"/>
                 *                     &lt;/restriction>
                 *                   &lt;/simpleType>
                 *                 &lt;/attribute>
                 *               &lt;/extension>
                 *             &lt;/simpleContent>
                 *           &lt;/complexType>
                 *         &lt;/element>
                 *         &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
                 *       &lt;/sequence>
                 *       &lt;attribute name="OtherType">
                 *         &lt;simpleType>
                 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
                 *             &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
                 *           &lt;/restriction>
                 *         &lt;/simpleType>
                 *       &lt;/attribute>
                 *       &lt;attribute name="OntologyRefID">
                 *         &lt;simpleType>
                 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
                 *             &lt;pattern value="[0-9]{1,8}"/>
                 *           &lt;/restriction>
                 *         &lt;/simpleType>
                 *       &lt;/attribute>
                 *     &lt;/restriction>
                 *   &lt;/complexContent>
                 * &lt;/complexType>
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "formula",
                    "distance",
                    "duration",
                    "ontologyExtension"
                })
                public static class CalculationMethod {

                    @XmlElement(name = "Formula")
                    protected MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod.Formula formula;
                    @XmlElement(name = "Distance")
                    protected MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod.Distance distance;
                    @XmlElement(name = "Duration")
                    protected MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod.Duration duration;
                    @XmlElement(name = "OntologyExtension")
                    protected OntologyExtensionType ontologyExtension;
                    @XmlAttribute(name = "OtherType")
                    protected String otherType;
                    @XmlAttribute(name = "OntologyRefID")
                    protected String ontologyRefID;

                    /**
                     * Gets the value of the formula property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod.Formula }
                     *     
                     */
                    public MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod.Formula getFormula() {
                        return formula;
                    }

                    /**
                     * Sets the value of the formula property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod.Formula }
                     *     
                     */
                    public void setFormula(MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod.Formula value) {
                        this.formula = value;
                    }

                    /**
                     * Gets the value of the distance property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod.Distance }
                     *     
                     */
                    public MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod.Distance getDistance() {
                        return distance;
                    }

                    /**
                     * Sets the value of the distance property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod.Distance }
                     *     
                     */
                    public void setDistance(MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod.Distance value) {
                        this.distance = value;
                    }

                    /**
                     * Gets the value of the duration property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod.Duration }
                     *     
                     */
                    public MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod.Duration getDuration() {
                        return duration;
                    }

                    /**
                     * Sets the value of the duration property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod.Duration }
                     *     
                     */
                    public void setDuration(MultiModalOfferType.RequestedOffer.TimePeriod.EarliestStart.CalculationMethod.Duration value) {
                        this.duration = value;
                    }

                    /**
                     * Gets the value of the ontologyExtension property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link OntologyExtensionType }
                     *     
                     */
                    public OntologyExtensionType getOntologyExtension() {
                        return ontologyExtension;
                    }

                    /**
                     * Sets the value of the ontologyExtension property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link OntologyExtensionType }
                     *     
                     */
                    public void setOntologyExtension(OntologyExtensionType value) {
                        this.ontologyExtension = value;
                    }

                    /**
                     * Gets the value of the otherType property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getOtherType() {
                        return otherType;
                    }

                    /**
                     * Sets the value of the otherType property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setOtherType(String value) {
                        this.otherType = value;
                    }

                    /**
                     * Gets the value of the ontologyRefID property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getOntologyRefID() {
                        return ontologyRefID;
                    }

                    /**
                     * Sets the value of the ontologyRefID property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setOntologyRefID(String value) {
                        this.ontologyRefID = value;
                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType>
                     *   &lt;complexContent>
                     *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyDistanceType">
                     *     &lt;/extension>
                     *   &lt;/complexContent>
                     * &lt;/complexType>
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "")
                    public static class Distance
                        extends OntologyDistanceType
                    {


                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType>
                     *   &lt;simpleContent>
                     *     &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_OfferDurationUOM">
                     *       &lt;attribute name="DecimalValue" use="required" type="{http://www.w3.org/2001/XMLSchema}decimal" />
                     *       &lt;attribute name="OtherType">
                     *         &lt;simpleType>
                     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
                     *             &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
                     *           &lt;/restriction>
                     *         &lt;/simpleType>
                     *       &lt;/attribute>
                     *       &lt;attribute name="OntologyRefID">
                     *         &lt;simpleType>
                     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
                     *             &lt;pattern value="[0-9]{1,8}"/>
                     *           &lt;/restriction>
                     *         &lt;/simpleType>
                     *       &lt;/attribute>
                     *     &lt;/extension>
                     *   &lt;/simpleContent>
                     * &lt;/complexType>
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "value"
                    })
                    public static class Duration {

                        @XmlValue
                        protected ListOfferDurationUOM value;
                        @XmlAttribute(name = "DecimalValue", required = true)
                        protected BigDecimal decimalValue;
                        @XmlAttribute(name = "OtherType")
                        protected String otherType;
                        @XmlAttribute(name = "OntologyRefID")
                        protected String ontologyRefID;

                        /**
                         * Source: Unit of Measure (UOM) OpenTravel codelist.
                         * 
                         * @return
                         *     possible object is
                         *     {@link ListOfferDurationUOM }
                         *     
                         */
                        public ListOfferDurationUOM getValue() {
                            return value;
                        }

                        /**
                         * Sets the value of the value property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link ListOfferDurationUOM }
                         *     
                         */
                        public void setValue(ListOfferDurationUOM value) {
                            this.value = value;
                        }

                        /**
                         * Gets the value of the decimalValue property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link BigDecimal }
                         *     
                         */
                        public BigDecimal getDecimalValue() {
                            return decimalValue;
                        }

                        /**
                         * Sets the value of the decimalValue property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link BigDecimal }
                         *     
                         */
                        public void setDecimalValue(BigDecimal value) {
                            this.decimalValue = value;
                        }

                        /**
                         * Gets the value of the otherType property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getOtherType() {
                            return otherType;
                        }

                        /**
                         * Sets the value of the otherType property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setOtherType(String value) {
                            this.otherType = value;
                        }

                        /**
                         * Gets the value of the ontologyRefID property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getOntologyRefID() {
                            return ontologyRefID;
                        }

                        /**
                         * Sets the value of the ontologyRefID property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setOntologyRefID(String value) {
                            this.ontologyRefID = value;
                        }

                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType>
                     *   &lt;simpleContent>
                     *     &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_OfferAvailabilityStartFormula">
                     *       &lt;attribute name="OtherType">
                     *         &lt;simpleType>
                     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
                     *             &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
                     *           &lt;/restriction>
                     *         &lt;/simpleType>
                     *       &lt;/attribute>
                     *       &lt;attribute name="OntologyRefID">
                     *         &lt;simpleType>
                     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
                     *             &lt;pattern value="[0-9]{1,8}"/>
                     *           &lt;/restriction>
                     *         &lt;/simpleType>
                     *       &lt;/attribute>
                     *     &lt;/extension>
                     *   &lt;/simpleContent>
                     * &lt;/complexType>
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "value"
                    })
                    public static class Formula {

                        @XmlValue
                        protected ListOfferAvailabilityStartFormula value;
                        @XmlAttribute(name = "OtherType")
                        protected String otherType;
                        @XmlAttribute(name = "OntologyRefID")
                        protected String ontologyRefID;

                        /**
                         * Source: OpenTravel
                         * 
                         * @return
                         *     possible object is
                         *     {@link ListOfferAvailabilityStartFormula }
                         *     
                         */
                        public ListOfferAvailabilityStartFormula getValue() {
                            return value;
                        }

                        /**
                         * Sets the value of the value property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link ListOfferAvailabilityStartFormula }
                         *     
                         */
                        public void setValue(ListOfferAvailabilityStartFormula value) {
                            this.value = value;
                        }

                        /**
                         * Gets the value of the otherType property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getOtherType() {
                            return otherType;
                        }

                        /**
                         * Sets the value of the otherType property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setOtherType(String value) {
                            this.otherType = value;
                        }

                        /**
                         * Gets the value of the ontologyRefID property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getOntologyRefID() {
                            return ontologyRefID;
                        }

                        /**
                         * Sets the value of the ontologyRefID property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setOntologyRefID(String value) {
                            this.ontologyRefID = value;
                        }

                    }

                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;simpleContent>
             *     &lt;extension base="&lt;http://www.opentravel.org/OTA/2003/05>List_OfferDurationUOM">
             *       &lt;attribute name="DecimalValue" use="required" type="{http://www.w3.org/2001/XMLSchema}decimal" />
             *       &lt;attribute name="OtherType">
             *         &lt;simpleType>
             *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
             *             &lt;pattern value="[a-zA-Z0-9]{1,64}"/>
             *           &lt;/restriction>
             *         &lt;/simpleType>
             *       &lt;/attribute>
             *       &lt;attribute name="OntologyRefID">
             *         &lt;simpleType>
             *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
             *             &lt;pattern value="[0-9]{1,8}"/>
             *           &lt;/restriction>
             *         &lt;/simpleType>
             *       &lt;/attribute>
             *     &lt;/extension>
             *   &lt;/simpleContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "value"
            })
            public static class MaximumDuration {

                @XmlValue
                protected ListOfferDurationUOM value;
                @XmlAttribute(name = "DecimalValue", required = true)
                protected BigDecimal decimalValue;
                @XmlAttribute(name = "OtherType")
                protected String otherType;
                @XmlAttribute(name = "OntologyRefID")
                protected String ontologyRefID;

                /**
                 * Source: Unit of Measure (UOM) OpenTravel codelist.
                 * 
                 * @return
                 *     possible object is
                 *     {@link ListOfferDurationUOM }
                 *     
                 */
                public ListOfferDurationUOM getValue() {
                    return value;
                }

                /**
                 * Sets the value of the value property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link ListOfferDurationUOM }
                 *     
                 */
                public void setValue(ListOfferDurationUOM value) {
                    this.value = value;
                }

                /**
                 * Gets the value of the decimalValue property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getDecimalValue() {
                    return decimalValue;
                }

                /**
                 * Sets the value of the decimalValue property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setDecimalValue(BigDecimal value) {
                    this.decimalValue = value;
                }

                /**
                 * Gets the value of the otherType property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getOtherType() {
                    return otherType;
                }

                /**
                 * Sets the value of the otherType property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setOtherType(String value) {
                    this.otherType = value;
                }

                /**
                 * Gets the value of the ontologyRefID property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getOntologyRefID() {
                    return ontologyRefID;
                }

                /**
                 * Sets the value of the ontologyRefID property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setOntologyRefID(String value) {
                    this.ontologyRefID = value;
                }

            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyCompanyType">
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class RequestingParty
        extends OntologyCompanyType
    {


    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="TripPurpose" type="{http://www.opentravel.org/OTA/2003/05}OntologyTripPurposeType" minOccurs="0"/>
     *         &lt;element name="Classification" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyTravelerClassType">
     *               &lt;/extension>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="DetailInfo" maxOccurs="unbounded" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Identification" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="Name" type="{http://www.opentravel.org/OTA/2003/05}OntologyNameType" minOccurs="0"/>
     *                             &lt;element name="Age" type="{http://www.opentravel.org/OTA/2003/05}OntologyAgeBirthDateType" minOccurs="0"/>
     *                             &lt;element name="Address" type="{http://www.opentravel.org/OTA/2003/05}OntologyAddressType" minOccurs="0"/>
     *                             &lt;element name="Contact" type="{http://www.opentravel.org/OTA/2003/05}OntologyContactType" minOccurs="0"/>
     *                             &lt;element name="LoyaltyProgram" type="{http://www.opentravel.org/OTA/2003/05}OntologyLoyaltyType" maxOccurs="unbounded" minOccurs="0"/>
     *                             &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="CustomerValue" type="{http://www.opentravel.org/OTA/2003/05}OntologyValueType" minOccurs="0"/>
     *                 &lt;/sequence>
     *                 &lt;attribute name="ServiceAnimalInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
     *                 &lt;attribute name="DisabledInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
     *                 &lt;attribute name="FemaleInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
     *                 &lt;attribute name="MaleInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "tripPurpose",
        "classification",
        "detailInfo",
        "ontologyExtension"
    })
    public static class TravelerCharacteristics {

        @XmlElement(name = "TripPurpose")
        protected OntologyTripPurposeType tripPurpose;
        @XmlElement(name = "Classification")
        protected MultiModalOfferType.TravelerCharacteristics.Classification classification;
        @XmlElement(name = "DetailInfo")
        protected List<MultiModalOfferType.TravelerCharacteristics.DetailInfo> detailInfo;
        @XmlElement(name = "OntologyExtension")
        protected OntologyExtensionType ontologyExtension;

        /**
         * Gets the value of the tripPurpose property.
         * 
         * @return
         *     possible object is
         *     {@link OntologyTripPurposeType }
         *     
         */
        public OntologyTripPurposeType getTripPurpose() {
            return tripPurpose;
        }

        /**
         * Sets the value of the tripPurpose property.
         * 
         * @param value
         *     allowed object is
         *     {@link OntologyTripPurposeType }
         *     
         */
        public void setTripPurpose(OntologyTripPurposeType value) {
            this.tripPurpose = value;
        }

        /**
         * Gets the value of the classification property.
         * 
         * @return
         *     possible object is
         *     {@link MultiModalOfferType.TravelerCharacteristics.Classification }
         *     
         */
        public MultiModalOfferType.TravelerCharacteristics.Classification getClassification() {
            return classification;
        }

        /**
         * Sets the value of the classification property.
         * 
         * @param value
         *     allowed object is
         *     {@link MultiModalOfferType.TravelerCharacteristics.Classification }
         *     
         */
        public void setClassification(MultiModalOfferType.TravelerCharacteristics.Classification value) {
            this.classification = value;
        }

        /**
         * Gets the value of the detailInfo property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the detailInfo property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDetailInfo().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link MultiModalOfferType.TravelerCharacteristics.DetailInfo }
         * 
         * 
         */
        public List<MultiModalOfferType.TravelerCharacteristics.DetailInfo> getDetailInfo() {
            if (detailInfo == null) {
                detailInfo = new ArrayList<MultiModalOfferType.TravelerCharacteristics.DetailInfo>();
            }
            return this.detailInfo;
        }

        /**
         * Gets the value of the ontologyExtension property.
         * 
         * @return
         *     possible object is
         *     {@link OntologyExtensionType }
         *     
         */
        public OntologyExtensionType getOntologyExtension() {
            return ontologyExtension;
        }

        /**
         * Sets the value of the ontologyExtension property.
         * 
         * @param value
         *     allowed object is
         *     {@link OntologyExtensionType }
         *     
         */
        public void setOntologyExtension(OntologyExtensionType value) {
            this.ontologyExtension = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyTravelerClassType">
         *     &lt;/extension>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class Classification
            extends OntologyTravelerClassType
        {


        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="Identification" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="Name" type="{http://www.opentravel.org/OTA/2003/05}OntologyNameType" minOccurs="0"/>
         *                   &lt;element name="Age" type="{http://www.opentravel.org/OTA/2003/05}OntologyAgeBirthDateType" minOccurs="0"/>
         *                   &lt;element name="Address" type="{http://www.opentravel.org/OTA/2003/05}OntologyAddressType" minOccurs="0"/>
         *                   &lt;element name="Contact" type="{http://www.opentravel.org/OTA/2003/05}OntologyContactType" minOccurs="0"/>
         *                   &lt;element name="LoyaltyProgram" type="{http://www.opentravel.org/OTA/2003/05}OntologyLoyaltyType" maxOccurs="unbounded" minOccurs="0"/>
         *                   &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="CustomerValue" type="{http://www.opentravel.org/OTA/2003/05}OntologyValueType" minOccurs="0"/>
         *       &lt;/sequence>
         *       &lt;attribute name="ServiceAnimalInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
         *       &lt;attribute name="DisabledInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
         *       &lt;attribute name="FemaleInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
         *       &lt;attribute name="MaleInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "identification",
            "customerValue"
        })
        public static class DetailInfo {

            @XmlElement(name = "Identification")
            protected MultiModalOfferType.TravelerCharacteristics.DetailInfo.Identification identification;
            @XmlElement(name = "CustomerValue")
            protected OntologyValueType customerValue;
            @XmlAttribute(name = "ServiceAnimalInd")
            protected Boolean serviceAnimalInd;
            @XmlAttribute(name = "DisabledInd")
            protected Boolean disabledInd;
            @XmlAttribute(name = "FemaleInd")
            protected Boolean femaleInd;
            @XmlAttribute(name = "MaleInd")
            protected Boolean maleInd;

            /**
             * Gets the value of the identification property.
             * 
             * @return
             *     possible object is
             *     {@link MultiModalOfferType.TravelerCharacteristics.DetailInfo.Identification }
             *     
             */
            public MultiModalOfferType.TravelerCharacteristics.DetailInfo.Identification getIdentification() {
                return identification;
            }

            /**
             * Sets the value of the identification property.
             * 
             * @param value
             *     allowed object is
             *     {@link MultiModalOfferType.TravelerCharacteristics.DetailInfo.Identification }
             *     
             */
            public void setIdentification(MultiModalOfferType.TravelerCharacteristics.DetailInfo.Identification value) {
                this.identification = value;
            }

            /**
             * Gets the value of the customerValue property.
             * 
             * @return
             *     possible object is
             *     {@link OntologyValueType }
             *     
             */
            public OntologyValueType getCustomerValue() {
                return customerValue;
            }

            /**
             * Sets the value of the customerValue property.
             * 
             * @param value
             *     allowed object is
             *     {@link OntologyValueType }
             *     
             */
            public void setCustomerValue(OntologyValueType value) {
                this.customerValue = value;
            }

            /**
             * Gets the value of the serviceAnimalInd property.
             * 
             * @return
             *     possible object is
             *     {@link Boolean }
             *     
             */
            public Boolean isServiceAnimalInd() {
                return serviceAnimalInd;
            }

            /**
             * Sets the value of the serviceAnimalInd property.
             * 
             * @param value
             *     allowed object is
             *     {@link Boolean }
             *     
             */
            public void setServiceAnimalInd(Boolean value) {
                this.serviceAnimalInd = value;
            }

            /**
             * Gets the value of the disabledInd property.
             * 
             * @return
             *     possible object is
             *     {@link Boolean }
             *     
             */
            public Boolean isDisabledInd() {
                return disabledInd;
            }

            /**
             * Sets the value of the disabledInd property.
             * 
             * @param value
             *     allowed object is
             *     {@link Boolean }
             *     
             */
            public void setDisabledInd(Boolean value) {
                this.disabledInd = value;
            }

            /**
             * Gets the value of the femaleInd property.
             * 
             * @return
             *     possible object is
             *     {@link Boolean }
             *     
             */
            public Boolean isFemaleInd() {
                return femaleInd;
            }

            /**
             * Sets the value of the femaleInd property.
             * 
             * @param value
             *     allowed object is
             *     {@link Boolean }
             *     
             */
            public void setFemaleInd(Boolean value) {
                this.femaleInd = value;
            }

            /**
             * Gets the value of the maleInd property.
             * 
             * @return
             *     possible object is
             *     {@link Boolean }
             *     
             */
            public Boolean isMaleInd() {
                return maleInd;
            }

            /**
             * Sets the value of the maleInd property.
             * 
             * @param value
             *     allowed object is
             *     {@link Boolean }
             *     
             */
            public void setMaleInd(Boolean value) {
                this.maleInd = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="Name" type="{http://www.opentravel.org/OTA/2003/05}OntologyNameType" minOccurs="0"/>
             *         &lt;element name="Age" type="{http://www.opentravel.org/OTA/2003/05}OntologyAgeBirthDateType" minOccurs="0"/>
             *         &lt;element name="Address" type="{http://www.opentravel.org/OTA/2003/05}OntologyAddressType" minOccurs="0"/>
             *         &lt;element name="Contact" type="{http://www.opentravel.org/OTA/2003/05}OntologyContactType" minOccurs="0"/>
             *         &lt;element name="LoyaltyProgram" type="{http://www.opentravel.org/OTA/2003/05}OntologyLoyaltyType" maxOccurs="unbounded" minOccurs="0"/>
             *         &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "name",
                "age",
                "address",
                "contact",
                "loyaltyProgram",
                "ontologyExtension"
            })
            public static class Identification {

                @XmlElement(name = "Name")
                protected OntologyNameType name;
                @XmlElement(name = "Age")
                protected OntologyAgeBirthDateType age;
                @XmlElement(name = "Address")
                protected OntologyAddressType address;
                @XmlElement(name = "Contact")
                protected OntologyContactType contact;
                @XmlElement(name = "LoyaltyProgram")
                protected List<OntologyLoyaltyType> loyaltyProgram;
                @XmlElement(name = "OntologyExtension")
                protected OntologyExtensionType ontologyExtension;

                /**
                 * Gets the value of the name property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link OntologyNameType }
                 *     
                 */
                public OntologyNameType getName() {
                    return name;
                }

                /**
                 * Sets the value of the name property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link OntologyNameType }
                 *     
                 */
                public void setName(OntologyNameType value) {
                    this.name = value;
                }

                /**
                 * Gets the value of the age property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link OntologyAgeBirthDateType }
                 *     
                 */
                public OntologyAgeBirthDateType getAge() {
                    return age;
                }

                /**
                 * Sets the value of the age property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link OntologyAgeBirthDateType }
                 *     
                 */
                public void setAge(OntologyAgeBirthDateType value) {
                    this.age = value;
                }

                /**
                 * Gets the value of the address property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link OntologyAddressType }
                 *     
                 */
                public OntologyAddressType getAddress() {
                    return address;
                }

                /**
                 * Sets the value of the address property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link OntologyAddressType }
                 *     
                 */
                public void setAddress(OntologyAddressType value) {
                    this.address = value;
                }

                /**
                 * Gets the value of the contact property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link OntologyContactType }
                 *     
                 */
                public OntologyContactType getContact() {
                    return contact;
                }

                /**
                 * Sets the value of the contact property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link OntologyContactType }
                 *     
                 */
                public void setContact(OntologyContactType value) {
                    this.contact = value;
                }

                /**
                 * Gets the value of the loyaltyProgram property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the loyaltyProgram property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getLoyaltyProgram().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link OntologyLoyaltyType }
                 * 
                 * 
                 */
                public List<OntologyLoyaltyType> getLoyaltyProgram() {
                    if (loyaltyProgram == null) {
                        loyaltyProgram = new ArrayList<OntologyLoyaltyType>();
                    }
                    return this.loyaltyProgram;
                }

                /**
                 * Gets the value of the ontologyExtension property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link OntologyExtensionType }
                 *     
                 */
                public OntologyExtensionType getOntologyExtension() {
                    return ontologyExtension;
                }

                /**
                 * Sets the value of the ontologyExtension property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link OntologyExtensionType }
                 *     
                 */
                public void setOntologyExtension(OntologyExtensionType value) {
                    this.ontologyExtension = value;
                }

            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Mode" type="{http://www.opentravel.org/OTA/2003/05}OntologyTripModeType"/>
     *         &lt;element name="BookingMethod" type="{http://www.opentravel.org/OTA/2003/05}OntologyBookingMethodType" minOccurs="0"/>
     *         &lt;element name="DateTimeDuration" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyTimeDurationType">
     *               &lt;/extension>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="Location" maxOccurs="unbounded" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyLocationType">
     *               &lt;/extension>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="PriceAndPayment" type="{http://www.opentravel.org/OTA/2003/05}OntologyPaymentType" minOccurs="0"/>
     *         &lt;element name="ReservationStatus" type="{http://www.opentravel.org/OTA/2003/05}OntologyReservationStatusType" minOccurs="0"/>
     *         &lt;element name="Baggage" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyBaggageType">
     *               &lt;/extension>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="Animals" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyAnimalType">
     *               &lt;/extension>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="Activity" type="{http://www.opentravel.org/OTA/2003/05}OntologyActivityType" minOccurs="0"/>
     *         &lt;element name="Lodging" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyLodgingType">
     *               &lt;/extension>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="Transportation" type="{http://www.opentravel.org/OTA/2003/05}OntologyTransportationType" minOccurs="0"/>
     *         &lt;element name="TripValue" type="{http://www.opentravel.org/OTA/2003/05}OntologyValueType" minOccurs="0"/>
     *         &lt;element ref="{http://www.opentravel.org/OTA/2003/05}OntologyExtension" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "mode",
        "bookingMethod",
        "dateTimeDuration",
        "location",
        "priceAndPayment",
        "reservationStatus",
        "baggage",
        "animals",
        "activity",
        "lodging",
        "transportation",
        "tripValue",
        "ontologyExtension"
    })
    public static class TripCharacteristics {

        @XmlElement(name = "Mode", required = true)
        protected OntologyTripModeType mode;
        @XmlElement(name = "BookingMethod")
        protected OntologyBookingMethodType bookingMethod;
        @XmlElement(name = "DateTimeDuration")
        protected MultiModalOfferType.TripCharacteristics.DateTimeDuration dateTimeDuration;
        @XmlElement(name = "Location")
        protected List<MultiModalOfferType.TripCharacteristics.Location> location;
        @XmlElement(name = "PriceAndPayment")
        protected OntologyPaymentType priceAndPayment;
        @XmlElement(name = "ReservationStatus")
        protected OntologyReservationStatusType reservationStatus;
        @XmlElement(name = "Baggage")
        protected MultiModalOfferType.TripCharacteristics.Baggage baggage;
        @XmlElement(name = "Animals")
        protected MultiModalOfferType.TripCharacteristics.Animals animals;
        @XmlElement(name = "Activity")
        protected OntologyActivityType activity;
        @XmlElement(name = "Lodging")
        protected MultiModalOfferType.TripCharacteristics.Lodging lodging;
        @XmlElement(name = "Transportation")
        protected OntologyTransportationType transportation;
        @XmlElement(name = "TripValue")
        protected OntologyValueType tripValue;
        @XmlElement(name = "OntologyExtension")
        protected OntologyExtensionType ontologyExtension;

        /**
         * Gets the value of the mode property.
         * 
         * @return
         *     possible object is
         *     {@link OntologyTripModeType }
         *     
         */
        public OntologyTripModeType getMode() {
            return mode;
        }

        /**
         * Sets the value of the mode property.
         * 
         * @param value
         *     allowed object is
         *     {@link OntologyTripModeType }
         *     
         */
        public void setMode(OntologyTripModeType value) {
            this.mode = value;
        }

        /**
         * Gets the value of the bookingMethod property.
         * 
         * @return
         *     possible object is
         *     {@link OntologyBookingMethodType }
         *     
         */
        public OntologyBookingMethodType getBookingMethod() {
            return bookingMethod;
        }

        /**
         * Sets the value of the bookingMethod property.
         * 
         * @param value
         *     allowed object is
         *     {@link OntologyBookingMethodType }
         *     
         */
        public void setBookingMethod(OntologyBookingMethodType value) {
            this.bookingMethod = value;
        }

        /**
         * Gets the value of the dateTimeDuration property.
         * 
         * @return
         *     possible object is
         *     {@link MultiModalOfferType.TripCharacteristics.DateTimeDuration }
         *     
         */
        public MultiModalOfferType.TripCharacteristics.DateTimeDuration getDateTimeDuration() {
            return dateTimeDuration;
        }

        /**
         * Sets the value of the dateTimeDuration property.
         * 
         * @param value
         *     allowed object is
         *     {@link MultiModalOfferType.TripCharacteristics.DateTimeDuration }
         *     
         */
        public void setDateTimeDuration(MultiModalOfferType.TripCharacteristics.DateTimeDuration value) {
            this.dateTimeDuration = value;
        }

        /**
         * Gets the value of the location property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the location property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getLocation().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link MultiModalOfferType.TripCharacteristics.Location }
         * 
         * 
         */
        public List<MultiModalOfferType.TripCharacteristics.Location> getLocation() {
            if (location == null) {
                location = new ArrayList<MultiModalOfferType.TripCharacteristics.Location>();
            }
            return this.location;
        }

        /**
         * Gets the value of the priceAndPayment property.
         * 
         * @return
         *     possible object is
         *     {@link OntologyPaymentType }
         *     
         */
        public OntologyPaymentType getPriceAndPayment() {
            return priceAndPayment;
        }

        /**
         * Sets the value of the priceAndPayment property.
         * 
         * @param value
         *     allowed object is
         *     {@link OntologyPaymentType }
         *     
         */
        public void setPriceAndPayment(OntologyPaymentType value) {
            this.priceAndPayment = value;
        }

        /**
         * Gets the value of the reservationStatus property.
         * 
         * @return
         *     possible object is
         *     {@link OntologyReservationStatusType }
         *     
         */
        public OntologyReservationStatusType getReservationStatus() {
            return reservationStatus;
        }

        /**
         * Sets the value of the reservationStatus property.
         * 
         * @param value
         *     allowed object is
         *     {@link OntologyReservationStatusType }
         *     
         */
        public void setReservationStatus(OntologyReservationStatusType value) {
            this.reservationStatus = value;
        }

        /**
         * Gets the value of the baggage property.
         * 
         * @return
         *     possible object is
         *     {@link MultiModalOfferType.TripCharacteristics.Baggage }
         *     
         */
        public MultiModalOfferType.TripCharacteristics.Baggage getBaggage() {
            return baggage;
        }

        /**
         * Sets the value of the baggage property.
         * 
         * @param value
         *     allowed object is
         *     {@link MultiModalOfferType.TripCharacteristics.Baggage }
         *     
         */
        public void setBaggage(MultiModalOfferType.TripCharacteristics.Baggage value) {
            this.baggage = value;
        }

        /**
         * Gets the value of the animals property.
         * 
         * @return
         *     possible object is
         *     {@link MultiModalOfferType.TripCharacteristics.Animals }
         *     
         */
        public MultiModalOfferType.TripCharacteristics.Animals getAnimals() {
            return animals;
        }

        /**
         * Sets the value of the animals property.
         * 
         * @param value
         *     allowed object is
         *     {@link MultiModalOfferType.TripCharacteristics.Animals }
         *     
         */
        public void setAnimals(MultiModalOfferType.TripCharacteristics.Animals value) {
            this.animals = value;
        }

        /**
         * Gets the value of the activity property.
         * 
         * @return
         *     possible object is
         *     {@link OntologyActivityType }
         *     
         */
        public OntologyActivityType getActivity() {
            return activity;
        }

        /**
         * Sets the value of the activity property.
         * 
         * @param value
         *     allowed object is
         *     {@link OntologyActivityType }
         *     
         */
        public void setActivity(OntologyActivityType value) {
            this.activity = value;
        }

        /**
         * Gets the value of the lodging property.
         * 
         * @return
         *     possible object is
         *     {@link MultiModalOfferType.TripCharacteristics.Lodging }
         *     
         */
        public MultiModalOfferType.TripCharacteristics.Lodging getLodging() {
            return lodging;
        }

        /**
         * Sets the value of the lodging property.
         * 
         * @param value
         *     allowed object is
         *     {@link MultiModalOfferType.TripCharacteristics.Lodging }
         *     
         */
        public void setLodging(MultiModalOfferType.TripCharacteristics.Lodging value) {
            this.lodging = value;
        }

        /**
         * Gets the value of the transportation property.
         * 
         * @return
         *     possible object is
         *     {@link OntologyTransportationType }
         *     
         */
        public OntologyTransportationType getTransportation() {
            return transportation;
        }

        /**
         * Sets the value of the transportation property.
         * 
         * @param value
         *     allowed object is
         *     {@link OntologyTransportationType }
         *     
         */
        public void setTransportation(OntologyTransportationType value) {
            this.transportation = value;
        }

        /**
         * Gets the value of the tripValue property.
         * 
         * @return
         *     possible object is
         *     {@link OntologyValueType }
         *     
         */
        public OntologyValueType getTripValue() {
            return tripValue;
        }

        /**
         * Sets the value of the tripValue property.
         * 
         * @param value
         *     allowed object is
         *     {@link OntologyValueType }
         *     
         */
        public void setTripValue(OntologyValueType value) {
            this.tripValue = value;
        }

        /**
         * Gets the value of the ontologyExtension property.
         * 
         * @return
         *     possible object is
         *     {@link OntologyExtensionType }
         *     
         */
        public OntologyExtensionType getOntologyExtension() {
            return ontologyExtension;
        }

        /**
         * Sets the value of the ontologyExtension property.
         * 
         * @param value
         *     allowed object is
         *     {@link OntologyExtensionType }
         *     
         */
        public void setOntologyExtension(OntologyExtensionType value) {
            this.ontologyExtension = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyAnimalType">
         *     &lt;/extension>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class Animals
            extends OntologyAnimalType
        {


        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyBaggageType">
         *     &lt;/extension>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class Baggage
            extends OntologyBaggageType
        {


        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyTimeDurationType">
         *     &lt;/extension>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class DateTimeDuration
            extends OntologyTimeDurationType
        {


        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyLocationType">
         *     &lt;/extension>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class Location
            extends OntologyLocationType
        {


        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}OntologyLodgingType">
         *     &lt;/extension>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class Lodging
            extends OntologyLodgingType
        {


        }

    }

}
