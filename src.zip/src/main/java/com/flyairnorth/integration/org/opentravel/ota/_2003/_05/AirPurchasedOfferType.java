
package com.flyairnorth.integration.org.opentravel.ota._2003._05;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Contains an array of ancillary items being or previously purchased for this trip. Internal airline and ATPCO encoding for airline delivered ancillary items and third party trip insurance are supported.
 * 
 * <p>Java class for AirPurchasedOfferType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AirPurchasedOfferType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PurchasedItem" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://www.opentravel.org/OTA/2003/05}AncillaryServiceDetailType">
 *                 &lt;sequence>
 *                   &lt;element name="AppliesTo" type="{http://www.opentravel.org/OTA/2003/05}ApplyPriceToType" minOccurs="0"/>
 *                   &lt;element name="LandProductInfo" type="{http://www.opentravel.org/OTA/2003/05}AirLandProductType" minOccurs="0"/>
 *                   &lt;element name="InsuranceProduct" type="{http://www.opentravel.org/OTA/2003/05}AirInsuranceOfferType" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AirPurchasedOfferType", propOrder = {
    "purchasedItem"
})
public class AirPurchasedOfferType {

    @XmlElement(name = "PurchasedItem", required = true)
    protected List<AirPurchasedOfferType.PurchasedItem> purchasedItem;

    /**
     * Gets the value of the purchasedItem property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the purchasedItem property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPurchasedItem().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AirPurchasedOfferType.PurchasedItem }
     * 
     * 
     */
    public List<AirPurchasedOfferType.PurchasedItem> getPurchasedItem() {
        if (purchasedItem == null) {
            purchasedItem = new ArrayList<AirPurchasedOfferType.PurchasedItem>();
        }
        return this.purchasedItem;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://www.opentravel.org/OTA/2003/05}AncillaryServiceDetailType">
     *       &lt;sequence>
     *         &lt;element name="AppliesTo" type="{http://www.opentravel.org/OTA/2003/05}ApplyPriceToType" minOccurs="0"/>
     *         &lt;element name="LandProductInfo" type="{http://www.opentravel.org/OTA/2003/05}AirLandProductType" minOccurs="0"/>
     *         &lt;element name="InsuranceProduct" type="{http://www.opentravel.org/OTA/2003/05}AirInsuranceOfferType" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "appliesTo",
        "landProductInfo",
        "insuranceProduct"
    })
    public static class PurchasedItem
        extends AncillaryServiceDetailType
    {

        @XmlElement(name = "AppliesTo")
        protected ApplyPriceToType appliesTo;
        @XmlElement(name = "LandProductInfo")
        protected AirLandProductType landProductInfo;
        @XmlElement(name = "InsuranceProduct")
        protected AirInsuranceOfferType insuranceProduct;

        /**
         * Gets the value of the appliesTo property.
         * 
         * @return
         *     possible object is
         *     {@link ApplyPriceToType }
         *     
         */
        public ApplyPriceToType getAppliesTo() {
            return appliesTo;
        }

        /**
         * Sets the value of the appliesTo property.
         * 
         * @param value
         *     allowed object is
         *     {@link ApplyPriceToType }
         *     
         */
        public void setAppliesTo(ApplyPriceToType value) {
            this.appliesTo = value;
        }

        /**
         * Gets the value of the landProductInfo property.
         * 
         * @return
         *     possible object is
         *     {@link AirLandProductType }
         *     
         */
        public AirLandProductType getLandProductInfo() {
            return landProductInfo;
        }

        /**
         * Sets the value of the landProductInfo property.
         * 
         * @param value
         *     allowed object is
         *     {@link AirLandProductType }
         *     
         */
        public void setLandProductInfo(AirLandProductType value) {
            this.landProductInfo = value;
        }

        /**
         * Gets the value of the insuranceProduct property.
         * 
         * @return
         *     possible object is
         *     {@link AirInsuranceOfferType }
         *     
         */
        public AirInsuranceOfferType getInsuranceProduct() {
            return insuranceProduct;
        }

        /**
         * Sets the value of the insuranceProduct property.
         * 
         * @param value
         *     allowed object is
         *     {@link AirInsuranceOfferType }
         *     
         */
        public void setInsuranceProduct(AirInsuranceOfferType value) {
            this.insuranceProduct = value;
        }

    }

}
