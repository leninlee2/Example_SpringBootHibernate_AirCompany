
package com.flyairnorth.integration.org.opentravel.ota._2003._05;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for List_OfferTripPurpose.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="List_OfferTripPurpose">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="BereavmentOrEmergency"/>
 *     &lt;enumeration value="Business"/>
 *     &lt;enumeration value="BusinessAndPersonal"/>
 *     &lt;enumeration value="CharterOrGroup"/>
 *     &lt;enumeration value="ConferenceOrEvent"/>
 *     &lt;enumeration value="Personal"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "List_OfferTripPurpose")
@XmlEnum
public enum ListOfferTripPurpose {

    @XmlEnumValue("BereavmentOrEmergency")
    BEREAVMENT_OR_EMERGENCY("BereavmentOrEmergency"),
    @XmlEnumValue("Business")
    BUSINESS("Business"),
    @XmlEnumValue("BusinessAndPersonal")
    BUSINESS_AND_PERSONAL("BusinessAndPersonal"),
    @XmlEnumValue("CharterOrGroup")
    CHARTER_OR_GROUP("CharterOrGroup"),
    @XmlEnumValue("ConferenceOrEvent")
    CONFERENCE_OR_EVENT("ConferenceOrEvent"),
    @XmlEnumValue("Personal")
    PERSONAL("Personal");
    private final String value;

    ListOfferTripPurpose(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ListOfferTripPurpose fromValue(String v) {
        for (ListOfferTripPurpose c: ListOfferTripPurpose.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
