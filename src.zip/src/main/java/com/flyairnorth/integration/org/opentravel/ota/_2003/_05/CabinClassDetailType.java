
package com.flyairnorth.integration.org.opentravel.ota._2003._05;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlMixed;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * Detail information about a cabin class, including row characteristics, zone and seat details.
 * 
 * <p>Java class for CabinClassDetailType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CabinClassDetailType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AvailabilityList" type="{http://www.opentravel.org/OTA/2003/05}CabinClassAvailabilityType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="RowInfo" type="{http://www.opentravel.org/OTA/2003/05}RowDetailType" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="SeatInfo" type="{http://www.opentravel.org/OTA/2003/05}SeatDetailsType" minOccurs="0"/>
 *         &lt;element name="Zone" type="{http://www.opentravel.org/OTA/2003/05}SeatZoneSummaryType" maxOccurs="99" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Layout" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="UpperDeckInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="ColumnNumber" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *       &lt;attribute name="ColumnSpan" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CabinClassDetailType", propOrder = {
    "content"
})
@XmlSeeAlso({
    com.flyairnorth.integration.org.opentravel.ota._2003._05.SeatMapDetailsType.CabinClass.class
})
public class CabinClassDetailType {

    @XmlElementRefs({
        @XmlElementRef(name = "RowInfo", namespace = "http://www.opentravel.org/OTA/2003/05", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SeatInfo", namespace = "http://www.opentravel.org/OTA/2003/05", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "Zone", namespace = "http://www.opentravel.org/OTA/2003/05", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "AvailabilityList", namespace = "http://www.opentravel.org/OTA/2003/05", type = JAXBElement.class, required = false)
    })
    @XmlMixed
    protected List<Serializable> content;
    @XmlAttribute(name = "Layout")
    protected String layout;
    @XmlAttribute(name = "UpperDeckInd")
    protected Boolean upperDeckInd;
    @XmlAttribute(name = "ColumnNumber")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger columnNumber;
    @XmlAttribute(name = "ColumnSpan")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger columnSpan;

    /**
     * Detail information about a cabin class, including row characteristics, zone and seat details.Gets the value of the content property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the content property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContent().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link SeatDetailsType }{@code >}
     * {@link JAXBElement }{@code <}{@link SeatZoneSummaryType }{@code >}
     * {@link String }
     * {@link JAXBElement }{@code <}{@link RowDetailType }{@code >}
     * {@link JAXBElement }{@code <}{@link CabinClassAvailabilityType }{@code >}
     * 
     * 
     */
    public List<Serializable> getContent() {
        if (content == null) {
            content = new ArrayList<Serializable>();
        }
        return this.content;
    }

    /**
     * Gets the value of the layout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLayout() {
        return layout;
    }

    /**
     * Sets the value of the layout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLayout(String value) {
        this.layout = value;
    }

    /**
     * Gets the value of the upperDeckInd property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isUpperDeckInd() {
        return upperDeckInd;
    }

    /**
     * Sets the value of the upperDeckInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setUpperDeckInd(Boolean value) {
        this.upperDeckInd = value;
    }

    /**
     * Gets the value of the columnNumber property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getColumnNumber() {
        return columnNumber;
    }

    /**
     * Sets the value of the columnNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setColumnNumber(BigInteger value) {
        this.columnNumber = value;
    }

    /**
     * Gets the value of the columnSpan property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getColumnSpan() {
        return columnSpan;
    }

    /**
     * Sets the value of the columnSpan property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setColumnSpan(BigInteger value) {
        this.columnSpan = value;
    }

}
