package com.flyairnorth.integration.constants;

public class TicketLogActionOptions {
	public static final String TICKET_ISSUED = "TICKET_ISSUED";
	public static final String PAID = "PAID";
	public static final String DELAYED_PAYMENT = "DELAYED PAYMENT";
	public static final String UPDATE_TICKET = "UPDATE TICKET";
}
