package com.flyairnorth.integration.constants;

public interface MyIDFaresTypes {
	static final String ZED = "ZED";
	static final String ZED_HIGH = "High";
	static final String ZH = "ZH";
	static final String ZM = "ZM";
	static final String ZED_MED = "Med";
	static final String ZED_LOW = "Low";
	static final String ZL = "ZL";
}
