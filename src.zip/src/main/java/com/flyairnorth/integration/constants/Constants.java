package com.flyairnorth.integration.constants;

public interface Constants {

	static float GSTRATE = 0.05f;
	static String GST_DESCRIPTION = "Canada Goods and Service Tax #850279555 ";
	static String OPTIMUM = "OPTIMUM";
	static String SAVER = "SAVER";
	static String GOYUKON = "GOYUKON";
	static String MYOB = "MYOB";
	static String FEATURE_FLAG_SSM_MSGS = "FEAT_FLAG_SSM_MSGS";
	static String FEATURE_FLAG_WEB_SVCS = "FEAT_FLAG_WEB_SVCS";
	static String FEATURE_FLAG_WEB_SVCS_MYID = "FEAT_FLAG_WEB_SVCS_MYID";
	static String FEATURE_FLAG_AVS_MSGS = "FEAT_FLAG_AVS_MSGS";
	static String FEATURE_FLAG_CANCEL_WEB_SVCS = "FEATURE_FLAG_CANCEL_WEB_SVCS";
	static String CAD_CURRENCY = "CAD";
	static String NOT_4N_PRIORITY = "S5";
	static final String PAYMENT_METHOD_NOT_FOUND_MSG = "No valid payment method inserted. Valid options are: 'SABRE' (Sabre Payment through BSP), 'TRAVELPORT' (Sabre Payment through BSP), "
			+ "'AMADEUS' (Amadeus), VARVISA, VARMC,  VARAMEX and VIDECOM";
	static final String AIRNORTH = "4N";
	static final String MY_ID_USD_TO_CAD_RATE = "MYIDEXCHANGERATE";
	static final String MY_ID_INFANT_FARE_DISCOUNT = "MYIDINFANTFAREDISCOUNT";
	static final String MAIL_TO_DUPPLICATED_BOOKINGS = "MAILTODUPPLICATEDBOOKINGS";
	static final String INTEGRATION_USERNAME = "INTEGRATION";
	static final String TLOG_DATE_PATTERN = "MM/dd/yy";
	static final String NULL = "NULL";
	static final String RLOC = "rloc";
	static final String TNUMCNTR = "tnumcntr";
	static final String TNUM = "tnum";
	static final String INUM = "inum";
	static final String DELAYED = "DELAYED";
	
	static final String UNDEFINED = "UNDEFINED";

	static final String N_A = "N/A";

	static final String MODIFY_USERNAME = "MODIFY_SERVICE"; 

	static final int ORDER_ID_LIMIT = 34;

	static final String ORDER_ID_PREFIX = "INUM";

    static final float YOWHSTRATE = 0.13f; 
    static final String HST_DESCRIPTION = "Harmonized Sales Tax #850279555";
    static final String OTTAWA = "YOW";
}
