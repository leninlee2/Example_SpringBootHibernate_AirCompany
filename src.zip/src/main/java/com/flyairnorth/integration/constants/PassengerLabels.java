package com.flyairnorth.integration.constants;

public interface PassengerLabels {
	String LABEL_INFANT = "I";
	String ADULT_MALE = "M";
	String ADULT_FEMALE = "F";
	String BOY = "B";
	String GIRL = "G";
	String YOUTH_MALE = "YP-M";
	String YOUTH_FEMALE = "YP-F";
}
