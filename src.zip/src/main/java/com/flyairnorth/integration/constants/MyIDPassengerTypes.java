package com.flyairnorth.integration.constants;

public interface MyIDPassengerTypes {
	static final String EMPLOYEE_MYID = "ZEA";
	static final String EMPLOYEE_ETARS = "EM";
	static final String MARRIAGE_MYID = "ZSP";
	static final String PARTNER_OPPOSITE_MYID = "ZSO";
	static final String PARTNER_SAME_MYID = "ZSS";
	static final String MARRIAGE_ETARS = "SD";
	static final String CHILD_2_11_MYID = "ZEC";
	static final String CHILD_12_21_MYID = "ZEA";
	static final String CHILD_22_24_MYID = "ZEA";
	static final String CHILD_21_ETARS = "D21";
	static final String CHILD_24_ETARS = "D24";
	static final String INFANT_MYID = "ZEI";
	static final String INFANT_ETARS = "D21";
	static final String FATHER_MYID = "ZEP";
	static final String FATHER_ETARS = "PF";
	static final String MOTHER_MYID = "ZEP";
	static final String MOTHER_ETARS = "PM";
	static final String DESIGNATE_MYID = "ZPA";
	static final String DESIGNATE_ETARS = "DI";
	static final String IN_LAW_MYID = "ZPL";
	static final String IN_LAW_ETARS = "PL";
	static final String GRANDPARENTS_MYID = "ZEF";
	static final String GRANDPARENTS_ETARS = "GP";
	static final String SIBLING_MYID = "ZMA";
	static final String SIBLING_ETARS = "SB";
}
