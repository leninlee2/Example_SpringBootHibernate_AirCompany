package com.flyairnorth.integration.constants;

public class TranTypeOptions {
	public final static int REFUNDED = 2;
	public final static int SPACE_AVAILABLE = 3;
	public final static int CANCELLED = 5;
	public final static int CANCELLED_REBOOKED = 6;
	public final static int CONFIRMED = 7;
	public final static int CHECKED_IN = 8;
	public final static int BOARDED = 9;
	public final static int WAIT_LISTED = 10;
	public final static int NO_SHOWED = 11;
	public final static int STAND_BY = 12;
	public final static int FIM = 13;
	public final static int DELETE = 14;
	public final static int NON_REVENUE_STAND_BY = 15;
	public final static int NON_REVENUE_DELAYED = 16;
	public final static int NON_REVENUE_CONFIRM_DELAYED = 17;
	public final static int MYID_CANCELED_REBOOKED = 18;
	public final static int DELAYED_PAID = 19;
}
