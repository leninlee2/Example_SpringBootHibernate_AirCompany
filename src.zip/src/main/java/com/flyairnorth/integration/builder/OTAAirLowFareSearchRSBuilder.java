package com.flyairnorth.integration.builder;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.XMLGregorianCalendar;

import com.flyairnorth.integration.dto.search.ConnectionDTO;
import com.flyairnorth.integration.dto.search.FareDTO;
import com.flyairnorth.integration.dto.search.FlightDTO;
import com.flyairnorth.integration.dto.search.PassengerDTO;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.AirItineraryPricingInfoType.FareInfos;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.AirItineraryPricingInfoType.FareInfos.FareInfo;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.AirItineraryPricingInfoType.ItinTotalFare;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.AirItineraryPricingInfoType.PTCFareBreakdowns;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.AirItineraryType;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.AirItineraryType.OriginDestinationOptions;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.AirItineraryType.OriginDestinationOptions.OriginDestinationOption;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.AirTaxType;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.FareBasisCodeType;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.FareInfoType.FareReference;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.FareType.BaseFare;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.FareType.Taxes;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.FareType.TotalFare;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.FlightSegmentBaseType.ArrivalAirport;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.FlightSegmentBaseType.DepartureAirport;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.LocationType;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.OTAAirLowFareSearchRS;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.ObjectFactory;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.OriginDestinationOptionType.FlightSegment;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.PTCFareBreakdownType;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.PTCFareBreakdownType.FareBasisCodes;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.PTCFareBreakdownType.PassengerFare;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.PassengerTypeQuantityType;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.PricedItinerariesType;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.PricedItinerariesType.PricedItinerary;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.PricedItineraryType.AirItineraryPricingInfo;
import com.flyairnorth.integration.util.CalendarUtils;

public class OTAAirLowFareSearchRSBuilder {
	
	private OTAAirLowFareSearchRS response;

	private ObjectFactory objectFactory; 
	
	public OTAAirLowFareSearchRSBuilder() {
		this.objectFactory = new ObjectFactory();
		this.response = objectFactory.createOTAAirLowFareSearchRS();
	}

	public OTAAirLowFareSearchRSBuilder withSucess() {
		response.setSuccess(objectFactory.createSuccessType());
		return this;
	}

	public void withFlightDTO(FlightDTO flightDTO) {
		List<PricedItinerary> itineraries = this.getPricedItineraries();

		flightDTO.getFares().forEach(fareDTO -> {
			PricedItinerary pricedItinerary = objectFactory.createPricedItinerariesTypePricedItinerary();
			pricedItinerary.setSequenceNumber(BigInteger.valueOf(itineraries.size()+1));

			pricedItinerary.setAirItineraryPricingInfo(getAirItineraryPricingInfo(fareDTO));
			pricedItinerary.setAirItinerary(getAirItinerary(fareDTO, flightDTO));

			itineraries.add(pricedItinerary);
		});
	}

	public void withConnectionDTO(ConnectionDTO connectionDTO) {
		List<PricedItinerary> itineraries = this.getPricedItineraries();

		connectionDTO.getFares().forEach(fareDTO -> {
			FlightDTO firstLeg = connectionDTO.getFirstLeg();
			FlightDTO secondLeg = connectionDTO.getSecondLeg();

			PricedItinerary pricedItinerary = objectFactory.createPricedItinerariesTypePricedItinerary();
			pricedItinerary.setSequenceNumber(BigInteger.valueOf(itineraries.size()+1));

			pricedItinerary.setAirItineraryPricingInfo(getAirItineraryPricingInfo(fareDTO));
			pricedItinerary.setAirItinerary(getAirItinerary(fareDTO, firstLeg, secondLeg));

			itineraries.add(pricedItinerary);
		});
	}
	
	private AirItineraryType getAirItinerary(FareDTO fareDTO, FlightDTO... flightsDTO) {

		AirItineraryType airItinerary = objectFactory.createAirItineraryType();
		OriginDestinationOptions originDestinationOptions = objectFactory.createAirItineraryTypeOriginDestinationOptions();
		OriginDestinationOption originDestinationOption = objectFactory.createAirItineraryTypeOriginDestinationOptionsOriginDestinationOption();

		List<FlightDTO> flightsList = Arrays.asList(flightsDTO);
		flightsList.forEach(flightDTO -> {
			DepartureAirport departureAirport = objectFactory.createFlightSegmentBaseTypeDepartureAirport();
			departureAirport.setLocationCode(flightDTO.getOrigin());

			ArrivalAirport arrivalAirport = objectFactory.createFlightSegmentBaseTypeArrivalAirport();
			arrivalAirport.setLocationCode(flightDTO.getDestination());

			FlightSegment segment = objectFactory.createOriginDestinationOptionTypeFlightSegment();

			XMLGregorianCalendar xmlDepartureDateTime;
			XMLGregorianCalendar xmlArrivalDateTime;
			try {
				xmlDepartureDateTime = CalendarUtils.convertToXMLGregorianCalendar(flightDTO.getDepartureDateTime());
				xmlArrivalDateTime = CalendarUtils.convertToXMLGregorianCalendar(flightDTO.getArrivalDateTime());
			} catch (DatatypeConfigurationException e) {
				throw new IllegalArgumentException("Error while parsing DepartureDateTime to XML. "+e.getMessage(), e);
			}

			segment.setDepartureAirport(departureAirport);
			segment.setArrivalAirport(arrivalAirport);
			segment.setFlightNumber(flightDTO.getFlightNumber());
			segment.setDepartureDateTime(xmlDepartureDateTime);
			segment.setArrivalDateTime(xmlArrivalDateTime);
			originDestinationOption.getFlightSegment().add(segment);
		});

		originDestinationOptions.getOriginDestinationOption().add(originDestinationOption);
		airItinerary.setOriginDestinationOptions(originDestinationOptions);

		return airItinerary;
	}

	private AirItineraryPricingInfo getAirItineraryPricingInfo(FareDTO fareDTO) {
		AirItineraryPricingInfo airItineraryPricingInfo = objectFactory.createPricedItineraryTypeAirItineraryPricingInfo();
		airItineraryPricingInfo.getItinTotalFare().add(getItinTotalFare(fareDTO));
		airItineraryPricingInfo.setFareInfos(getFareInfos(fareDTO));

		airItineraryPricingInfo.setPTCFareBreakdowns(getPTCFareBreakdowns(fareDTO));

		return airItineraryPricingInfo;
	}

	private PTCFareBreakdowns getPTCFareBreakdowns(FareDTO fareDTO) {
		PTCFareBreakdowns ptcFaresBreakdowns = objectFactory.createAirItineraryPricingInfoTypePTCFareBreakdowns();
		List<PTCFareBreakdownType> ptcFareBreakdownList = ptcFaresBreakdowns.getPTCFareBreakdown();

		PTCFareBreakdownType ptcFareBreakDown = objectFactory.createPTCFareBreakdownType();
		PassengerTypeQuantityType passengerTypeQuantity = objectFactory.createPassengerTypeQuantityType();

		PassengerDTO passengerDTO = fareDTO.getPassengerDTO();
		passengerTypeQuantity.setCode(passengerDTO.getType().toString());
		passengerTypeQuantity.setQuantity(BigInteger.valueOf(passengerDTO.getQuantity()));

		ptcFareBreakDown.setPassengerTypeQuantity(passengerTypeQuantity);

		FareBasisCodes fareBasisCodes = objectFactory.createPTCFareBreakdownTypeFareBasisCodes();
		FareBasisCodeType fareBase = objectFactory.createFareBasisCodeType();

		fareBase.setValue(fareDTO.getCode());
		fareBasisCodes.getFareBasisCode().add(fareBase);

		ptcFareBreakDown.setFareBasisCodes(fareBasisCodes);

		PassengerFare passengerFare = objectFactory.createPTCFareBreakdownTypePassengerFare();
		BaseFare baseFare = objectFactory.createFareTypeBaseFare();

		baseFare.setAmount(fareDTO.getFareValue());
		baseFare.setCurrencyCode(fareDTO.getCurrencyIsocode());
		passengerFare.setBaseFare(baseFare);

		Taxes taxes = objectFactory.createFareTypeTaxes();
		List<AirTaxType> taxList = taxes.getTax();
		fareDTO.getCharges().forEach(charge -> {
			AirTaxType airTax = objectFactory.createAirTaxType();
			airTax.setAmount(BigDecimal.valueOf(charge.getAmount()));
			airTax.setCurrencyCode(charge.getCurrencyIsocode());
			airTax.setTaxCode(charge.getDescription());
			taxList.add(airTax);
		});
		double chargesSum = fareDTO.getCharges().stream().mapToDouble(charge -> charge.getAmount()).sum();
		taxes.setAmount(BigDecimal.valueOf(chargesSum).setScale(2, RoundingMode.HALF_UP));

		passengerFare.setTaxes(taxes);

		TotalFare totalFare = objectFactory.createFareTypeTotalFare();
		totalFare.setCurrencyCode(fareDTO.getCurrencyIsocode());
		totalFare.setAmount(fareDTO.getFareAndChargesSum());
		passengerFare.setTotalFare(totalFare);

		ptcFareBreakDown.getPassengerFare().add(passengerFare);

		ptcFareBreakdownList.add(ptcFareBreakDown);

		return ptcFaresBreakdowns;
	}

	private List<PricedItinerary> getPricedItineraries() {
		PricedItinerariesType pricedItineraries = response.getPricedItineraries();
		if (pricedItineraries == null) {
			pricedItineraries = objectFactory.createPricedItinerariesType();
			response.setPricedItineraries(pricedItineraries);
		}
		return pricedItineraries.getPricedItinerary();
	}

	private FareInfos getFareInfos(FareDTO fareDTO) {
		FareInfos fareInfos = objectFactory.createAirItineraryPricingInfoTypeFareInfos();
		FareInfo fareInfo = objectFactory.createAirItineraryPricingInfoTypeFareInfosFareInfo();

		fareInfo.setCurrencyCode(fareDTO.getCurrencyIsocode());
		
		FareReference reference = objectFactory.createFareInfoTypeFareReference();
		reference.setValue(fareDTO.getFareClass());
		reference.setResBookDesigCode(fareDTO.getCode());
		reference.setTicketDesignatorCode(fareDTO.getMyIDBookingStatus());
		
		fareInfo.getFareReference().add(reference);
		
		LocationType origin = objectFactory.createLocationType();
		origin.setValue(fareDTO.getOrigin());
		LocationType destination = objectFactory.createLocationType();
		destination.setValue(fareDTO.getDestination());

		fareInfo.setDepartureAirport(origin);
		fareInfo.setArrivalAirport(destination);

		fareInfos.getFareInfo().add(fareInfo);
		return fareInfos;
	}

	private ItinTotalFare getItinTotalFare(FareDTO fareDTO) {
		ItinTotalFare itinTotalFare = objectFactory.createAirItineraryPricingInfoTypeItinTotalFare();
		itinTotalFare.setBaseFare(getBaseFare(fareDTO));
		itinTotalFare.setTaxes(getTaxes(fareDTO));

		TotalFare totalFare = objectFactory.createFareTypeTotalFare();
		totalFare.setAmount(fareDTO.getFareAndChargesSum());
		itinTotalFare.setTotalFare(totalFare);

		return itinTotalFare;
	}

	private Taxes getTaxes(FareDTO fareDTO) {
		Taxes taxes = objectFactory.createFareTypeTaxes();
		fareDTO.getCharges().forEach(charge ->{
			AirTaxType airTax = objectFactory.createAirTaxType();
			airTax.setTaxName(charge.getDescription());
			airTax.setAmount(BigDecimal.valueOf(charge.getAmount()));
			airTax.setCurrencyCode(charge.getCurrencyIsocode());
			taxes.getTax().add(airTax);
		});
		return taxes;
	}

	private BaseFare getBaseFare(FareDTO fareDTO) {
		BaseFare baseFare = objectFactory.createFareTypeBaseFare();
		baseFare.setAmount(fareDTO.getFareValue());
		baseFare.setCurrencyCode(fareDTO.getCurrencyIsocode());
		return baseFare;
	}

	public OTAAirLowFareSearchRS build() {
		return response;
	}
}
