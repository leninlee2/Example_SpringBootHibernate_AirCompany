package com.flyairnorth.integration.builder;

import com.flyairnorth.integration.entity.TLog;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.ObjectFactory;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.TravelerInfoType;

public class TravelerInfoBuilder {
	private TravelerInfoType travelerInfo;
	private ObjectFactory objectFactory;

	public TravelerInfoBuilder() {
		objectFactory = new ObjectFactory();
		this.travelerInfo = objectFactory.createTravelerInfoType();
	}

	public TravelerInfoBuilder withTLog(TLog tlog) {
		TravelerInfoType.AirTraveler airTraveler = new AirTravelerBuilder().withTLog(tlog).build(); 
		travelerInfo.getAirTraveler().add(airTraveler);

		return this;
	}

	public TravelerInfoType build() {
		return this.travelerInfo;
	}
}
