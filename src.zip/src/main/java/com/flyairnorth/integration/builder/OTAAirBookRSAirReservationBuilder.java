package com.flyairnorth.integration.builder;

import com.flyairnorth.integration.entity.TLog;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.OTAAirBookRS;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.ObjectFactory;

public class OTAAirBookRSAirReservationBuilder {

	private ObjectFactory objectFactory;
	private OTAAirBookRS.AirReservation response;

	public OTAAirBookRSAirReservationBuilder() {
		this.objectFactory = new ObjectFactory();
		this.response = objectFactory.createOTAAirBookRSAirReservation();
	}

	public OTAAirBookRSAirReservationBuilder withTLog(TLog tlog) {
		response.setTravelerInfo(new TravelerInfoBuilder().withTLog(tlog).build());
		response.setAirItinerary(new AirItineraryBuilder().withTLog(tlog).build());
		response.getBookingReferenceID().addAll(new BookingReferenceIDBuilder().withTLog(tlog).build());
		response.setFulfillment(new FulfillmentTypeBuilder().withTLog(tlog).build());
		return this;
	}

	public OTAAirBookRS.AirReservation build(){
		return this.response;
	}
}
