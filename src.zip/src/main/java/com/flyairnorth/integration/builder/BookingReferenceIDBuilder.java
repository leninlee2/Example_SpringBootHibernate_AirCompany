package com.flyairnorth.integration.builder;

import java.util.ArrayList;
import java.util.List;

import com.flyairnorth.integration.entity.TLog;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.AirReservationType.BookingReferenceID;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.ObjectFactory;

public class BookingReferenceIDBuilder {

	private ObjectFactory objectFactory;
	private List<BookingReferenceID> bookingReferenceIDList;

	public BookingReferenceIDBuilder() {
		this.objectFactory = new ObjectFactory();
		this.bookingReferenceIDList = new ArrayList<>();
	}

	public BookingReferenceIDBuilder withTLog(TLog tlog) {
		bookingReferenceIDList.add(getBookingReferenceID("rloc", tlog.getPnr()));
		bookingReferenceIDList.add(getBookingReferenceID("inum", tlog.getiNum()));
		bookingReferenceIDList.add(getBookingReferenceID("tnum", tlog.gettNum()));
//		bookingReferenceIDList.add(getBookingReferenceID("tnumcntr", tlog.gettNumCntr().toString()));

		return this;
	}

	private BookingReferenceID getBookingReferenceID(String type, String id) {
		BookingReferenceID bookingReferenceID = objectFactory.createBookingReferenceID();
		bookingReferenceID.setType(type);
		bookingReferenceID.setID(id);
		return bookingReferenceID;
	}
	public List<BookingReferenceID> build() {
		return this.bookingReferenceIDList;
	}
}
