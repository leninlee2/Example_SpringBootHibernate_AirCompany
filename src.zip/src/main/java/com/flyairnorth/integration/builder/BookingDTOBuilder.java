package com.flyairnorth.integration.builder;

import java.time.LocalDateTime;

import javax.xml.datatype.XMLGregorianCalendar;

import com.flyairnorth.integration.dto.booking.BookingDTO;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.FlightSegmentBaseType.ArrivalAirport;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.FlightSegmentBaseType.DepartureAirport;
import com.flyairnorth.integration.util.CalendarUtils;

public class BookingDTOBuilder {

	private BookingDTO bookingDTO;

	public BookingDTOBuilder() {
		this.bookingDTO = new BookingDTO();
	}

	public BookingDTOBuilder withFareClass(String fareClass) {
		this.bookingDTO.setFareClass(fareClass);
		return this;
	}

	public BookingDTOBuilder withFlightNumber(String flightNumber) {
		this.bookingDTO.setFlightNumber(flightNumber);
		return this;
	}

	public BookingDTOBuilder withDepartureAirport(DepartureAirport departureAirport) {
		this.bookingDTO.setOrigin(departureAirport.getLocationCode());
		return this;
	}

	public BookingDTOBuilder withArrivalAirport(ArrivalAirport arrivalAirport) {
		this.bookingDTO.setDestination(arrivalAirport.getLocationCode());
		return this;
	}

	public BookingDTOBuilder withDepartureDateTime(XMLGregorianCalendar departureDateTime) {
		LocalDateTime localDateTime = CalendarUtils.convertToLocalDateTime(departureDateTime);

		this.bookingDTO.setDepartureDateTime(localDateTime);
	
		return this;
	}

	public BookingDTOBuilder withFareCode(String fareCode) {
		this.bookingDTO.setFareCode(fareCode);
		return this;
	}

	public BookingDTO build() {
		return this.bookingDTO;
	}

	public BookingDTOBuilder withRefNumber(String refNumber) {
		this.bookingDTO.setSegmentReferenceNumber(refNumber);
		return this;
	}
}