package com.flyairnorth.integration.builder;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.flyairnorth.integration.constants.TranTypeOptions;
import com.flyairnorth.integration.entity.TLog;
import com.flyairnorth.integration.entity.TicketAttribute;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.FlightSegmentBaseType.ArrivalAirport;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.FlightSegmentBaseType.DepartureAirport;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.FlightSegmentType;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.OTAResRetrieveRS.ReservationsList.AirReservation;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.ObjectFactory;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.PersonNameType;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.TPAExtensionsType;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.TransactionStatusType;
import com.flyairnorth.integration.util.CalendarUtils;

public class ResRetrieveRSAirReservationBuilder {
	
	private static final String TNUMCNTR = "tnumcntr";
	private static final String INUM = "inum";
	private static final String TNUM = "tnum";
	private static final String IATA_NUMBER = "iataNumber";
	private static final String TICKET_NUMBER = "ticketNumber";
	private ObjectFactory objectFactory;
	private AirReservation response;
	private static Logger LOGGER = LoggerFactory.getLogger(ResRetrieveRSAirReservationBuilder.class);
	
	public ResRetrieveRSAirReservationBuilder() {
		this.objectFactory = new ObjectFactory();
		this.response = objectFactory.createOTAResRetrieveRSReservationsListAirReservation();
	}

	public ResRetrieveRSAirReservationBuilder withTLog(TLog tlog) {
		response.setBookingReferenceID(tlog.getPnr());
		response.setDateBooked(getXMLGregorianCalendarFromString(tlog.getDateTime()));
		response.setFlightSegment(getFlightSegment(tlog));
		response.getTravelerName().add(getPersonName(tlog));
		response.setStatus(getTransactionStatusType(tlog));

		return this;
	}

	private TransactionStatusType getTransactionStatusType(TLog tlog) {
		Integer tranType = tlog.getTranType();

		switch (tranType) {
		case TranTypeOptions.CONFIRMED:
			return TransactionStatusType.RESERVED;
		case TranTypeOptions.CANCELLED:
			return TransactionStatusType.CANCELLED;
		case TranTypeOptions.SPACE_AVAILABLE:
			return TransactionStatusType.PENDING;
		default:
			return TransactionStatusType.CANCELLED;
		}
	}

	private PersonNameType getPersonName(TLog tlog) {
		PersonNameType personName = objectFactory.createPersonNameType();
		personName.getGivenName().add(tlog.getFirst());
		personName.getMiddleName().add(tlog.getMiddle());
		personName.setSurname(tlog.getLast());

		return personName;
	}

	private TPAExtensionsType createTPAExtensions(TLog tlog, List<TicketAttribute> etickets) throws ParserConfigurationException {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = dbf.newDocumentBuilder();
        Document doc = builder.newDocument();
        Element root = doc.createElement("ReservationProperties");
        doc.appendChild(root);

        root.setAttribute(INUM, tlog.getiNum());
        root.setAttribute(TNUM, tlog.gettNum());
        root.setAttribute(TNUMCNTR, tlog.getTnumCntr().toString());
        if (!StringUtils.isEmpty(tlog.getIataNum())) {
        	root.setAttribute(IATA_NUMBER, tlog.getIataNum());
        }

        etickets = etickets.stream().filter(ticket -> {
        	return ticket.getInum().equals(tlog.getiNum()) && ticket.getTnum().equals(tlog.gettNum()) && ticket.gettNumCntr().equals(tlog.getTnumCntr());
        }).collect(Collectors.toList());

        if (!CollectionUtils.isEmpty(etickets)) {
        	TicketAttribute ticketAttribute = etickets.get(0);
        	root.setAttribute(TICKET_NUMBER, ticketAttribute.getAttributeValue());
        }

        TPAExtensionsType tpa = objectFactory.createTPAExtensionsType();
        tpa.getAny().add(root);

        return tpa;
	}

	private FlightSegmentType getFlightSegment(TLog tlog) {
		FlightSegmentType flightSegment = objectFactory.createFlightSegmentType();
		flightSegment.setArrivalAirport(getArrivalAirport(tlog));
		flightSegment.setDepartureAirport(getDepartureAirport(tlog));
		try {
			flightSegment.setDepartureDateTime(CalendarUtils.convertToXMLGregorianCalendar(tlog.getDepartureDateTime()));
			flightSegment.setArrivalDateTime(CalendarUtils.convertToXMLGregorianCalendar(tlog.getArrivalDateTime()));
		} catch (DatatypeConfigurationException e) {
			LOGGER.error("Error parsing Departure and/or Arrival dates to XMLGregorianCalendar: ", e);
		}
		flightSegment.setFlightNumber(tlog.getfFlight());
		flightSegment.setFareBasisCode(tlog.getFareCode());
		
		return flightSegment;
	}

	private DepartureAirport getDepartureAirport(TLog tlog) {
		DepartureAirport departureAirport = objectFactory.createFlightSegmentBaseTypeDepartureAirport();
		departureAirport.setLocationCode(tlog.getFromCode());
		return departureAirport;
	}

	private ArrivalAirport getArrivalAirport(TLog tlog) {
		ArrivalAirport arrivalAirport = objectFactory.createFlightSegmentBaseTypeArrivalAirport();
		arrivalAirport.setLocationCode(tlog.getToCode());
		return arrivalAirport;
	}

	private XMLGregorianCalendar getXMLGregorianCalendarFromString(String resDate) {
		XMLGregorianCalendar xmlDate;
		DateTimeFormatter localDateTimeFormatter = DateTimeFormatter.ofPattern("MM/dd/yy hh:mm a");
		LocalDateTime parseResDate = LocalDateTime.parse(resDate, localDateTimeFormatter);

		try {
			xmlDate = CalendarUtils.convertToXMLGregorianCalendar(parseResDate);
		} catch (DatatypeConfigurationException e) {
			xmlDate = null;
		}

		return xmlDate;
	}

	public AirReservation build() {
		return response;
	}

	public ResRetrieveRSAirReservationBuilder withTLogAndETickets(TLog tlog, List<TicketAttribute> ticketAttributes) {
		this.withTLog(tlog);
		try {
			response.setTPAExtensions(createTPAExtensions(tlog, ticketAttributes));
		} catch (ParserConfigurationException e) {
			LOGGER.error("Error building TPA_Extensions tag: ", e);
		}
		return this;
	}
}
