package com.flyairnorth.integration.builder;

import org.apache.commons.lang3.StringUtils;

import com.flyairnorth.integration.entity.TLog;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.FulfillmentType;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.FulfillmentType.PaymentDetails;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.FulfillmentType.PaymentDetails.PaymentDetail;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.ObjectFactory;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.PaymentFormType.Ticket;

public class FulfillmentTypeBuilder {

	private ObjectFactory objectFactory;
	private FulfillmentType fulfillment;

	public FulfillmentTypeBuilder() {
		this.objectFactory = new ObjectFactory();
		this.fulfillment = objectFactory.createFulfillmentType();
	}

	public FulfillmentTypeBuilder withTLog(TLog tlog) {
		if (!StringUtils.isEmpty(tlog.getIataNum())) {
			PaymentDetails paymentDetails = objectFactory.createFulfillmentTypePaymentDetails();
			PaymentDetail paymentDetail = objectFactory.createFulfillmentTypePaymentDetailsPaymentDetail();
			Ticket ticket = objectFactory.createPaymentFormTypeTicket();
			ticket.setOriginalIssueIATA(tlog.getIataNum());

			paymentDetail.setTicket(ticket);
			paymentDetails.getPaymentDetail().add(paymentDetail);
			fulfillment.setPaymentDetails(paymentDetails);
		}
		return this;
	}

	public FulfillmentType build() {
		return this.fulfillment;
	}

}
