package com.flyairnorth.integration.builder;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.flyairnorth.integration.dto.booking.AddressDTO;
import com.flyairnorth.integration.dto.booking.BookingPassengerDTO;
import com.flyairnorth.integration.dto.booking.MyIDDTO;
import com.flyairnorth.integration.dto.booking.TelephoneDTO;
import com.flyairnorth.integration.enumerator.AgeQualifyingCode;
import com.flyairnorth.integration.enumerator.GenderOptions;
import com.flyairnorth.integration.enumerator.VidecomContactType;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.AirTravelerType.Address;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.AirTravelerType.Email;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.AirTravelerType.Telephone;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.AirTravelerType.TravelerRefNumber;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.MyIDType;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.PassengerTypeQuantityType;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.PersonNameType;

public class BookingPassengerDTOBuilder {

	private BookingPassengerDTO passenger;

	public BookingPassengerDTOBuilder() {
		this.passenger = new BookingPassengerDTO();
	}

	public BookingPassengerDTOBuilder withPersonName(PersonNameType personName) {
		passenger.setFirstName(personName.getGivenName().stream().collect(Collectors.joining(" ")));
		passenger.setMiddleName(personName.getMiddleName().stream().collect(Collectors.joining(" ")));
		passenger.setLastName(personName.getSurname());
		return this;
	}

	public BookingPassengerDTOBuilder withEmails(List<Email> email) {
		if (passenger.getEmails() == null) {
			passenger.setEmails(new ArrayList<>());
		}
		passenger.getEmails().addAll(email.stream().map(Email::getValue).collect(Collectors.toList()));

		return this;
	}

	public BookingPassengerDTOBuilder withAddresses(List<Address> address) {
		if (passenger.getAddresses() == null) {
			passenger.setAddresses(new ArrayList<>());
		}
		List<AddressDTO> addresses = passenger.getAddresses();

		address.forEach(a -> {
			AddressDTO addressDTO = new AddressDTO();
			addressDTO.setAddressLines(a.getAddressLine());
			addressDTO.setCityName(a.getCityName());

			if (a.getCountryName() != null) {
				addressDTO.setCountry(a.getCountryName().getCode());
			}

			addressDTO.setPostalCode(a.getPostalCode());
			if (a.getStateProv() != null) {
				addressDTO.setState(a.getStateProv().getStateCode());
			}

			if (a.getStreetNmbr() != null) {
				addressDTO.getAddressLines().add(a.getStreetNmbr().getValue());
			}

			addresses.add(addressDTO);
		});
		return this;
	}

	public BookingPassengerDTOBuilder withTelephones(List<Telephone> telephones) {
		if (passenger.getTelephones() == null) {
			passenger.setTelephones(new ArrayList<>());
		}

		List<TelephoneDTO> passengerTels = passenger.getTelephones();

		telephones.forEach(telephone -> {
			if (!StringUtils.isEmpty(telephone.getPhoneNumber())) {
				TelephoneDTO telephoneDTO = new TelephoneDTO();
				telephoneDTO.setPhoneNumber(telephone.getPhoneNumber());
				telephoneDTO.setType(VidecomContactType.fromString(telephone.getPhoneUseType()));
	
				passengerTels.add(telephoneDTO);
			}
		});
		return this;
	}

	public BookingPassengerDTO build() {
		return this.passenger;
	}

	public BookingPassengerDTOBuilder withPassengerTypeCode(String passengerTypeCode) {
		AgeQualifyingCode ageCode = AgeQualifyingCode.valueOf(passengerTypeCode);
		if (ageCode == null) {
			throw new IllegalArgumentException("Coud not parse PassengerTypeCode. Possible values are ADULT, SENIOR, YOUTH, CHILD, INFANT");
		}
		this.passenger.setType(ageCode);
		return this;
	}

	public BookingPassengerDTOBuilder withPassengerTypeQuantity(PassengerTypeQuantityType passengerTypeQuantity) {
		if (passengerTypeQuantity == null) {
			this.passenger.setQuantity(1);
		} else {
			this.passenger.setQuantity(passengerTypeQuantity.getQuantity().intValue());
		}
		return this;
	}

	public BookingPassengerDTOBuilder withPassengerGender(String gender) {
		this.passenger.setGender(GenderOptions.fromString(gender));
		return this;
	}

	public BookingPassengerDTOBuilder withMyID(MyIDType myID) {
		if (myID == null) {
			return this;
		}

		MyIDDTO myIDDTO = new MyIDDTO();
		myIDDTO.setAssignSeat(myID.isAssignSeat());
		myIDDTO.setEmployeeID(myID.getEmployeeID());
		myIDDTO.setEmployeeType(myID.getEmployeeType());
		myIDDTO.setPassengerAirlineCode(myID.getPassengerAirlineCode());
		myIDDTO.setFareCode(myID.getFareCode());
		this.passenger.setMyID(myIDDTO);
		return this;
	}

	public BookingPassengerDTOBuilder withReferenceNumber(TravelerRefNumber travelerRefNumber) {
		if (travelerRefNumber == null) {
			return this;
		}

		this.passenger.setTravelerRefNumber(travelerRefNumber.getRPH());
		return this;
	}
}