package com.flyairnorth.integration.builder;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.XMLGregorianCalendar;

import com.flyairnorth.integration.entity.TLog;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.AirItineraryType;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.AirItineraryType.OriginDestinationOptions;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.FlightSegmentBaseType.ArrivalAirport;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.FlightSegmentBaseType.DepartureAirport;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.ObjectFactory;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.OriginDestinationOptionType;
import com.flyairnorth.integration.util.CalendarUtils;

public class AirItineraryBuilder {

	private ObjectFactory objectFactory;
	private AirItineraryType airItinerary;

	public AirItineraryBuilder() {
		this.objectFactory = new ObjectFactory();
		this.airItinerary = objectFactory.createAirItineraryType();
	}

	public AirItineraryBuilder withTLog(TLog tlog) {
		airItinerary.setOriginDestinationOptions(getOriginDestination(tlog));
		
		return this;
	}

	private OriginDestinationOptions getOriginDestination(TLog tlog) {
		OriginDestinationOptions originDestinationOptions = objectFactory.createAirItineraryTypeOriginDestinationOptions();
		AirItineraryType.OriginDestinationOptions.OriginDestinationOption origDest = objectFactory.createAirItineraryTypeOriginDestinationOptionsOriginDestinationOption();
		OriginDestinationOptionType.FlightSegment segment = objectFactory.createOriginDestinationOptionTypeFlightSegment();

		DepartureAirport departureAirport = new DepartureAirport();
		departureAirport.setCodeContext(tlog.getFromCode());
		segment.setDepartureAirport(departureAirport);

		ArrivalAirport arrivalAirport = new ArrivalAirport();
		arrivalAirport.setCodeContext(tlog.getToCode());
		segment.setArrivalAirport(arrivalAirport);

		try {
			XMLGregorianCalendar xmlGregorianCalendar = CalendarUtils.convertToXMLGregorianCalendar(tlog.getDepartureDateTime());
			segment.setDepartureDateTime(xmlGregorianCalendar);
		} catch (DatatypeConfigurationException e) {
			throw new IllegalArgumentException("Error while parsing ultimateFDate to XML");
		}

		segment.setFareBasisCode(tlog.getFareClass());
		segment.setFlightNumber(tlog.getfFlight());

		origDest.getFlightSegment().add(segment);
		originDestinationOptions.getOriginDestinationOption().add(origDest);
		return originDestinationOptions;
	}

	public AirItineraryType build() {
		return this.airItinerary;
	}
}
