package com.flyairnorth.integration.builder;

import java.math.BigInteger;

import com.flyairnorth.integration.entity.TLog;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.AirTravelerType.TravelerRefNumber;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.ObjectFactory;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.PassengerTypeQuantityType;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.PersonNameType;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.TravelerInfoType.AirTraveler;

public class AirTravelerBuilder {

	private AirTraveler airTraveler;
	private ObjectFactory objectFactory;
	
	public AirTravelerBuilder() {
		objectFactory = new ObjectFactory();
		airTraveler = objectFactory.createTravelerInfoTypeAirTraveler();
	}

	public AirTravelerBuilder withTLog(TLog tlog) {
		airTraveler.setGender(tlog.getSex());
		airTraveler.setPersonName(getPersonNameType(tlog));
		PassengerTypeQuantityType quantity = objectFactory.createPassengerTypeQuantityType();
		quantity.setQuantity(BigInteger.ONE);
		airTraveler.setPassengerTypeQuantity(quantity);
		TravelerRefNumber airTravelerRefNumber = objectFactory.createAirTravelerTypeTravelerRefNumber();
		airTravelerRefNumber.setRPH(tlog.getTnumCntr().toString());
		airTraveler.setTravelerRefNumber(airTravelerRefNumber);

		return this;
	}

	private PersonNameType getPersonNameType(TLog tlog) {
		PersonNameType personName = objectFactory.createPersonNameType();
		personName.getGivenName().add(tlog.getFirst());
		personName.getMiddleName().add(tlog.getMiddle());
		personName.setSurname(tlog.getLast());

		return personName;
	}

	public AirTraveler build() {
		return airTraveler;
	}
}
