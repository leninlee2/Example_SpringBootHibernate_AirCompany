package com.flyairnorth.integration.exception;

import java.util.List;

import com.flyairnorth.integration.org.opentravel.ota._2003._05.ErrorType;

public class NoAvailableSeatsException extends BookingException {

	private static final long serialVersionUID = 7320416142865570133L;

	public NoAvailableSeatsException(ErrorType error) {
		super(error);
	}

	public NoAvailableSeatsException(List<ErrorType> errors) {
		super(errors);
	}

}
