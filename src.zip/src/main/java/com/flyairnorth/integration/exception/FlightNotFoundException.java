package com.flyairnorth.integration.exception;

import java.util.List;

import com.flyairnorth.integration.dto.booking.BookingDTO;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.ErrorType;

public class FlightNotFoundException extends BookingException {

	private static final long serialVersionUID = -5731698648819142823L;
	private BookingDTO bookingDTO;

	public FlightNotFoundException(ErrorType error) {
		super(error);
	}

	public FlightNotFoundException(List<ErrorType> errors) {
		super(errors);
	}

	public void setBookingDTO(BookingDTO bookingDTO) {
		this.bookingDTO = bookingDTO;
	}

	public BookingDTO getBookingDTO() {
		return bookingDTO;
	}
}
