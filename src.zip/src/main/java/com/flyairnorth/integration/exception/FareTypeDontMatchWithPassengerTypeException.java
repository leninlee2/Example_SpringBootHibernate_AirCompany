package com.flyairnorth.integration.exception;

public class FareTypeDontMatchWithPassengerTypeException extends RuntimeException {

	private static final long serialVersionUID = 4755618636111840792L;

}
