package com.flyairnorth.integration.exception;

public class MissingStaticConfigurationException extends RuntimeException{

	private static final long serialVersionUID = -6763291403955829662L;

	public MissingStaticConfigurationException() {
		super();
	}

	public MissingStaticConfigurationException(String message) {
		super(message);
	}
}
