package com.flyairnorth.integration.exception;

import java.util.List;

import com.flyairnorth.integration.dto.booking.BookingDTO;
import com.flyairnorth.integration.dto.search.FlightDTO;
import com.flyairnorth.integration.org.opentravel.ota._2003._05.ErrorType;

public class AmbiguousFlightsForSameDestinyException extends BookingException {

	private static final long serialVersionUID = 7379110446754199612L;
	private BookingDTO bookingDTO;
	private List<FlightDTO> flightsDTO;

	public AmbiguousFlightsForSameDestinyException(ErrorType error) {
		super(error);
	}

	public AmbiguousFlightsForSameDestinyException(List<ErrorType> errors) {
		super(errors);
	}

	public void setBookingDTO(BookingDTO bookingDTO) {
		this.bookingDTO = bookingDTO;
	}

	public BookingDTO getBookingDTO() {
		return bookingDTO;
	}

	public List<FlightDTO> getFlightsDTO() {
		return flightsDTO;
	}

	public void setFlightsDTO(List<FlightDTO> flightsDTO) {
		this.flightsDTO = flightsDTO;
	}
}