package com.flyairnorth.integration.exception;

import java.util.ArrayList;
import java.util.List;

import com.flyairnorth.integration.org.opentravel.ota._2003._05.ErrorType;

public class BookingException extends Exception {

	private static final long serialVersionUID = 6059714315780125125L;
	private List<ErrorType> errors;

	public BookingException(List<ErrorType> errors) {
		super();
		this.errors = errors;
	}

	public BookingException(ErrorType error) {
		this.errors = new ArrayList<>();
		this.errors.add(error);
	}

	public List<ErrorType> getErrors() {
		return errors;
	}
}
