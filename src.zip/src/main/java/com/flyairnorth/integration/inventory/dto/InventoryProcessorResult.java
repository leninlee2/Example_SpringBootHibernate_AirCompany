package com.flyairnorth.integration.inventory.dto;

import com.flyairnorth.integration.entity.FareSeatsInventory;
import com.flyairnorth.integration.entity.Fares;

public class InventoryProcessorResult {

	private Integer seatsBeforeUpdate;
	private FareSeatsInventory fareSeatsInventory;
	private Fares fare;
	private String processorName;

	public InventoryProcessorResult(Integer seatsBeforeUpdate, FareSeatsInventory fareSeatsInventory, Fares fare, String processorName) {
		this.seatsBeforeUpdate = seatsBeforeUpdate;
		this.fareSeatsInventory = fareSeatsInventory;
		this.fare = fare;
		this.processorName = processorName;
	}

	public Integer getSeatsBeforeUpdate() {
		return seatsBeforeUpdate;
	}

	public void setSeatsBeforeUpdate(Integer seatsBeforeUpdate) {
		this.seatsBeforeUpdate = seatsBeforeUpdate;
	}

	public FareSeatsInventory getFareSeatsInventory() {
		return fareSeatsInventory;
	}

	public void setFareSeatsInventory(FareSeatsInventory fareSeatsInventory) {
		this.fareSeatsInventory = fareSeatsInventory;
	}

	public Fares getFare() {
		return fare;
	}

	public void setFare(Fares fare) {
		this.fare = fare;
	} 	

	public String getProcessorName() {
		return processorName;
	}

	public void setProcessorName(String processorName) {
		this.processorName = processorName;
	}
}
