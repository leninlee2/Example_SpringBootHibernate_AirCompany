package com.flyairnorth.integration.inventory.dto;

import java.time.LocalDate;

import com.flyairnorth.integration.enumerator.InventoryStatusCode;

public class InventoryMessageDetail {

	private String airline;
	private String flight;
	private String bookingCode;
	private LocalDate date;
	private InventoryStatusCode statusCode;
	private String origin;
	private String destination;

	public InventoryMessageDetail(String airline, String flight, String bookingCode, LocalDate date,
			InventoryStatusCode statusCode, String origin, String destination) {
		this.airline = airline;
		this.flight = flight;
		this.bookingCode = bookingCode;
		this.date = date;
		this.statusCode = statusCode;
		this.origin = origin;
		this.destination = destination;
	}

	public InventoryMessageDetail() {
	}

	public String getAirline() {
		return airline;
	}

	public void setAirline(String airline) {
		this.airline = airline;
	}

	public String getFlight() {
		return flight;
	}

	public void setFlight(String flight) {
		this.flight = flight;
	}

	public String getBookingCode() {
		return bookingCode;
	}

	public void setBookingCode(String bookingCode) {
		this.bookingCode = bookingCode;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public InventoryStatusCode getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(InventoryStatusCode statusCode) {
		this.statusCode = statusCode;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	@Override
	public String toString() {
		return "InventoryMessageDetail [airline=" + airline + ", flight=" + flight + ", bookingCode=" + bookingCode
				+ ", date=" + date + ", statusCode=" + statusCode + ", origin=" + origin + ", destination="
				+ destination + "]";
	}
}
