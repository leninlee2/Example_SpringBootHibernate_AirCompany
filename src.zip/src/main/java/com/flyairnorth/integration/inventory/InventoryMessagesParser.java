package com.flyairnorth.integration.inventory;

import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Locale;
import java.util.StringTokenizer;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.flyairnorth.integration.enumerator.InventoryStatusCode;
import com.flyairnorth.integration.inventory.dto.InventoryMessage;
import com.flyairnorth.integration.inventory.dto.InventoryMessageDetail;
import com.flyairnorth.integration.ssm.parser.exception.ParserException;

@Service
public class InventoryMessagesParser {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(InventoryMessagesParser.class);

	private static final String LOG_PREFIX = "[INVENTORY MESSAGES PARSER]=========== ";

	public static final String COMMAND = "AVS";

	public InventoryMessage parse(String message) throws ParserException {
		InventoryMessage inventoryMessage = new InventoryMessage();
		message = StringUtils.remove(message, StringUtils.CR);
		StringTokenizer tokenizer = new StringTokenizer(message, StringUtils.LF);
		String command = tokenizer.nextToken();

		if (!command.equals(COMMAND)) {
			String errorMessage = MessageFormat.format("{0} AVS message doesn''t contain ''AVS'' on first line. Content: \"{1}\"", LOG_PREFIX, command);
			LOGGER.error(errorMessage);
			throw new ParserException(errorMessage);
		}	

		inventoryMessage.setCommand(command);
		while (tokenizer.hasMoreTokens()) {
			String line = tokenizer.nextToken();
			try {
				InventoryMessageDetail detail = parseMessageDetail(line);
				inventoryMessage.getDetails().add(detail);
			}catch(ParserException | ParseException e) {
					String errorMessage = MessageFormat.format("Could not parse date information on message: {0}", line);
					LOGGER.error(errorMessage);
					throw new ParserException(errorMessage);
			}
		}

		return inventoryMessage;
	}

	private InventoryMessageDetail parseMessageDetail(String message) throws ParserException, ParseException {
		if (message.length() != 20) {
			String errorMessage = MessageFormat.format("{0} Unformatted AVS message. Expected 20 characters and found {1}."
					+ ". Example of expected message: 4N0207K25JULLCYDAYEV. Received: {2}" , LOG_PREFIX, message.length(), message);
			LOGGER.error(errorMessage);
			throw new ParserException(errorMessage);
		}
		//4N0207K25JULL8YDAYEV
		String airline = message.substring(0, 2);
		String flight = message.substring(2, 6);
		if (flight.startsWith("0")) { 
			//removing left zero
			flight = flight.substring(1);
		}
		String bookingCode = message.substring(6, 7);
		String textualDate = message.substring(7, 12);
		LocalDate date = new SimpleDateFormat("ddMMM", Locale.US).parse(textualDate).toInstant().atZone(ZoneId.systemDefault()).toLocalDate().withYear(LocalDate.now().getYear());
		String statusCode = message.substring(12, 14);
		String origin = message.substring(14, 17);
		String destination = message.substring(17);
		try {
			InventoryMessageDetail detail = new InventoryMessageDetail(airline, flight, bookingCode, date, InventoryStatusCode.valueOf(statusCode), origin, destination);
			return detail;
		}catch(IllegalArgumentException iae) {
			String[] values = Arrays.stream(InventoryStatusCode.values()).map(Enum::name).toArray(String[]::new);
			String errorMessage = MessageFormat.format("{0} Wrong status code received: {1}. Expected: {2}", LOG_PREFIX, statusCode, StringUtils.join(values, ','));
			LOGGER.error(errorMessage);
			throw new ParserException(errorMessage);
		}
	}
}
