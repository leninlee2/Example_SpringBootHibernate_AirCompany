package com.flyairnorth.integration.inventory.dto;

import java.util.ArrayList;
import java.util.List;

public class InventoryMessage {

	private String command;
	private List<InventoryMessageDetail> details;

	public String getCommand() {
		return command;
	}

	public void setCommand(String command) {
		this.command = command;
	}

	public List<InventoryMessageDetail> getDetails() {
		if (details == null) {
			details = new ArrayList<>();
		}
		return details;
	}

	public void setDetails(List<InventoryMessageDetail> details) {
		this.details = details;
	}
}
