package com.flyairnorth.integration.enumerator;

public enum BookingErrors {

	MISSING_ARGUMENTS, WRONG_VALUE, INTERNAL_ERROR, DISABLED_FEATURE;

}
