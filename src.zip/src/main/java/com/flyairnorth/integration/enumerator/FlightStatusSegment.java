package com.flyairnorth.integration.enumerator;

public enum FlightStatusSegment {
	HK("HK"), 
	PK("PK");
	
	private String label;

	private FlightStatusSegment(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

}
