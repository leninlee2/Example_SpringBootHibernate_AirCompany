package com.flyairnorth.integration.enumerator;

public enum VidecomContactType {
	BUSINESS("B"), AGENCY("T"), HOME("H"), MOBILE("M"), OTHER("P"), PHYSICAL("A"), CREDIT("C"), EMAIL("E");

	private String type;

	private VidecomContactType(String type) {
		this.type = type;
	}

	public String getType() {
		return this.type;
	}

	@Override
	public String toString() {
		return this.type;
	}

	public static VidecomContactType fromString(String text) {
		if (text == null) {
			return OTHER;
		}
		switch (text) {
		case "B":
			return BUSINESS;
		case "T":
			return AGENCY;
		case "H":
			return HOME;
		case "M":
			return MOBILE;
		case "P":
			return OTHER;
		case "A":
			return PHYSICAL;
		case "C":
			return CREDIT;
		case "E":
			return EMAIL;
		default:
			return OTHER;
		}
	}

}
