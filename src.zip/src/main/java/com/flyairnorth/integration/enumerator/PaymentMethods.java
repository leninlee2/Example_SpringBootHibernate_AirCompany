package com.flyairnorth.integration.enumerator;

public enum PaymentMethods {
	SABRE, TRAVELPORT, AMADEUS, VARVISA, VARMC, VARAMEX, VIDECOM;
}
	