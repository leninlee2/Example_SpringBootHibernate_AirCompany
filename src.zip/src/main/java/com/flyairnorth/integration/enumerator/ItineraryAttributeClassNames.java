package com.flyairnorth.integration.enumerator;

public enum ItineraryAttributeClassNames {
	BSOURCE("bsource"), 
	BCONTACT("bcontact"), 
	BISSUE("bissue"),
	BPNR("bpnr"),
	GDSPNR("GDSPNR"),
	PNR("PNR")
	;
	
	private String value;

	private ItineraryAttributeClassNames(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return this.value;
	}
}
