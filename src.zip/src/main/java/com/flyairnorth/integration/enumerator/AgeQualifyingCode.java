package com.flyairnorth.integration.enumerator;

public enum AgeQualifyingCode {
	ADULT("A"), 
	SENIOR("S"), 
	YOUTH("Y"), 
	CHILD("C"), 
	INFANT("I");

	private String label;

	private AgeQualifyingCode(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}
}
