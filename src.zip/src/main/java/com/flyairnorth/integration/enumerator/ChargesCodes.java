package com.flyairnorth.integration.enumerator;

public enum ChargesCodes {

	GST("GST"), Q("Q"), ATSC("ATSC"), AIF("AIF"), HST("HST");

	private String code;

	private ChargesCodes(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
}
