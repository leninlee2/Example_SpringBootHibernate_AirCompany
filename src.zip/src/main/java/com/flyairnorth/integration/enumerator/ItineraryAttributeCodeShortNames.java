package com.flyairnorth.integration.enumerator;

public enum ItineraryAttributeCodeShortNames {
	WEB, RES, MyID, GDS, GDST, HPHONE, CPHONE, FAX, EMAIL, AIRPORTCODE, GDSOLD;
}
