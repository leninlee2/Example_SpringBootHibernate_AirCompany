package com.flyairnorth.integration.enumerator;

public enum TransactionSources {
	GDS, VIDECOM;
}
