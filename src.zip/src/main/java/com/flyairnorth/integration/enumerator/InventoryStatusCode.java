package com.flyairnorth.integration.enumerator;

import javax.jms.IllegalStateRuntimeException;

public enum InventoryStatusCode {
	AS, CR, CL, CC, CN, CS, LR, LL, LC, LA, LN, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, L0, L1, L2, L3, L4, L5, L6, L7, L8, L9;

	public Integer getInteger() {
		switch (this) {
		case A0:
		case L0:
			return 0;
		case A1:
		case L1:
			return 1;
		case A2:
		case L2:
			return 2;
		case A3:
		case L3:
			return 3;
		case A4:
		case L4:
			return 4;
		case A5:
		case L5:
			return 5;
		case A6:
		case L6:
			return 6;
		case A7:
		case L7:
			return 7;
		case A8:
		case L8:
			return 8;
		case A9:
		case L9:
			return 9;
		default:
			throw new IllegalStateRuntimeException(
					"This method should not be called for following cases: [AS, CR, CL, CC, CN, CS, LR, LL, LC, LA, LN]. Value sent: "+this.toString());
		}
	}
}
