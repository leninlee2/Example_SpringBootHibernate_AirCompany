package com.flyairnorth.integration.enumerator;

public enum CheckinStatus {

	OPENED, CLOSED, GATE, RELEASED;

}
