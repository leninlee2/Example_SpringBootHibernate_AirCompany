package com.flyairnorth.integration.enumerator;

public enum Status {
	
	SCHEDULED,
	DELAYED,
	CANCELLED;

}
