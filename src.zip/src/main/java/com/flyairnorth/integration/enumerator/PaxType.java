package com.flyairnorth.integration.enumerator;

public enum PaxType {
	A,
	C,
	E;
}
