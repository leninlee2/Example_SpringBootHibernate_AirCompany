package com.flyairnorth.integration.enumerator;

public enum TicketAttributeCodes {

	STAND_BY_PRIORITY("SBYPRI"),
	STAND_BY_DOJ("SBYDOJ"),
	STAND_BY_TICKET_TYPE("SBYTICTYPE"),
	EMP_NAME_MISMATCH("EMPMISMATCH"),
	EMP_ID_NOT_FOUND("EMPIDNOTFOUND"),
	MISSING_GENDER("MISSGENDER"),
	VIDECOM_BOOKING("VIDECOMBOOKING"),
	UNAVAILABLE_FARE("UNAVAILABLEFARE"),
	ETICKET_NUMBER("ETICKETNUM"),
	GDSSSRS("GDSSSRS"),
	RULECODE("RULECODE");

	private String code;

	private TicketAttributeCodes(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}
}
