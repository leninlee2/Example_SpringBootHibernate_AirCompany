package com.flyairnorth.integration.enumerator;

public enum GenderOptions {
	DEFAULT("MALE"),
	MALE("MALE"),
	FEMALE("FEMALE");

	private String value;

	private GenderOptions(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return this.value;
	}

	public static GenderOptions fromString(String value) {
		if (value == null) {
			return DEFAULT;
		}
		switch (value) {
		case "M":
			return MALE;
		case "F":
			return FEMALE;
		default:
			return DEFAULT;
		}
	}
}
