package com.flyairnorth.integration.enumerator;

public enum YesNo {
	Y,
	N;

}
