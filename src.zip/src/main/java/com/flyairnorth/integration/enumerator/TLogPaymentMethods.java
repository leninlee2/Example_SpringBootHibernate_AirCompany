package com.flyairnorth.integration.enumerator;

public enum TLogPaymentMethods {

	CASH("CASH"), DELAYED("DELAYED"), CRED_VISA("CRED:Visa"), CRED_MC("CRED:MC"), CRED_AMEX("CRED:AMEX"), GC("GC"), 
	REF("REF"), INUMREF("INUMREF"), CRED_VARVISA("CRED:VARVISA"), CRED_VARMC("CRED:VARMC"), CRED_VARAMEX("CRED:VARAMEX");

	private String value;

	private TLogPaymentMethods(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	@Override
	public String toString() {
		return this.getValue();
	}
}
